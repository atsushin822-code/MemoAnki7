# 変換ツール(PC側)

辞書(XD-A8500)に入れるデータを PC で作るツールです。Python 3.8 以上が必要です(標準ライブラリのみ。新形式の Anki ファイルだけ `pip install zstandard`)。

| 作りたいもの | ツール | 出力 |
|---|---|---|
| Anki のデッキ | `tools/anki_to_deck.py` | `IMPORT.DAT` |
| CSV の単語帳 | `tools/csv_to_deck.py` | `IMPORT.DAT` |
| Wikipedia の記事 | `tools/wikipedia_convert.py` | `WIKI.DAT` + `WIKI_SOURCES.txt` |
| 自分で用意した JSONL の記事 | `tools/wikipedia_prepare.py` | `WIKI.DAT` |

できたファイルは、辞書のアプリフォルダ(`MEMAN`)に入れて転送します(手順は README / 導入手順を参照)。取り込みはアプリの **Settings → Import a deck from IMPORT.DAT**、記事は **Wikipedia** 画面で読めます。

## CSV はそのまま取り込める

単語帳が CSV(UTF-8、`Front,Back,Example`)だけなら、変換せずに `MEMAN` フォルダへ入れ、アプリの **Settings → Import a deck from a file** で取り込めます(デッキ名はその場で入力。初期値はファイル名)。**ファイル名は自由**です(`IMPORT2.CSV`、`words.csv` など `.CSV` なら何でも可)。変換ツールが作る `.DAT` は `IMPORT.DAT`、`IMPORT2.DAT` のように `IMPORT` で始まる名前にしてください。複数のファイルを入れておくと、取り込み画面に一覧で並びます。Anki のファイルや、Shift_JIS の CSV には、下の変換ツールを使ってください。

## Anki → IMPORT.DAT

**Anki での書き出し**
- 推奨: *ファイル → 書き出し → Anki デッキパッケージ (.apkg)*、「古いバージョンの Anki をサポート」に**チェックを入れる**。
- 代わりに *「ノートをプレーンテキストで書き出し」*(`.txt`)でも変換できます(最も確実)。

**変換**
```
python3 tools/anki_to_deck.py my.apkg --list                 # デッキ・ノートタイプ・フィールドを表示
python3 tools/anki_to_deck.py my.apkg --deck "英単語" -o IMPORT.DAT
python3 tools/anki_to_deck.py my.apkg --model Basic --front Front --back Back --example 3 -o IMPORT.DAT
python3 tools/anki_to_deck.py notes.txt --name "My words" -o IMPORT.DAT
```
- フィールドは名前か番号(1始まり)で指定します。省略時は 1=表、2=裏、3=例文です。
- 穴埋め(Cloze)ノートは、穴ごとに1枚のカードになります(表は `[...]` 付きの文、裏は答え)。
- HTML・画像・`[sound:]` は取り除きます。改行は ` / ` で連結します(`--newline` で変更)。
- 同じ表・裏のカードは1枚にまとめます。
- **学習履歴・間隔は引き継ぎません**(すべて新規カードになります)。画像・音声も取り込みません。
- 1回の取り込みは **600枚まで**です。超える場合は表示に従い `--start 600` のように続きを別ファイルに作ります。
- デッキ名は日本語可(47バイトまで)です。1ファイルにつき1デッキです。

## Wikipedia → WIKI.DAT

辞書の容量は限られるので、**読みたい記事を選んで**変換するのが基本です。

**A. タイトル一覧から取得(いちばん簡単。要ネット接続)**
```
# titles.txt に1行1タイトルで書く(# で始まる行はコメント)
python3 tools/wikipedia_convert.py fetch titles.txt --lang ja -o WIKI.DAT
```
Wikipedia の API を、1件ずつ間隔を空けて呼びます。Wikimedia は連絡先入りの User-Agent を求めているので、`--user-agent "MyTool/1.0 (you@example.com)"` を付けてください。

**B. 公式ダンプから**(`dumps.wikimedia.org` の `jawiki-latest-pages-articles.xml.bz2`。数GBあります)
```
python3 tools/wikipedia_convert.py dump jawiki-latest-pages-articles.xml.bz2 --titles-file titles.txt -o WIKI.DAT
python3 tools/wikipedia_convert.py dump jawiki-latest-pages-articles.xml.bz2 --limit 3000 --min-chars 400 -o WIKI.DAT
```
`--titles-file` なしでは「条件に合う最初の N 件」になり、選び方は指定できません。リダイレクト、曖昧さ回避、ノート等、短すぎる記事は除外します。

**C. WikiExtractor の出力から**
```
python3 tools/wikipedia_convert.py extractor extracted/AA/wiki_00 extracted/AA/wiki_01 -o WIKI.DAT
```

**共通の仕様**
- 本文は整形したプレーンテキストにします(テンプレート・表・脚注・画像・外部リンク等の節は除去)。見出しは「■ / □」になります。整形は簡易なので、記事によっては欠けたり崩れたりします。
- 1記事 20,000 バイトまで(`--max-bytes`、辞書側の上限は 32KB)。
- 検索は「よみ」で行います。日本語記事は本文先頭の「(よみ)」から自動で拾います。拾えない漢字題名は一覧のスクロールでのみ読めます(最後に件数を表示します)。
- 出力の隣に `WIKI_SOURCES.txt`(題名とURL)を作ります。**Wikipedia の本文は CC BY-SA 4.0 です。** データを配る場合は出典を付けてください。

## 共通の注意
- 辞書の内蔵フォントで出せない文字(JIS X 0208 外)は `?` になります。変換時に該当文字を一覧表示します。
- 動作確認: `python3 -m unittest discover tools/tests`
