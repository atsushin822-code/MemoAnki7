# Build status

Target: CASIO EX-word DATAPLUS 5 / XD-A8500.

Verified in the development sandbox:
- devkitSH4 builds with no warnings (-Os, -ffunction-sections, --gc-sections). Code+rodata 119,308 of 130,944 bytes (ROM region); .bss ~19 KB of the 32 KB RAM region. The Japanese font is ~70 KB of that.
- Host simulator (`tools/sim/run_sim.sh`, ASan/UBSan) runs the real UI/logic: tour, persistence, quit unwinding, reset/key test, low-memory fallback, Wikipedia (browse/search/read/zoom/make card), Japanese import/study/kana input. Unit tests: UTF-8, line breaking, romaji editor, font lookup.

Not verified: real XD-A8500 behaviour (key codes, file locations `_USER\MEMANKI.DAT` / app folder, memory pool, LCD output, whether extra files like WIKI.DAT are installed with the add-on, speed of text drawing).

Lessons: static RAM is ~32 KB and ROM ~128 KB; large struct assignment needs memcpy (no libgcc); the device libc has no strncmp/memmove (src/libc/memmove.c provides memmove); do not use -O3 (overflows ROM); `html/` needs diction.htm, infodp5.htm, infogt5.htm.
