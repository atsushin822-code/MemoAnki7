# GitHub Actions でのビルドと実機への導入

1. 空の GitHub リポジトリを作り、このフォルダの中身(`.github`, `.gitattributes` を含む)をアップロードする。
   - `.gitattributes` は `html/*.htm` の改行(CRLF)を壊さないために必要です。
2. **Actions → Build MemoAnki EX → Run workflow**(push でも自動実行されます)。
3. 完了後、Artifacts から取得:
   - `MemoAnki-EX-build` … `build.zip`(`build/ja/MEMAN/` と `build/cn/MEMAN/`。XD-A8500 は **ja**)
   - `MemoAnki-EX-screenshots` … シミュレータの画面PNG(日本語表示・Wikipedia 含む)
4. Release が欲しい場合: Run workflow の `tag` に `v1` など、または `git tag v1 && git push origin v1`。
5. 本体への転送: `build/ja/MEMAN` を libexword の手順(`dict install MEMAN` 等)で EX-word に導入。

## 初回起動で確認してほしいこと

- ホームが出て、↑↓/ENTER/BACK が効く。
- **Settings → Key test** で各キーの名前が出る(SYMBOL がスペースとして使えるか等)。
- Settings の `Data file` が `saved OK` になる。`SAVE FAILED` の場合は進捗が保存されません(結果を教えてください)。

## 日本語・Wikipedia の確認

- ホーム → Settings → **Import a deck from IMPORT.DAT** で日本語入りサンプルデッキを取り込み、Study で表示を確認。
- ホーム → Wikipedia で `huji`(F1 で hira にして入力)→ ふじさん → 富士山。表示されない場合は `WIKI.DAT not installed`(ファイルがデバイスに届いていない)なので、結果を教えてください。
- `WIKI.DAT` / `IMPORT.DAT` は `data/device/` に置くと、ビルド成果物に含まれます。
