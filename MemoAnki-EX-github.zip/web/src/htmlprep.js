/* MemoAnki EX: HTML(+CSS+images) -> offline-browser files (.HTM/.CSS/.IMG). Mirrors tools/html_prepare.py (byte-identical output). No DOM. */
(function (root) {
  'use strict';
  var MAX_W = 480, MAX_H = 200, MASK = 0xF81F;
  var LIM_HTML = 24 * 1024 - 1, LIM_CSS = 4096 - 1, LIM_IMGS = 8, LIM_LINKS = 12;

  /* ---------------- colour helpers (same as tools/imgfmt.py) ---------------- */
  function to565(r, g, b) {
    var v = (Math.floor((r * 31 + 127) / 255) << 11) | (Math.floor((g * 63 + 127) / 255) << 5) | Math.floor((b * 31 + 127) / 255);
    return v === MASK ? (v ^ 1) : v;
  }
  function from565(v) {
    var r = (v >> 11) & 31, g = (v >> 5) & 63, b = v & 31;
    return [(r << 3) | (r >> 2), (g << 2) | (g >> 4), (b << 3) | (b >> 2)];
  }

  function shrinkNearest(w, h, rgb, maxW, maxH) {
    if (w <= maxW && h <= maxH) return { w: w, h: h, rgb: rgb };
    var scale = Math.min(maxW / w, maxH / h);
    var nw = Math.max(1, Math.floor(w * scale)), nh = Math.max(1, Math.floor(h * scale));
    var out = new Uint8Array(nw * nh * 3);
    for (var y = 0; y < nh; y++) {
      var sy = Math.floor(y * h / nh);
      for (var x = 0; x < nw; x++) {
        var sx = Math.floor(x * w / nw), s = (sy * w + sx) * 3, d = (y * nw + x) * 3;
        out[d] = rgb[s]; out[d + 1] = rgb[s + 1]; out[d + 2] = rgb[s + 2];
      }
    }
    return { w: nw, h: nh, rgb: out };
  }

  /* weighted median cut on the RGB565 histogram (same result as tools/imgfmt.py without Pillow) */
  function makeBox(items) {
    var best = -1, chan = 0;
    for (var c = 0; c < 3; c++) {
      var mn = 255, mx = 0;
      for (var i = 0; i < items.length; i++) {
        var q = from565(items[i][0])[c];
        if (q < mn) mn = q;
        if (q > mx) mx = q;
      }
      if (mx - mn > best) { best = mx - mn; chan = c; }
    }
    return { items: items, score: items.length > 1 ? best : 0, chan: chan };
  }
  function medianCut(hist) {
    var items = [];
    hist.forEach(function (cnt, v) { items.push([v, cnt]); });
    items.sort(function (a, b) { return a[0] - b[0]; });
    var boxes = [makeBox(items)];
    while (boxes.length < 256) {
      var bi = -1, bs = 0;
      for (var i = 0; i < boxes.length; i++) if (boxes[i].score > bs) { bs = boxes[i].score; bi = i; }
      if (bi < 0) break;
      var box = boxes.splice(bi, 1)[0], chan = box.chan;
      var arr = box.items.map(function (t) { return [from565(t[0])[chan], t[0], t[1]]; });
      arr.sort(function (a, b) { return a[0] - b[0] || a[1] - b[1]; });
      var sorted = arr.map(function (t) { return [t[1], t[2]]; });
      var total = 0, k;
      for (k = 0; k < sorted.length; k++) total += sorted[k][1];
      var acc = 0, cut = 1;
      for (k = 0; k < sorted.length; k++) {
        acc += sorted[k][1];
        if (acc * 2 >= total) { cut = Math.min(Math.max(k + 1, 1), sorted.length - 1); break; }
      }
      boxes.splice(bi, 0, makeBox(sorted.slice(0, cut)), makeBox(sorted.slice(cut)));
    }
    return boxes.map(function (b) {
      var tot = 0, r = 0, g = 0, bl = 0;
      b.items.forEach(function (t) { var e = from565(t[0]); tot += t[1]; r += e[0] * t[1]; g += e[1] * t[1]; bl += e[2] * t[1]; });
      return to565(Math.floor(r / tot), Math.floor(g / tot), Math.floor(bl / tot));
    });
  }
  function quantize(w, h, rgb) {
    var hist = new Map(), n = w * h, i;
    for (i = 0; i < n; i++) {
      var v = to565(rgb[i * 3], rgb[i * 3 + 1], rgb[i * 3 + 2]);
      hist.set(v, (hist.get(v) || 0) + 1);
    }
    var pal;
    if (hist.size <= 256) { pal = Array.from(hist.keys()).sort(function (a, b) { return a - b; }); }
    else pal = medianCut(hist);
    var exp = pal.map(from565), cache = new Map(), out = new Uint8Array(n);
    for (i = 0; i < n; i++) {
      var q = to565(rgb[i * 3], rgb[i * 3 + 1], rgb[i * 3 + 2]), k = cache.get(q);
      if (k === undefined) {
        var e = from565(q), bd = Infinity;
        k = 0;
        for (var j = 0; j < exp.length; j++) {
          var d = (exp[j][0] - e[0]) * (exp[j][0] - e[0]) + (exp[j][1] - e[1]) * (exp[j][1] - e[1]) + (exp[j][2] - e[2]) * (exp[j][2] - e[2]);
          if (d < bd) { bd = d; k = j; }
        }
        cache.set(q, k);
      }
      out[i] = k;
    }
    return { pal: pal, idx: out };
  }
  function packImg(w, h, pal, idx) {
    var out = new Uint8Array(4 + 4 + 512 + idx.length), dv = new DataView(out.buffer);
    out.set([0x49, 0x4D, 0x47, 0x31], 0);                       /* "IMG1" */
    dv.setUint16(4, w); dv.setUint16(6, h);
    for (var i = 0; i < 256; i++) dv.setUint16(8 + i * 2, i < pal.length ? pal[i] : 0);
    out.set(idx, 520);
    return out;
  }

  /* ---------------- text / paths ---------------- */
  function decodeText(bytes) {
    try { return new TextDecoder('utf-8', { fatal: true }).decode(bytes); } catch (e) {}
    try { return new TextDecoder('shift_jis', { fatal: true }).decode(bytes); } catch (e) {}
    return new TextDecoder('utf-8').decode(bytes);
  }
  function normPath(p) {
    var parts = [];
    String(p).replace(/\\/g, '/').split('/').forEach(function (s) {
      if (s === '' || s === '.') return;
      if (s === '..') { parts.pop(); return; }
      parts.push(s);
    });
    return parts.join('/');
  }
  function dirOf(p) { var i = p.lastIndexOf('/'); return i < 0 ? '' : p.slice(0, i); }
  function baseOf(p) { var i = p.lastIndexOf('/'); return i < 0 ? p : p.slice(i + 1); }
  function extOf(p) { var b = baseOf(p), i = b.lastIndexOf('.'); return i > 0 ? b.slice(i).toLowerCase() : ''; }
  function stemOf(p) { var b = baseOf(p), i = b.lastIndexOf('.'); return i > 0 ? b.slice(0, i) : b; }

  function Names() { this.map = {}; this.used = {}; }
  Names.prototype.get = function (path, ext) {
    if (this.map[path]) return this.map[path];
    var stem = stemOf(path).replace(/[^A-Za-z0-9_]/g, '').toUpperCase().slice(0, 8) || 'FILE';
    var name = stem, n = 1;
    while (this.used[name + ext]) { var suffix = String(n); name = stem.slice(0, 8 - suffix.length) + suffix; n++; }
    this.used[name + ext] = true;
    this.map[path] = name + ext;
    return this.map[path];
  };

  /* the pages to convert: index first, then the others by path */
  function orderPages(files) {
    var pages = files.filter(function (f) { var e = extOf(f.path); return e === '.htm' || e === '.html'; }).map(function (f) { return normPath(f.path); });
    pages.sort(function (a, b) {
      var ai = /^index\.html?$/i.test(baseOf(a)) ? 0 : 1, bi = /^index\.html?$/i.test(baseOf(b)) ? 0 : 1;
      if (ai !== bi) return ai - bi;
      return a < b ? -1 : a > b ? 1 : 0;
    });
    return pages;
  }

  /* opts.decodeImage(bytes, path) -> Promise<{w, h, rgb}> (already shrunk to 480x200) */
  async function convert(files, opts) {
    var byPath = {}, byLower = {}, out = {}, warnings = [], rows = [];
    files.forEach(function (f) { var p = normPath(f.path); byPath[p] = f; byLower[p.toLowerCase()] = f; f.npath = p; });
    var names = new Names(), done = {}, imgDone = {};

    function find(base, ref) {
      ref = ref.split('#')[0].split('?')[0].trim();
      if (!ref || /^(https?:|data:|mailto:|\/\/)/i.test(ref)) return null;
      var cands = [ref];
      try { var d = decodeURIComponent(ref); if (d !== ref) cands.push(d); } catch (e) {}
      for (var i = 0; i < cands.length; i++) {
        var p = cands[i].charAt(0) === '/' ? normPath(cands[i]) : normPath(dirOf(base) + '/' + cands[i]);
        if (byPath[p]) return byPath[p];
        if (byLower[p.toLowerCase()]) return byLower[p.toLowerCase()];
      }
      return null;
    }

    var queue = orderPages(files);
    while (queue.length) {
      var pagePath = queue.shift();
      if (done[pagePath] || !byPath[pagePath]) continue;
      done[pagePath] = true;
      var pageName = baseOf(pagePath), html = decodeText(byPath[pagePath].data);
      var tokens = [], notes = [], nImg = 0, nLink = 0;

      html = html.replace(/(<img\b[^>]*?\bsrc\s*=\s*)(["'])(.*?)\2/gis, function (m, a, q, ref) {
        var f = find(pagePath, ref);
        if (!f) { if (!/^(https?:|data:|\/\/)/i.test(ref.trim())) warnings.push(pageName + ': 画像が見つかりません: ' + ref); return m; }
        var name = names.get(f.npath, '.IMG');
        nImg++;
        tokens.push({ name: name, path: f.npath, ref: ref });
        return a + q + '\u0001' + (tokens.length - 1) + '\u0001' + q;
      });
      html = html.replace(/<link\b[^>]*>/gis, function (m) {
        if (!/stylesheet/i.test(m)) return m;
        return m.replace(/(href\s*=\s*)(["'])(.*?)\2/is, function (mm, a, q, ref) {
          var f = find(pagePath, ref);
          if (!f) { warnings.push(pageName + ': CSS が見つかりません: ' + ref); return mm; }
          var name = names.get(f.npath, '.CSS');
          if (!out[name]) {
            var css = decodeText(f.data);
            out[name] = { data: new TextEncoder().encode(css), src: baseOf(f.npath) };
            if (out[name].data.length > LIM_CSS) warnings.push(name + ': 4KB を超えています(端末では先頭 4KB だけ使われます)');
          }
          return a + q + name + q;
        });
      });
      html = html.replace(/(<a\b[^>]*?\bhref\s*=\s*)(["'])(.*?)\2/gis, function (m, a, q, ref) {
        var f = find(pagePath, ref), e = f ? extOf(f.npath) : '';
        if (!f || (e !== '.htm' && e !== '.html')) {
          if (!f && ref.trim() && !/^(https?:|data:|mailto:|#|\/\/|javascript:)/i.test(ref.trim())) warnings.push(pageName + ': リンク先が選ばれていません: ' + ref);
          return m;
        }
        queue.push(f.npath);
        nLink++;
        var i = ref.indexOf('#'), frag = i >= 0 ? '#' + ref.slice(i + 1) : '';
        return a + q + names.get(f.npath, '.HTM') + frag + q;
      });
      var pageOut = names.get(pagePath, '.HTM');

      for (var t = 0; t < tokens.length; t++) {
        var tk = tokens[t], replacement = tk.ref;
        if (!imgDone[tk.name]) {
          try {
            var im = await opts.decodeImage(byPath[tk.path].data, tk.path);
            var qz = quantize(im.w, im.h, im.rgb);
            out[tk.name] = { data: packImg(im.w, im.h, qz.pal, qz.idx), src: baseOf(tk.path), w: im.w, h: im.h };
            imgDone[tk.name] = true;
          } catch (e) { warnings.push(baseOf(tk.path) + ': 画像を読めません(' + (e && e.message || e) + ')'); imgDone[tk.name] = 'bad'; }
        }
        if (imgDone[tk.name] === true) replacement = tk.name;
        tk.out = replacement;
      }
      html = html.replace(/\u0001(\d+)\u0001/g, function (m, i) { return tokens[+i].out; });

      var bytes = new TextEncoder().encode(html);
      out[pageOut] = { data: bytes, src: pageName };
      if (bytes.length > LIM_HTML) warnings.push(pageOut + ': 24KB を超えています(端末では先頭の 24KB だけ読み込まれます)');
      if (nImg > LIM_IMGS) warnings.push(pageOut + ': 画像が ' + nImg + ' 枚あります(端末で表示されるのは 8 枚まで)');
      if (nLink > LIM_LINKS) warnings.push(pageOut + ': リンクが ' + nLink + ' 個あります(端末で使えるのは 12 個まで)');
    }
    Object.keys(out).sort().forEach(function (n) { rows.push({ name: n, src: out[n].src, size: out[n].data.length, w: out[n].w, h: out[n].h }); });
    return { files: out, rows: rows, warnings: warnings };
  }

  /* ---------------- ZIP (stored, no compression) ---------------- */
  var crcTable = null;
  function crc32(data) {
    if (!crcTable) { crcTable = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; crcTable[n] = c >>> 0; } }
    var crc = 0xFFFFFFFF;
    for (var i = 0; i < data.length; i++) crc = crcTable[(crc ^ data[i]) & 255] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }
  function makeZip(entries) {      /* entries: [{name, data}] */
    var enc = new TextEncoder(), parts = [], central = [], offset = 0, now = new Date();
    var dtime = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1);
    var ddate = ((Math.max(now.getFullYear(), 1980) - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
    entries.forEach(function (e) {
      var nm = enc.encode(e.name), crc = crc32(e.data);
      var lh = new Uint8Array(30 + nm.length), dv = new DataView(lh.buffer);
      dv.setUint32(0, 0x04034b50, true); dv.setUint16(4, 20, true); dv.setUint16(6, 0x0800, true); dv.setUint16(8, 0, true);
      dv.setUint16(10, dtime, true); dv.setUint16(12, ddate, true); dv.setUint32(14, crc, true);
      dv.setUint32(18, e.data.length, true); dv.setUint32(22, e.data.length, true); dv.setUint16(26, nm.length, true); dv.setUint16(28, 0, true);
      lh.set(nm, 30);
      var ch = new Uint8Array(46 + nm.length), cv = new DataView(ch.buffer);
      cv.setUint32(0, 0x02014b50, true); cv.setUint16(4, 20, true); cv.setUint16(6, 20, true); cv.setUint16(8, 0x0800, true); cv.setUint16(10, 0, true);
      cv.setUint16(12, dtime, true); cv.setUint16(14, ddate, true); cv.setUint32(16, crc, true);
      cv.setUint32(20, e.data.length, true); cv.setUint32(24, e.data.length, true); cv.setUint16(28, nm.length, true);
      cv.setUint32(42, offset, true);
      ch.set(nm, 46);
      parts.push(lh, e.data); central.push(ch);
      offset += lh.length + e.data.length;
    });
    var csize = 0;
    central.forEach(function (c) { csize += c.length; });
    var end = new Uint8Array(22), ev = new DataView(end.buffer);
    ev.setUint32(0, 0x06054b50, true); ev.setUint16(8, entries.length, true); ev.setUint16(10, entries.length, true);
    ev.setUint32(12, csize, true); ev.setUint32(16, offset, true);
    var all = parts.concat(central, [end]), total = 0, pos = 0;
    all.forEach(function (a) { total += a.length; });
    var res = new Uint8Array(total);
    all.forEach(function (a) { res.set(a, pos); pos += a.length; });
    return res;
  }

  root.HtmlPrep = { convert: convert, makeZip: makeZip, orderPages: orderPages, shrinkNearest: shrinkNearest, quantize: quantize, packImg: packImg, decodeText: decodeText, MAX_W: MAX_W, MAX_H: MAX_H };
})(typeof window !== 'undefined' ? window : globalThis);
