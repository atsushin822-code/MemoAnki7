/* MemoAnki EX data converter - HTML tab wiring (DOM only). Uses HtmlPrep from htmlprep.js. */
(function () {
  'use strict';
  if (typeof document === 'undefined') return;
  const $ = id => document.getElementById(id);
  const OK_EXT = ['.htm', '.html', '.css', '.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.svg'];
  const MIME = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.bmp': 'image/bmp', '.svg': 'image/svg+xml' };
  let files = [], result = null;

  const extOf = n => { const i = n.lastIndexOf('.'); return i > 0 ? n.slice(i).toLowerCase() : ''; };
  const fmt = n => n < 1024 ? n + ' B' : (n / 1024).toFixed(1) + ' KB';
  function say(kind, text) { const m = $('html-msg'); m.hidden = !text; m.className = 'msg ' + kind; m.textContent = text; }

  function refresh() {
    const ul = $('html-list'); ul.textContent = '';
    files.forEach(f => { const li = document.createElement('li'); li.textContent = f.path + '(' + fmt(f.data.length) + ')'; ul.appendChild(li); });
    const hasPage = files.some(f => ['.htm', '.html'].includes(extOf(f.path)));
    $('html-go').disabled = !hasPage;
    $('html-clear').disabled = !files.length;
    if (files.length && !hasPage) say('warn', 'HTML ファイル(.html / .htm)が入っていません。');
  }

  async function addFiles(list) {                       // list: [{file, path}]
    for (const it of list) {
      if (!OK_EXT.includes(extOf(it.file.name))) continue;
      const path = it.path.replace(/\\/g, '/');
      files = files.filter(x => x.path !== path);
      files.push({ path, data: new Uint8Array(await it.file.arrayBuffer()) });
    }
    result = null; $('html-result').hidden = true; say('', '');
    refresh();
  }
  const fromInput = e => { addFiles(Array.from(e.target.files).map(f => ({ file: f, path: f.webkitRelativePath || f.name }))); e.target.value = ''; };
  $('html-files').addEventListener('change', fromInput);
  $('html-dir').addEventListener('change', fromInput);

  function readEntries(entry, prefix, acc) {
    return new Promise(resolve => {
      if (entry.isFile) { entry.file(f => { acc.push({ file: f, path: prefix + entry.name }); resolve(); }, () => resolve()); return; }
      const reader = entry.createReader(); let all = [];
      (function next() {
        reader.readEntries(async ents => {
          if (!ents.length) { for (const e of all) await readEntries(e, prefix + entry.name + '/', acc); resolve(); return; }
          all = all.concat(Array.from(ents)); next();
        }, () => resolve());
      })();
    });
  }
  const drop = $('html-drop');
  ['dragenter', 'dragover'].forEach(n => drop.addEventListener(n, e => { e.preventDefault(); drop.style.borderColor = 'var(--accent)'; }));
  ['dragleave', 'drop'].forEach(n => drop.addEventListener(n, e => { e.preventDefault(); drop.style.borderColor = ''; }));
  drop.addEventListener('drop', async e => {
    const acc = [], items = e.dataTransfer.items;
    if (items && items.length && items[0].webkitGetAsEntry) {
      for (const it of Array.from(items)) { const en = it.webkitGetAsEntry(); if (en) await readEntries(en, '', acc); }
    } else Array.from(e.dataTransfer.files).forEach(f => acc.push({ file: f, path: f.name }));
    addFiles(acc);
  });
  $('html-clear').addEventListener('click', () => { files = []; result = null; $('html-result').hidden = true; say('', ''); refresh(); });

  async function decodeImage(bytes, path) {
    const blob = new Blob([bytes], { type: MIME[extOf(path)] || '' });
    let src, w, h;
    try { src = await createImageBitmap(blob); w = src.width; h = src.height; }
    catch (_) {
      const url = URL.createObjectURL(blob);
      src = await new Promise((ok, ng) => { const im = new Image(); im.onload = () => ok(im); im.onerror = () => ng(new Error('形式が不明です')); im.src = url; });
      w = src.naturalWidth || 300; h = src.naturalHeight || 150;
    }
    const scale = (w > HtmlPrep.MAX_W || h > HtmlPrep.MAX_H) ? Math.min(HtmlPrep.MAX_W / w, HtmlPrep.MAX_H / h) : 1;
    const nw = Math.max(1, Math.floor(w * scale)), nh = Math.max(1, Math.floor(h * scale));
    const cv = document.createElement('canvas'); cv.width = nw; cv.height = nh;
    const ctx = cv.getContext('2d');
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, nw, nh);
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(src, 0, 0, nw, nh);
    const d = ctx.getImageData(0, 0, nw, nh).data, rgb = new Uint8Array(nw * nh * 3);
    for (let i = 0, j = 0; i < d.length; i += 4, j += 3) { rgb[j] = d[i]; rgb[j + 1] = d[i + 1]; rgb[j + 2] = d[i + 2]; }
    return { w: nw, h: nh, rgb };
  }

  $('html-go').addEventListener('click', async () => {
    $('html-go').disabled = true; say('note', '変換しています…');
    try { result = await HtmlPrep.convert(files, { decodeImage }); }
    catch (e) { say('warn', '変換に失敗しました: ' + (e && e.message || e)); refresh(); return; }
    const table = $('html-preview'); table.textContent = '';
    const head = document.createElement('tr');
    ['出力ファイル', '元', 'サイズ', 'メモ'].forEach(t => { const th = document.createElement('th'); th.textContent = t; head.appendChild(th); });
    table.appendChild(head);
    const warnBy = {};
    result.warnings.forEach(w => { const n = (w.match(/^([A-Z0-9_]+\.[A-Z]{3}):/) || [])[1]; if (n) (warnBy[n] = warnBy[n] || []).push(w.slice(n.length + 2)); });
    for (const r of result.rows) {
      const tr = document.createElement('tr'), a = document.createElement('a'), td = document.createElement('td');
      a.href = URL.createObjectURL(new Blob([result.files[r.name].data])); a.download = r.name; a.textContent = r.name;
      td.appendChild(a); tr.appendChild(td);
      [r.src, fmt(r.size), (r.w ? r.w + '×' + r.h + ' ' : '') + (warnBy[r.name] || []).join(' / ')].forEach(t => { const c = document.createElement('td'); c.textContent = t; tr.appendChild(c); });
      table.appendChild(tr);
    }
    const box = $('html-downloads'); box.textContent = '';
    const total = result.rows.reduce((s, r) => s + r.size, 0);
    const b = document.createElement('button'); b.type = 'button'; b.className = 'primary';
    b.textContent = 'ZIP でまとめてダウンロード(' + result.rows.length + ' ファイル / ' + fmt(total) + ')';
    b.addEventListener('click', () => {
      const zip = HtmlPrep.makeZip(result.rows.map(r => ({ name: r.name, data: result.files[r.name].data })));
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([zip], { type: 'application/zip' })); a.download = 'MEMAN_html.zip';
      document.body.appendChild(a); a.click(); a.remove();
    });
    box.appendChild(b);
    $('html-result').hidden = false;
    const others = result.warnings.filter(w => !/^[A-Z0-9_]+\.[A-Z]{3}:/.test(w));
    say(others.length ? 'note' : 'ok', others.length ? others.join('\n') : '変換しました。');
    $('html-go').disabled = false;
  });
  refresh();
})();
