/* MemoAnki EX data converter - core (no DOM). Runs in browsers and in Node (tests).
   Mirrors tools/devfmt.py, tools/anki_to_deck.py and tools/wikipedia_convert.py: outputs are byte-identical. */
const MemoCore = (() => {
  'use strict';
  const enc = new TextEncoder();
  const CARD_FIELD_BYTES = 127, DECK_NAME_BYTES = 47, MAX_IMPORT_CARDS = 600;
  const WIKI_KEY_BYTES = 31, WIKI_TITLE_BYTES = 47;

  // ---------------------------------------------------------------- bytes
  function cutUtf8(b, n) {                          // at most n bytes, never inside a character
    if (b.length <= n) return b;
    let end = n;
    while (end > 0 && (b[end] & 0xC0) === 0x80) end--;
    return b.slice(0, end);
  }
  function cmpBytes(a, b) {
    const n = Math.min(a.length, b.length);
    for (let i = 0; i < n; i++) if (a[i] !== b[i]) return a[i] - b[i];
    return a.length - b.length;
  }
  function concat(parts) {
    let n = 0; for (const p of parts) n += p.length;
    const out = new Uint8Array(n); let o = 0;
    for (const p of parts) { out.set(p, o); o += p.length; }
    return out;
  }
  const u16 = v => Uint8Array.of((v >> 8) & 255, v & 255);
  const u32 = v => Uint8Array.of((v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255);
  const pad = (b, n) => { const o = new Uint8Array(n); o.set(b.slice(0, n)); return o; };

  // ---------------------------------------------------------------- characters the device font can draw
  let fontSet = null;
  function setFontRanges(str) {                      // "00A2,00A7-00A8,..." (hex)
    fontSet = new Set();
    for (const part of str.split(',')) {
      if (!part) continue;
      const [a, b] = part.split('-');
      const lo = parseInt(a, 16), hi = b ? parseInt(b, 16) : lo;
      for (let c = lo; c <= hi; c++) fontSet.add(c);
    }
  }
  function undisplayable(texts) {                    // Map char -> count
    const bad = new Map();
    if (!fontSet) return bad;
    for (const t of texts) for (const ch of t) {
      const o = ch.codePointAt(0);
      if (o >= 0x80 && !fontSet.has(o) && !/\s/.test(ch)) bad.set(ch, (bad.get(ch) || 0) + 1);
    }
    return bad;
  }

  // ---------------------------------------------------------------- IMPORT.DAT / WIKI.DAT
  function writeImportDat(name, cards) {             // cards: [[front, back, example], ...]
    const nb = cutUtf8(enc.encode(name), DECK_NAME_BYTES);
    if (!nb.length) throw new Error('デッキ名が空です');
    if (cards.length > MAX_IMPORT_CARDS) throw new Error(`1ファイルは${MAX_IMPORT_CARDS}枚までです`);
    const parts = [enc.encode('MIM1'), Uint8Array.of(nb.length), nb, u16(cards.length)];
    for (const card of cards) for (const f of card) {
      const b = cutUtf8(enc.encode(f), CARD_FIELD_BYTES);
      parts.push(u16(b.length), b);
    }
    return concat(parts);
  }

  const KANA_ONLY = /^[ぁ-ゖー゛゜ァ-ヺ・ \u3000a-zA-Z0-9]+$/;
  const READING = /[（(]([ぁ-ゖァ-ヺー・ ]+)[、，,）)]/;
  function foldKey(s) {
    let out = '';
    for (const ch of s.normalize('NFKC')) {
      const o = ch.codePointAt(0);
      if (ch >= 'A' && ch <= 'Z') out += ch.toLowerCase();
      else if (o >= 0x30A1 && o <= 0x30F6) out += String.fromCodePoint(o - 0x60);
      else out += ch;
    }
    return out;
  }
  function guessReading(title, text) {
    if (KANA_ONLY.test(title)) return null;
    const m = READING.exec(text.slice(0, 200));
    return m ? m[1] : null;
  }
  function writeWikiDat(articles, maxBytes = 20000) {   // [{title, text, reading?}]
    const entries = []; let noReading = 0;
    for (const a of articles) {
      const title = a.title.trim();
      let text = (a.text || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n').replace(/[\u0000-\u0009\u000B-\u001F]/g, ' ');
      const reading = a.reading || guessReading(title, text);
      if (!reading && !KANA_ONLY.test(title)) noReading++;
      entries.push({
        key: cutUtf8(enc.encode(foldKey(reading || title)), WIKI_KEY_BYTES),
        title: cutUtf8(enc.encode(title), WIKI_TITLE_BYTES),
        text: cutUtf8(enc.encode(text), maxBytes)
      });
    }
    entries.sort((x, y) => cmpBytes(x.key, y.key));
    const index = [], data = []; let off = 0;
    for (const e of entries) {
      index.push(pad(e.key, 32), pad(e.title, 48), u32(off), u32(e.text.length), new Uint8Array(8));
      data.push(e.text); off += e.text.length;
    }
    const indexOff = 32, dataOff = indexOff + 96 * entries.length;
    const header = concat([enc.encode('MWK1'), u32(entries.length), u32(indexOff), u32(dataOff), new Uint8Array(16)]);
    return { bytes: concat([header, ...index, ...data]), count: entries.length, noReading };
  }

  // ---------------------------------------------------------------- text cleanup
  const NAMED = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: '\u00a0', ndash: '–', mdash: '—', hellip: '…',
    lsquo: '‘', rsquo: '’', ldquo: '“', rdquo: '”', copy: '©', reg: '®', times: '×', middot: '·', laquo: '«', raquo: '»',
    yen: '¥', deg: '°', plusmn: '±', divide: '÷', bull: '•' };
  function unescapeHtml(s) {
    return s.replace(/&(#x[0-9a-fA-F]+|#[0-9]+|[a-zA-Z]+);/g, (m, e) => {
      if (e[0] === '#') {
        const cp = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
        try { return String.fromCodePoint(cp); } catch (_) { return m; }
      }
      return Object.prototype.hasOwnProperty.call(NAMED, e) ? NAMED[e] : m;
    });
  }
  const LINE_SPLIT = /\r\n|[\n\r\v\f\x1c-\x1e\x85\u2028\u2029]/;

  function clean(text, newline = ' / ') {            // Anki field (HTML) -> one line of plain text
    let t = text.replace(/\[sound:[^\]]*\]/g, '');
    t = t.replace(/<(script|style)\b[\s\S]*?<\/\1>/gi, '');
    t = t.replace(/<br\s*\/?>|<\/(div|p|li|tr|h[1-6])>/gi, '\n');
    t = t.replace(/<[^>]+>/g, '');
    t = unescapeHtml(t).replace(/\u00a0/g, ' ');
    return t.split(LINE_SPLIT).map(l => l.replace(/[ \t\u3000]+/g, ' ').trim()).filter(l => l).join(newline);
  }

  const CLOZE_SRC = '\\{\\{c(\\d+)::([\\s\\S]*?)(?:::([\\s\\S]*?))?\\}\\}';
  function hasCloze(text) { return new RegExp(CLOZE_SRC).test(text); }
  function clozeCards(text) {                        // [[front, back], ...] one per cloze number
    const nums = [...new Set([...text.matchAll(new RegExp(CLOZE_SRC, 'g'))].map(m => parseInt(m[1], 10)))].sort((a, b) => a - b);
    return nums.map(n => {
      const answers = [];
      const front = text.replace(new RegExp(CLOZE_SRC, 'g'), (m, num, ans, hint) => {
        if (parseInt(num, 10) === n) { answers.push(ans); return `[${hint ? hint : '...'}]`; }
        return ans;
      });
      return [front, answers.join(' / ')];
    });
  }

  // Wikipedia plain text (API "extracts"): headings, dropped sections, whitespace
  const DROP_SECTIONS = new Set(['脚注', '注釈', '出典', '参考文献', '関連項目', '外部リンク', '参照', '脚注・出典', '注釈・出典',
    '関連作品', '関連書籍', '関連文献', '脚注・参考文献', '参考資料', '文献', '備考', 'references', 'external links', 'see also',
    'further reading', 'notes', 'footnotes', 'sources', 'bibliography', 'citations', 'references and notes']);
  function postprocess(t) {
    t = t.replace(/<br\s*\/?>/gi, '\n').replace(/<\/?[a-zA-Z][^>]*>/g, '');
    t = unescapeHtml(t).replace(/\u00a0/g, ' ');
    const out = []; let dropLevel = null;
    for (let ln of t.split(LINE_SPLIT)) {
      ln = ln.replace(/\s+$/, '');
      const m = /^(={2,6})\s*(.*?)\s*\1\s*$/.exec(ln);
      if (m) {
        const level = m[1].length, title = m[2];
        if (dropLevel !== null && level > dropLevel) continue;
        dropLevel = DROP_SECTIONS.has(title.trim().toLowerCase()) ? level : null;
        if (dropLevel === null && title) { out.push(''); out.push((level === 2 ? '■ ' : '□ ') + title); }
        continue;
      }
      if (dropLevel !== null) continue;
      out.push(ln);
    }
    t = out.join('\n');
    t = t.replace(/[（(][\s、,;；・]*[）)]/g, '');
    t = t.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n');
    return t.trim();
  }

  // ---------------------------------------------------------------- delimited text (CSV / TSV / Anki plain-text export)
  function parseDelimited(text, sep) {               // RFC 4180 style, quotes may contain newlines
    const rows = []; let row = [], f = '', q = false, i = 0, any = false;
    while (i < text.length) {
      const c = text[i];
      if (q) {
        if (c === '"') { if (text[i + 1] === '"') { f += '"'; i += 2; continue; } q = false; i++; continue; }
        f += c; i++; continue;
      }
      if (c === '"' && f === '') { q = true; any = true; i++; continue; }
      if (c === sep) { row.push(f); f = ''; any = true; i++; continue; }
      if (c === '\n' || c === '\r') {
        if (c === '\r' && text[i + 1] === '\n') i++;
        i++;
        if (any || f !== '' || row.length) { row.push(f); rows.push(row); }
        row = []; f = ''; any = false; continue;
      }
      f += c; any = true; i++;
    }
    if (any || f !== '' || row.length) { row.push(f); rows.push(row); }
    return rows;
  }

  function newCollection() { return { models: {}, decks: {}, notes: [] }; }

  // Anki "Notes in Plain Text" (with #header lines) or plain CSV/TSV. hasHeader: true/false/null (auto)
  function readTextExport(raw, name = 'text', hasHeader = null) {
    raw = raw.replace(/^\uFEFF/, '');
    const header = {}, body = [];
    for (const ln of raw.split(/\r?\n/)) {
      if (ln.startsWith('#') && ln.includes(':')) {
        const k = ln.slice(1, ln.indexOf(':')).trim().toLowerCase();
        header[k] = ln.slice(ln.indexOf(':') + 1).replace(/^\s+|\s+$/g, '');
      } else if (ln.trim()) body.push(ln);
    }
    const seps = { tab: '\t', comma: ',', semicolon: ';', space: ' ', pipe: '|', colon: ':' };
    let sep = seps[(header.separator || '').toLowerCase()];
    if (!sep) { const first = body[0] || ''; sep = first.includes('\t') ? '\t' : (first.includes(',') ? ',' : ';'); }
    let rows = parseDelimited(body.join('\n'), sep);
    let names = header.columns ? header.columns.split(sep) : [];
    if (!header.columns && rows.length) {            // header row such as Front,Back,Example
      const low = rows[0].map(s => s.trim().toLowerCase());
      const looks = low.includes('front') && low.includes('back');
      if (hasHeader === true || (hasHeader === null && looks)) { names = rows[0].map(s => s.trim()); rows = rows.slice(1); }
    }
    const width = rows.reduce((m, r) => Math.max(m, r.length), 0);
    for (let i = names.length; i < width; i++) names.push(`列${i + 1}`);
    const col = newCollection();
    col.models['0'] = { name: 'text', fields: names, cloze: false };
    col.decks['0'] = name;
    rows.forEach((r, i) => col.notes.push({ nid: i, model: '0', fields: r, deckIds: ['0'] }));
    return col;
  }

  // ---------------------------------------------------------------- .apkg (zip + sqlite)
  async function inflateRaw(data) {
    if (typeof DecompressionStream === 'undefined') throw new Error('このブラウザは zip の展開(DecompressionStream)に未対応です。Chrome/Edge/Safari/Firefox の新しい版をお使いください');
    const stream = new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }
  function unzip(buf) {                              // returns {names, read(name)}
    const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    let i = buf.length - 22;
    while (i >= 0 && dv.getUint32(i, true) !== 0x06054b50) i--;
    if (i < 0) throw new Error('zip ファイルではありません');
    const n = dv.getUint16(i + 10, true);
    let p = dv.getUint32(i + 16, true);
    const files = new Map(), dec = new TextDecoder();
    for (let k = 0; k < n; k++) {
      if (dv.getUint32(p, true) !== 0x02014b50) throw new Error('zip が壊れています');
      const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true);
      const nl = dv.getUint16(p + 28, true), el = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true);
      files.set(dec.decode(buf.subarray(p + 46, p + 46 + nl)), { method, csize, off: dv.getUint32(p + 42, true) });
      p += 46 + nl + el + cl;
    }
    return {
      names: [...files.keys()],
      async read(name) {
        const f = files.get(name), lo = f.off;
        const start = lo + 30 + dv.getUint16(lo + 26, true) + dv.getUint16(lo + 28, true);
        const data = buf.subarray(start, start + f.csize);
        if (f.method === 0) return data;
        if (f.method === 8) return inflateRaw(data);
        throw new Error('未対応の zip 圧縮方式です');
      }
    };
  }

  async function readApkg(buf, SQL) {
    const z = unzip(buf);
    let name;
    if (z.names.includes('collection.anki21')) name = 'collection.anki21';
    else if (z.names.includes('collection.anki21b'))
      throw new Error('新形式の .apkg (collection.anki21b) は読めません。Anki で書き出すとき「古いバージョンの Anki をサポート」にチェックを入れるか、「ノートをプレーンテキストで書き出し」を使ってください。');
    else if (z.names.includes('collection.anki2')) name = 'collection.anki2';
    else throw new Error('Anki のデータ(collection.*)が見つかりません');
    const db = new SQL.Database(await z.read(name));
    try {
      const col = newCollection();
      const all = (sql) => { const r = db.exec(sql); return r.length ? r[0].values : []; };
      const tables = new Set(all("select name from sqlite_master where type='table'").map(r => r[0]));
      if (tables.has('notetypes')) {                 // new schema
        for (const [id, nm] of all('select id, name from notetypes')) col.models[String(id)] = { name: nm, fields: [], cloze: false };
        for (const [ntid, , nm] of all('select ntid, ord, name from fields order by ntid, ord')) col.models[String(ntid)].fields.push(nm);
        for (const [id, nm] of all('select id, name from decks')) col.decks[String(id)] = String(nm).replace(/\x1f/g, '::');
      } else {                                       // legacy schema: JSON in col
        const [models, decks] = all('select models, decks from col')[0];
        for (const [mid, m] of Object.entries(JSON.parse(models))) {
          col.models[mid] = { name: m.name, fields: [...m.flds].sort((a, b) => a.ord - b.ord).map(f => f.name), cloze: m.type === 1 };
        }
        for (const [did, d] of Object.entries(JSON.parse(decks))) col.decks[did] = d.name;
      }
      const cardsOf = new Map();
      const hasOdid = all('pragma table_info(cards)').some(r => r[1] === 'odid');
      for (const [nid, did, odid] of all(`select nid, did, ${hasOdid ? 'odid' : '0'} from cards`)) {
        const k = String(nid); if (!cardsOf.has(k)) cardsOf.set(k, new Set());
        cardsOf.get(k).add(String(odid || did));
      }
      for (const [nid, mid, flds] of all('select id, mid, flds from notes order by id'))
        col.notes.push({ nid, model: String(mid), fields: String(flds).split('\x1f'), deckIds: [...(cardsOf.get(String(nid)) || [])] });
      return col;
    } finally { db.close(); }
  }

  // ---------------------------------------------------------------- selecting cards
  const deckMatches = (name, wanted) => name === wanted || name.startsWith(wanted + '::') || name.toLowerCase().includes(wanted.toLowerCase());

  // opts: {deck, model, front, back, example (0-based index or null), newline}
  function buildCards(col, opts) {
    const cards = [], seen = new Set(); let skipped = 0;
    const nl = opts.newline === undefined ? ' / ' : opts.newline;
    for (const note of col.notes) {
      const model = col.models[note.model] || { name: '?', fields: [], cloze: false };
      if (opts.model && !model.name.toLowerCase().includes(opts.model.toLowerCase())) continue;
      if (opts.deck && !note.deckIds.some(d => deckMatches(col.decks[d] || '', opts.deck))) continue;
      const fi = opts.front === undefined ? 0 : opts.front;
      const bi = opts.back === undefined ? 1 : opts.back;
      const ei = opts.example === undefined ? 2 : opts.example;
      const get = i => (i !== null && i >= 0 && i < note.fields.length) ? note.fields[i] : '';
      let pairs;
      if (hasCloze(get(fi))) {
        const extra = clean(get(bi !== null ? bi : 1));
        pairs = clozeCards(get(fi)).map(([f, b]) => [clean(f, nl), clean(b, nl), extra]);
      } else {
        const front = clean(get(fi), nl), back = clean(get(bi), nl);
        if (!front || !back) { skipped++; continue; }
        pairs = [[front, back, (ei !== null && ei !== fi && ei !== bi) ? clean(get(ei), nl) : '']];
      }
      for (const p of pairs) {
        const key = p[0] + '\u0000' + p[1];
        if (seen.has(key)) continue;
        seen.add(key); cards.push(p);
      }
    }
    return { cards, skipped };
  }

  // ---------------------------------------------------------------- Wikipedia
  const wikiUrl = (lang, title) => `https://${lang}.wikipedia.org/wiki/${encodeURIComponent(title.replace(/ /g, '_'))}`;
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // Titles -> articles through the Wikipedia API (one request per title, polite delay).
  async function fetchArticles(titles, o = {}) {
    const lang = o.lang || 'ja', fetchFn = o.fetchFn || ((...a) => fetch(...a));
    const base = o.apiBase || `https://${lang}.wikipedia.org/w/api.php`;
    const articles = [], errors = [];
    for (let i = 0; i < titles.length; i++) {
      if (o.signal && o.signal.aborted) break;
      const title = titles[i];
      if (o.onProgress) o.onProgress(i, titles.length, title);
      try {
        const q = new URLSearchParams({ action: 'query', format: 'json', prop: 'extracts', explaintext: '1', redirects: '1',
          titles: title, formatversion: '2', origin: '*' });
        const res = await fetchFn(`${base}?${q}`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        if (data.error) throw new Error(data.error.info || data.error.code);
        let pages = (data.query && data.query.pages) || [];
        if (!Array.isArray(pages)) pages = Object.values(pages);
        let got = false;
        for (const pg of pages) {
          if (pg.missing || !pg.extract) continue;
          const t = pg.title || title;
          articles.push({ title: t, text: postprocess(pg.extract), url: wikiUrl(lang, t) });
          got = true;
        }
        if (!got) errors.push(`「${title}」の記事が見つかりません`);
      } catch (e) { errors.push(`「${title}」: ${e.message}`); }
      if (o.delayMs && i + 1 < titles.length) await sleep(o.delayMs);
    }
    return { articles, errors };
  }

  function sourcesText(articles, lang) {
    let s = `Text in WIKI.DAT comes from Wikipedia (${lang}) and is available under CC BY-SA 4.0:\n` +
      'https://creativecommons.org/licenses/by-sa/4.0/ . Authors: see each article\'s history.\n' +
      'Text was converted to plain text and may be shortened.\n\n';
    for (const a of articles) s += `${a.title}\t${a.url}\n`;
    return s;
  }

  function parseJsonl(text) {
    return text.split(/\r?\n/).filter(l => l.trim()).map((l, i) => {
      let o; try { o = JSON.parse(l); } catch (e) { throw new Error(`${i + 1}行目が JSON ではありません`); }
      if (!o.title) throw new Error(`${i + 1}行目に title がありません`);
      return o;
    });
  }

  // Shift_JIS fallback for CSV saved by Excel without "UTF-8"
  function decodeText(bytes) {
    try { return { text: new TextDecoder('utf-8', { fatal: true }).decode(bytes), encoding: 'UTF-8' }; }
    catch (_) { return { text: new TextDecoder('shift_jis').decode(bytes), encoding: 'Shift_JIS' }; }
  }

  return { cutUtf8, setFontRanges, undisplayable, writeImportDat, writeWikiDat, foldKey, guessReading, clean, clozeCards, hasCloze,
    postprocess, parseDelimited, readTextExport, readApkg, unzip, buildCards, fetchArticles, sourcesText, parseJsonl, decodeText,
    MAX_IMPORT_CARDS };
})();
if (typeof globalThis !== 'undefined') globalThis.MemoCore = MemoCore;
