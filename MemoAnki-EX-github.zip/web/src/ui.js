/* MemoAnki EX data converter - page wiring (DOM only). */
(function () {
  'use strict';
  if (typeof document === 'undefined') return;
  const C = MemoCore;
  const $ = id => document.getElementById(id);
  const enc = new TextEncoder();

  // ------------------------------------------------------------ helpers
  function showMsg(el, kind, text) { el.className = 'msg ' + kind; el.textContent = text; el.hidden = false; }
  function addMsg(parent, kind, text) {
    const d = document.createElement('div'); d.className = 'msg ' + kind; d.textContent = text; parent.appendChild(d);
  }
  function download(name, data) {
    const blob = new Blob([data], { type: 'application/octet-stream' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }
  function dlButton(parent, label, name, data) {
    const b = document.createElement('button'); b.type = 'button'; b.className = 'primary'; b.textContent = label;
    b.addEventListener('click', () => download(name, data)); parent.appendChild(b);
  }
  function fillTable(table, head, rows) {
    table.textContent = '';
    const tr = document.createElement('tr');
    for (const h of head) { const th = document.createElement('th'); th.textContent = h; tr.appendChild(th); }
    table.appendChild(tr);
    for (const r of rows) {
      const row = document.createElement('tr');
      for (const c of r) { const td = document.createElement('td'); td.textContent = c; row.appendChild(td); }
      table.appendChild(row);
    }
  }
  function setOptions(sel, items, selected) {          // items: [[value, label]]
    sel.textContent = '';
    for (const [v, l] of items) { const o = document.createElement('option'); o.value = v; o.textContent = l; sel.appendChild(o); }
    if (selected !== undefined) sel.value = String(selected);
  }
  function reportUndisplayable(parent, texts) {
    const bad = C.undisplayable(texts);
    if (bad.size) {
      const list = [...bad.entries()].sort((a, b) => b[1] - a[1]).slice(0, 40).map(e => e[0]).join(' ');
      let n = 0; for (const v of bad.values()) n += v;
      addMsg(parent, 'note', `辞書の内蔵フォントで出せない文字が ${n} 個(${bad.size} 種類)あり、辞書では「?」になります:\n${list}`);
    }
  }

  // ------------------------------------------------------------ tabs
  const tabs = ['deck', 'wiki', 'html', 'help'];
  for (const t of tabs) $('tab-' + t).addEventListener('click', () => {
    for (const u of tabs) { $('tab-' + u).setAttribute('aria-selected', String(u === t)); $('panel-' + u).hidden = u !== t; }
  });

  // ------------------------------------------------------------ sql.js (only needed for .apkg)
  let sqlPromise = null;
  function loadScript(src) {
    return new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = () => rej(new Error('load ' + src)); document.head.appendChild(s); });
  }
  function ensureSql() {
    if (sqlPromise) return sqlPromise;
    sqlPromise = (async () => {
      if (typeof initSqlJs !== 'undefined') return initSqlJs();
      const CDN = 'https://cdn.jsdelivr.net/npm/sql.js@1.10.3/dist/';
      for (const base of ['./', CDN]) {
        try { await loadScript(base + 'sql-wasm.js'); return await initSqlJs({ locateFile: f => base + f }); } catch (_) { /* try next */ }
      }
      throw new Error('.apkg を読むための SQLite(sql.js)を読み込めません。sql-wasm.js と sql-wasm.wasm を index.html と同じ場所に置いてください。');
    })();
    sqlPromise.catch(() => { sqlPromise = null; });
    return sqlPromise;
  }

  // ------------------------------------------------------------ deck tab
  let col = null, kind = '', stem = '', lastText = null;

  function stemOf(name) { return name.replace(/\.[^.]*$/, ''); }

  function usedModels() { return Object.entries(col.models).filter(([id]) => col.notes.some(n => n.model === id)); }

  function currentFieldNames() {
    const sel = $('deck-model').value;
    const used = usedModels();
    let m = null;
    if (sel !== '') m = col.models[sel];
    else if (used.length === 1) m = used[0][1];
    if (m) return m.fields;
    const max = col.notes.reduce((a, n) => Math.max(a, n.fields.length), 0);
    return Array.from({ length: max }, (_, i) => `フィールド ${i + 1}`);
  }

  function refreshFieldSelects() {
    const names = currentFieldNames();
    const items = names.map((n, i) => [String(i), `${i + 1}: ${n}`]);
    setOptions($('deck-front'), items); setOptions($('deck-back'), items);
    setOptions($('deck-example'), [['-1', '(なし)'], ...items]);
    $('deck-front').value = '0';
    $('deck-back').value = names.length > 1 ? '1' : '0';
    $('deck-example').value = names.length > 2 ? '2' : '-1';
  }

  function afterLoad(info) {
    const decks = Object.entries(col.decks).map(([id, name]) => [id, name, col.notes.filter(n => n.deckIds.includes(id)).length]).filter(d => d[2] > 0);
    const used = usedModels();
    setOptions($('deck-deck'), [['', `すべて(${col.notes.length} ノート)`], ...decks.sort((a, b) => a[1].localeCompare(b[1])).map(d => [d[1], `${d[1]}  (${d[2]})`])]);
    setOptions($('deck-model'), [['', 'すべて'], ...used.map(([id, m]) => [id, `${m.name}  (${col.notes.filter(n => n.model === id).length})${m.cloze ? ' [穴埋め]' : ''}`])]);
    $('deck-deck-wrap').hidden = kind !== 'apkg';
    $('deck-model-wrap').hidden = kind !== 'apkg' || used.length < 2;
    $('deck-header-wrap').hidden = kind !== 'text';
    if (kind === 'text') $('deck-header').checked = col.__header;
    refreshFieldSelects();
    $('deck-name').value = decks.length === 1 || kind === 'text' ? (kind === 'text' ? stem : decks[0][1].split('::').pop()) : stem;
    $('deck-options').hidden = false; $('deck-result').hidden = true;
    showMsg($('deck-load-msg'), 'ok', info);
  }

  async function loadFile(file) {
    try {
      const buf = new Uint8Array(await file.arrayBuffer());
      stem = stemOf(file.name);
      if (/\.apkg$/i.test(file.name)) {
        showMsg($('deck-load-msg'), 'note', 'Anki パッケージを読み込み中…');
        col = await C.readApkg(buf, await ensureSql()); kind = 'apkg'; lastText = null;
        afterLoad(`Anki パッケージ「${file.name}」: ${col.notes.length} ノート、${Object.keys(col.decks).length} デッキ`);
      } else {
        const { text, encoding } = C.decodeText(buf);
        loadText(text, stem, `「${file.name}」(${encoding})`);
      }
    } catch (e) { showMsg($('deck-load-msg'), 'warn', '読み込めませんでした: ' + e.message); $('deck-options').hidden = true; }
  }

  function loadText(text, name, label, header) {
    lastText = { text, name, label };
    col = C.readTextExport(text, name, header === undefined ? null : header);
    col.__header = header === undefined ? (col.models['0'].fields[0] !== '列1') : header;
    kind = 'text'; stem = name;
    afterLoad(`${label}: ${col.notes.length} 行を読み込みました`);
  }

  $('deck-file').addEventListener('change', e => { if (e.target.files[0]) loadFile(e.target.files[0]); });
  $('deck-paste-go').addEventListener('click', () => {
    try { loadText($('deck-paste').value, '貼り付け', '貼り付けた内容'); }
    catch (e) { showMsg($('deck-load-msg'), 'warn', '読み込めませんでした: ' + e.message); }
  });
  $('deck-model').addEventListener('change', () => refreshFieldSelects());
  $('deck-header').addEventListener('change', () => { if (lastText) loadText(lastText.text, lastText.name, lastText.label, $('deck-header').checked); });

  $('deck-convert').addEventListener('click', () => {
    const res = $('deck-result-msg'); res.textContent = ''; $('deck-downloads').textContent = '';
    try {
      const opt = {
        deck: $('deck-deck').value || undefined, model: $('deck-model').value ? col.models[$('deck-model').value].name : undefined,
        front: +$('deck-front').value, back: +$('deck-back').value, example: +$('deck-example').value < 0 ? null : +$('deck-example').value,
        newline: $('deck-newline').value
      };
      const { cards, skipped } = C.buildCards(col, opt);
      if (!cards.length) { addMsg(res, 'warn', 'カードが1枚もありません。デッキ・フィールドの選択を確認してください。'); $('deck-result').hidden = false; fillTable($('deck-preview'), [], []); return; }
      const name = $('deck-name').value.trim() || stem;
      const batches = [];
      for (let i = 0; i < cards.length; i += C.MAX_IMPORT_CARDS) batches.push(cards.slice(i, i + C.MAX_IMPORT_CARDS));
      addMsg(res, 'ok', `${cards.length} 枚のカードを作りました(デッキ名「${name}」)。` + (batches.length > 1 ? `\n600枚ずつ ${batches.length} 個のファイルに分けています。` : ''));
      if (skipped) addMsg(res, 'note', `表または裏が空のため ${skipped} 件を除外しました。`);
      let longFields = 0;
      for (const c of cards) for (const f of c) if (enc.encode(f).length > 127) longFields++;
      if (longFields) addMsg(res, 'note', `${longFields} 個の欄が127バイトを超えており、辞書側で切り詰められます。`);
      if (enc.encode(name).length > 47) addMsg(res, 'note', 'デッキ名が47バイトを超えるため、後ろが切り詰められます。');
      reportUndisplayable(res, cards.flat());
      batches.forEach((b, i) => {
        const file = i === 0 ? 'IMPORT.DAT' : `IMPORT${i + 1}.DAT`;
        dlButton($('deck-downloads'), `${file} をダウンロード(${i * 600 + 1}〜${i * 600 + b.length} 枚目)`, file, C.writeImportDat(name, b));
      });
      fillTable($('deck-preview'), ['表', '裏', '例文'], cards.slice(0, 8));
      $('deck-result').hidden = false;
    } catch (e) { addMsg(res, 'warn', '変換に失敗しました: ' + e.message); $('deck-result').hidden = false; }
  });

  // ------------------------------------------------------------ wikipedia tab
  const radios = document.querySelectorAll('input[name=wiki-mode]');
  for (const r of radios) r.addEventListener('change', () => {
    const m = document.querySelector('input[name=wiki-mode]:checked').value;
    $('wiki-titles-box').hidden = m !== 'titles'; $('wiki-jsonl-box').hidden = m !== 'jsonl';
  });
  $('wiki-jsonl-file').addEventListener('change', async e => { if (e.target.files[0]) $('wiki-jsonl').value = C.decodeText(new Uint8Array(await e.target.files[0].arrayBuffer())).text; });

  let abort = null;
  function finishWiki(articles, errors, lang) {
    const box = $('wiki-msgs'); box.textContent = '';
    for (const e of errors) addMsg(box, 'note', e);
    if (!articles.length) { addMsg(box, 'warn', '記事を1件も作れませんでした。'); $('wiki-result').hidden = true; return; }
    const { bytes, count, noReading } = C.writeWikiDat(articles, +$('wiki-max').value);
    const res = $('wiki-result-msg'); res.textContent = ''; $('wiki-downloads').textContent = '';
    addMsg(res, 'ok', `${count} 件の記事を WIKI.DAT にしました(${(bytes.length / 1024).toFixed(0)} KB)。`);
    if (noReading) addMsg(res, 'note', `${noReading} 件は漢字の題名で読みが見つからず、入力検索ができません(一覧のスクロールでは読めます)。\nJSONL に reading(ひらがな)を付けると検索できます。`);
    reportUndisplayable(res, articles.map(a => a.title + a.text));
    dlButton($('wiki-downloads'), 'WIKI.DAT をダウンロード', 'WIKI.DAT', bytes);
    if (articles[0].url) dlButton($('wiki-downloads'), 'WIKI_SOURCES.txt(出典)をダウンロード', 'WIKI_SOURCES.txt', C.sourcesText(articles, lang));
    fillTable($('wiki-preview'), ['題名', '文字数', '先頭'], articles.slice(0, 10).map(a => [a.title, String(a.text.length), a.text.replace(/\s+/g, ' ').slice(0, 50)]));
    $('wiki-result').hidden = false;
  }

  $('wiki-cancel').addEventListener('click', () => { if (abort) abort.abort(); });
  $('wiki-go').addEventListener('click', async () => {
    $('wiki-msgs').textContent = ''; $('wiki-result').hidden = true;
    const mode = document.querySelector('input[name=wiki-mode]:checked').value;
    const lang = $('wiki-lang').value.trim() || 'ja';
    if (mode === 'jsonl') {
      try { finishWiki(C.parseJsonl($('wiki-jsonl').value), [], lang); }
      catch (e) { addMsg($('wiki-msgs'), 'warn', e.message); }
      return;
    }
    const titles = $('wiki-titles').value.split(/\r?\n/).map(s => s.trim()).filter(s => s && !s.startsWith('#'));
    if (!titles.length) { addMsg($('wiki-msgs'), 'warn', '記事名を入力してください。'); return; }
    if (titles.length > 200) { addMsg($('wiki-msgs'), 'warn', '一度に取得できるのは200件までです。分けて実行してください。'); return; }
    abort = new AbortController();
    $('wiki-go').disabled = true; $('wiki-cancel').hidden = false; $('wiki-progress').hidden = false;
    try {
      const { articles, errors } = await C.fetchArticles(titles, {
        lang, apiBase: $('wiki-api').value.trim() || undefined, delayMs: 300, signal: abort.signal,
        onProgress: (i, n, t) => { $('wiki-progress').max = n; $('wiki-progress').value = i; $('wiki-status').textContent = `取得中 ${i + 1} / ${n}: ${t}`; }
      });
      if (abort.signal.aborted) errors.push('中止しました(ここまでの分で作成します)');
      finishWiki(articles, errors, lang);
    } catch (e) { addMsg($('wiki-msgs'), 'warn', '取得に失敗しました: ' + e.message); }
    finally { $('wiki-go').disabled = false; $('wiki-cancel').hidden = true; $('wiki-progress').hidden = true; $('wiki-status').textContent = ''; abort = null; }
  });
})();
