#!/usr/bin/env python3
"""Assemble web/index.html (single file) from web/src/{template.html,core.js,ui.js} and tools/jfont_cp.txt."""
from pathlib import Path

here = Path(__file__).resolve().parent
cps = sorted({int(x, 16) for line in (here.parent / "tools" / "jfont_cp.txt").read_text().splitlines()
              if not line.startswith("#") for x in line.split()})
ranges, start, prev = [], cps[0], cps[0]
for c in cps[1:] + [None]:
    if c is not None and c == prev + 1:
        prev = c
        continue
    ranges.append("%04X" % start if start == prev else "%04X-%04X" % (start, prev))
    if c is not None:
        start = prev = c
t = (here / "src" / "template.html").read_text(encoding="utf-8")
t = t.replace("/*FONT_RANGES*/", "var MemoFontRanges = '%s';" % ",".join(ranges))
t = t.replace("/*CORE*/", (here / "src" / "core.js").read_text(encoding="utf-8"))
t = t.replace("/*UI*/", "MemoCore.setFontRanges(MemoFontRanges);\n" + (here / "src" / "ui.js").read_text(encoding="utf-8"))
(here / "index.html").write_text(t, encoding="utf-8")
print("wrote web/index.html (%d bytes, %d font ranges)" % (len(t.encode()), len(ranges)))
