/* Tests for the web converter. Needs: npm install (jsdom, sql.js). Run: node web/tests/run.js
   Core: JS output must be byte-identical to the Python tools. UI: jsdom with mocked fetch/downloads. */
const fs = require('fs'), path = require('path'), vm = require('vm'), os = require('os');
const { execFileSync } = require('child_process');
const root = path.resolve(__dirname, '..', '..');
const initSqlJs = require('sql.js');

let failed = 0, passed = 0;
const ok = (c, msg) => { if (c) passed++; else { failed++; console.log('FAIL:', msg); } };
const eqBytes = (a, b) => Buffer.compare(Buffer.from(a), Buffer.from(b)) === 0;
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'webtest-'));
const py = (code, ...args) => execFileSync('python3', ['-c', code, ...args], { cwd: root, encoding: 'utf8' });

// load core.js into a context (browser-like globals)
const ctx = { TextEncoder, TextDecoder, DecompressionStream, Blob, Response, console, setTimeout, URLSearchParams };
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(root, 'web/src/core.js'), 'utf8'), ctx);
const C = ctx.MemoCore;
C.setFontRanges(fs.readFileSync(path.join(root, 'web/index.html'), 'utf8').match(/MemoFontRanges = '([^']*)'/)[1]);

(async () => {
  const SQL = await initSqlJs();

  // ---- CSV -> IMPORT.DAT (vs tools/csv_to_deck.py)
  const csvs = {
    sample: fs.readFileSync(path.join(root, 'data/decks/sample.csv'), 'utf8'),
    tricky: 'Front,Back,Example\n"run, ran","走る\n(過去形は ran)","She said ""hi"""\nachieve,達成する,\n' + 'x,' + 'あ'.repeat(60) + ',y\n'
  };
  for (const [name, text] of Object.entries(csvs)) {
    const f = path.join(tmp, name + '.csv'); fs.writeFileSync(f, text);
    const out = path.join(tmp, name + '.py.DAT');
    execFileSync('python3', ['tools/csv_to_deck.py', f, '--deck', '英単語', '--dat', out], { cwd: root });
    const col = C.readTextExport(text, name);
    const { cards } = C.buildCards(col, { newline: '' });                // csv_to_deck keeps field text as is
    // csv_to_deck does not clean fields; compare on content without newlines
    const js = C.writeImportDat('英単語', cards.map(c => c));
    if (name === 'sample') ok(eqBytes(js, fs.readFileSync(out)), 'csv sample: JS == Python bytes');
    else {
      const rows = cards.length; ok(rows === 3, 'tricky csv: 3 cards, got ' + rows);
      ok(cards[0][0] === 'run, ran' && cards[0][2] === 'She said "hi"', 'tricky csv: quotes');
      ok(cards[0][1] === '走る(過去形は ran)', 'tricky csv: newline in field -> joined: ' + cards[0][1]);
    }
  }
  ok(C.readTextExport('a,b\n1,2\n', 'x').notes.length === 2, 'no header: both rows are cards');
  ok(C.readTextExport('Front,Back\n1,2\n', 'x').notes.length === 1, 'header row detected');

  // ---- Anki text export (vs tools/anki_to_deck.py)
  const txt = '#separator:tab\n#html:true\n#columns:Front\tBack\tTags\n犬\t<div>dog</div>\tanimals\n猫\tcat\tanimals\n';
  const tf = path.join(tmp, 'notes.txt'); fs.writeFileSync(tf, txt);
  execFileSync('python3', ['tools/anki_to_deck.py', tf, '--name', '動物', '-o', path.join(tmp, 'notes.py.DAT')], { cwd: root });
  ok(eqBytes(C.writeImportDat('動物', C.buildCards(C.readTextExport(txt, 'notes'), {}).cards), fs.readFileSync(path.join(tmp, 'notes.py.DAT'))), 'anki text export: JS == Python');

  // ---- .apkg (synthetic, made by the Python tests) vs tools/anki_to_deck.py
  const apkg = path.join(tmp, 'a.apkg');
  py("import sys; sys.path.insert(0,'tools/tests'); sys.path.insert(0,'tools'); from test_tools import make_apkg; make_apkg(sys.argv[1])", apkg);
  execFileSync('python3', ['tools/anki_to_deck.py', apkg, '--deck', '英語', '-o', path.join(tmp, 'a.py.DAT')], { cwd: root });
  const colA = await C.readApkg(new Uint8Array(fs.readFileSync(apkg)), SQL);
  ok(Object.keys(colA.decks).length === 2 && colA.notes.length === 6, 'apkg: decks/notes read');
  const built = C.buildCards(colA, { deck: '英語' });
  ok(eqBytes(C.writeImportDat('英語', built.cards), fs.readFileSync(path.join(tmp, 'a.py.DAT'))), 'apkg: JS == Python bytes');
  ok(built.cards.length === 5 && built.skipped === 1, `apkg: 5 cards, 1 skipped (got ${built.cards.length}/${built.skipped})`);
  ok(built.cards[0][1] === '捨てる / 放棄する' && built.cards[0][2] === 'He abandoned it.', 'apkg: html/sound cleaned');
  ok(built.cards.some(c => c[0] === '日本の首都は[...]で、人口は約1400万人。' && c[1] === '東京'), 'apkg: cloze 1');
  ok(built.cards.some(c => c[0] === '日本の首都は東京で、人口は[数]。'), 'apkg: cloze 2 with hint');
  const only = C.buildCards(colA, { deck: '地名' });
  ok(only.cards.length === 1 && only.cards[0][0] === '富士山', 'apkg: deck filter');

  // deflate-compressed package (real Anki exports are compressed)
  const apkgZ = path.join(tmp, 'az.apkg');
  py("import sys, zipfile; src=zipfile.ZipFile(sys.argv[1]); z=zipfile.ZipFile(sys.argv[2],'w',zipfile.ZIP_DEFLATED); [z.writestr(n, src.read(n)) for n in src.namelist()]; z.close()", apkg, apkgZ);
  const colZ = await C.readApkg(new Uint8Array(fs.readFileSync(apkgZ)), SQL);
  ok(eqBytes(C.writeImportDat('英語', C.buildCards(colZ, { deck: '英語' }).cards), fs.readFileSync(path.join(tmp, 'a.py.DAT'))), 'apkg (deflate): JS == Python bytes');

  // new-format only package -> clear error
  const zipOnly21b = path.join(tmp, 'b.apkg');
  py("import sys, zipfile; z=zipfile.ZipFile(sys.argv[1],'w'); z.writestr('collection.anki21b',b'x'); z.writestr('collection.anki2',b'dummy'); z.close()", zipOnly21b);
  try { await C.readApkg(new Uint8Array(fs.readFileSync(zipOnly21b)), SQL); ok(false, 'anki21b should be rejected'); }
  catch (e) { ok(/古いバージョン/.test(e.message), 'anki21b: helpful error'); }

  // ---- WIKI.DAT (vs tools/wikipedia_prepare.py)
  const jl = fs.readFileSync(path.join(root, 'data/wikipedia/sample.jsonl'), 'utf8');
  execFileSync('python3', ['tools/wikipedia_prepare.py', 'data/wikipedia/sample.jsonl', '-o', path.join(tmp, 'w.py.DAT')], { cwd: root });
  const wk = C.writeWikiDat(C.parseJsonl(jl), 20000);
  ok(eqBytes(wk.bytes, fs.readFileSync(path.join(tmp, 'w.py.DAT'))), 'wiki sample: JS == Python bytes');
  ok(wk.count === 9, 'wiki sample: 9 articles');
  for (const mb of [30, 300]) {                                         // truncation on character boundaries
    execFileSync('python3', ['tools/wikipedia_prepare.py', 'data/wikipedia/sample.jsonl', '-o', path.join(tmp, 'w2.py.DAT'), '--max-bytes', String(mb)], { cwd: root });
    ok(eqBytes(C.writeWikiDat(C.parseJsonl(jl), mb).bytes, fs.readFileSync(path.join(tmp, 'w2.py.DAT'))), `wiki max-bytes ${mb}: JS == Python`);
  }
  const kanaSort = C.writeWikiDat([{ title: 'ん', text: 'x' }, { title: 'Zebra', text: 'x' }, { title: 'あ', text: 'x' }, { title: 'カメラ', text: 'x' }]);
  ok(kanaSort.count === 4, 'wiki: 4 entries');

  // ---- postprocess (vs tools/wikipedia_convert.py)
  const samples = ['富士山(ふじさん)は山。\n\n\n== 歴史 ==\n昔。\n=== 小 ===\nx\n== 外部リンク ==\nlink\n=== 下位 ===\ny\n== 終 ==\nz',
    'A &amp; B&nbsp;C <br> D ( ) E （、）', 'Plain text only.'];
  for (const s of samples) {
    const pyOut = py("import sys; sys.path.insert(0,'tools'); import wikipedia_convert as w; sys.stdout.write(w.postprocess(sys.argv[1]))", s);
    ok(C.postprocess(s) === pyOut, 'postprocess equal for: ' + JSON.stringify(s.slice(0, 20)));
  }

  // ---- fetchArticles with a mocked API
  const seen = [];
  const fetchFn = async (url) => {
    const u = new URL(url); seen.push(u.searchParams.get('titles') + '|' + u.searchParams.get('origin'));
    const t = u.searchParams.get('titles');
    const body = t === '無い' ? { query: { pages: [{ title: t, missing: true }] } }
      : t === 'エラー' ? { error: { code: 'ratelimited', info: 'too many' } }
      : { query: { pages: [{ title: t, extract: `${t}(よみ)の説明です。` + 'とても長い。'.repeat(10) + '\n\n== 歴史 ==\n昔の話。\n== 関連項目 ==\n別' }] } };
    return { ok: true, json: async () => body };
  };
  const fr = await C.fetchArticles(['桜', '無い', 'エラー'], { lang: 'ja', fetchFn, delayMs: 0 });
  ok(fr.articles.length === 1 && fr.articles[0].title === '桜', 'fetch: one article');
  ok(fr.errors.length === 2 && /見つかりません/.test(fr.errors[0]) && /too many/.test(fr.errors[1]), 'fetch: errors reported');
  ok(seen.every(s => s.endsWith('|*')), 'fetch: origin=* (CORS) sent');
  ok(!fr.articles[0].text.includes('別') && fr.articles[0].text.includes('■ 歴史'), 'fetch: sections processed');
  ok(fr.articles[0].url === 'https://ja.wikipedia.org/wiki/%E6%A1%9C', 'fetch: url');
  const ac = new AbortController(); ac.abort();
  ok((await C.fetchArticles(['a'], { fetchFn, signal: ac.signal })).articles.length === 0, 'fetch: abort');

  // ---- Shift_JIS fallback
  const sjis = new Uint8Array([0x93, 0xfa, 0x96, 0x7b, 0x8c, 0xea]);      // 日本語 in Shift_JIS
  const dtxt = C.decodeText(sjis);
  ok(dtxt.text === '日本語' && dtxt.encoding === 'Shift_JIS', 'Shift_JIS detected');

  // ---- font check
  ok(C.undisplayable(['漢字ひらがな abc']).size === 0 && C.undisplayable(['😀']).has('😀'), 'font check');

  // ================= UI (jsdom) =================
  const { JSDOM } = require('jsdom');
  const html = fs.readFileSync(path.join(root, 'web/index.html'), 'utf8');
  const downloads = [];
  const dom = new JSDOM(html, {
    runScripts: 'dangerously', pretendToBeVisual: true,
    beforeParse(win) {
      win.TextEncoder = TextEncoder; win.TextDecoder = TextDecoder; win.DecompressionStream = DecompressionStream;
      win.initSqlJs = initSqlJs;
      win.URL.createObjectURL = blob => { downloads.push(blob); return 'blob:test'; };
      win.URL.revokeObjectURL = () => {};
      win.HTMLAnchorElement.prototype.click = function () {};
      win.fetchCalls = [];
      win.fetch = async (url) => { win.fetchCalls.push(url); return fetchFn(url); };
    }
  });
  const w = dom.window, d = w.document, $ = id => d.getElementById(id);
  const click = id => $(id).dispatchEvent(new w.Event('click', { bubbles: true }));
  const readBlob = b => new Promise(res => { const r = new w.FileReader(); r.onload = () => res(Buffer.from(r.result)); r.readAsArrayBuffer(b); });
  const fire = (el, ev) => el.dispatchEvent(new w.Event(ev, { bubbles: true }));

  ok(typeof w.MemoCore === 'object', 'ui: core loaded in page');
  // tabs
  click('tab-wiki'); ok(!$('panel-wiki').hidden && $('panel-deck').hidden, 'ui: tab switch'); click('tab-deck');
  // paste CSV -> options -> convert -> download
  $('deck-paste').value = csvs.sample; click('deck-paste-go');
  ok(!$('deck-options').hidden && /5 行/.test($('deck-load-msg').textContent), 'ui: csv loaded: ' + $('deck-load-msg').textContent);
  ok($('deck-header').checked, 'ui: header detected');
  ok($('deck-front').options.length === 3 && $('deck-front').options[0].textContent.includes('Front'), 'ui: field names from header');
  $('deck-name').value = '英単語'; click('deck-convert');
  ok($('deck-downloads').querySelectorAll('button').length === 1, 'ui: one download button');
  $('deck-downloads').querySelector('button').dispatchEvent(new w.Event('click'));
  ok(downloads.length === 1 && eqBytes(await readBlob(downloads[0]), fs.readFileSync(path.join(tmp, 'sample.py.DAT'))), 'ui: downloaded IMPORT.DAT == Python output');
  ok($('deck-preview').rows.length === 6, 'ui: preview rows');
  // 1300 cards -> 3 files
  const big = 'Front,Back\n' + Array.from({ length: 1300 }, (_, i) => `w${i},m${i}`).join('\n');
  $('deck-paste').value = big; click('deck-paste-go'); click('deck-convert');
  ok($('deck-downloads').querySelectorAll('button').length === 3, 'ui: 1300 cards -> 3 files: ' + $('deck-downloads').querySelectorAll('button').length);
  // an unprintable char warning
  $('deck-paste').value = 'Front,Back\na,😀\n'; click('deck-paste-go'); click('deck-convert');
  ok(/出せない文字/.test($('deck-result-msg').textContent), 'ui: undisplayable warning');
  // empty selection
  $('deck-paste').value = 'Front,Back\n,\n'; click('deck-paste-go'); click('deck-convert');
  ok(/1枚もありません/.test($('deck-result-msg').textContent), 'ui: no cards message');

  // choose an .apkg file in the page (deflate-compressed), pick a deck, convert, compare with Python
  const JBlob = w.Blob;
  w.Blob = Blob; w.Response = Response;                                   // jsdom's Blob has no stream(); browsers do
  const fakeFile = { name: 'a.apkg', arrayBuffer: async () => { const b = fs.readFileSync(apkgZ); return b.buffer.slice(b.byteOffset, b.byteOffset + b.length); } };
  Object.defineProperty($('deck-file'), 'files', { value: [fakeFile], configurable: true });
  $('deck-options').hidden = true;
  fire($('deck-file'), 'change');
  for (let i = 0; i < 100 && $('deck-options').hidden; i++) await new Promise(r => setTimeout(r, 20));
  ok(!$('deck-options').hidden && /Anki パッケージ.*6 ノート/.test($('deck-load-msg').textContent), 'ui: apkg loaded: ' + $('deck-load-msg').textContent);
  ok(!$('deck-deck-wrap').hidden && !$('deck-model-wrap').hidden && $('deck-header-wrap').hidden, 'ui: apkg options visible');
  $('deck-deck').value = '英語::単語'; $('deck-name').value = '英語'; click('deck-convert');
  const nDl = downloads.length; $('deck-downloads').querySelector('button').dispatchEvent(new w.Event('click'));
  ok(eqBytes(Buffer.from(await downloads[nDl].arrayBuffer()), fs.readFileSync(path.join(tmp, 'a.py.DAT'))), 'ui: apkg download == Python output');
  ok(/5 枚/.test($('deck-result-msg').textContent) && /1 件/.test($('deck-result-msg').textContent), 'ui: apkg summary (5 cards, 1 skipped)');
  // model filter + field choice from the page (Cloze note type has 2 fields)
  const clozeOpt = [...$('deck-model').options].find(o => /Cloze/.test(o.textContent));
  $('deck-deck').value = ''; $('deck-model').value = clozeOpt.value; fire($('deck-model'), 'change');
  ok($('deck-front').options.length === 2 && $('deck-front').options[0].textContent.includes('Text'), 'ui: field list follows the note type');
  click('deck-convert');
  ok(/2 枚/.test($('deck-result-msg').textContent), 'ui: cloze note type -> 2 cards');
  w.Blob = JBlob;

  // wikipedia: titles -> fetch (mock) -> downloads
  click('tab-wiki');
  $('wiki-titles').value = '桜\n富士山\n無い\n# comment'; click('wiki-go');
  for (let i = 0; i < 100 && $('wiki-result').hidden; i++) await new Promise(r => setTimeout(r, 20));
  ok(!$('wiki-result').hidden, 'ui: wiki result shown');
  ok(w.fetchCalls.length === 3 && w.fetchCalls[0].startsWith('https://ja.wikipedia.org/w/api.php?'), 'ui: 3 API calls (comment line ignored)');
  ok(/2 件/.test($('wiki-result-msg').textContent), 'ui: 2 articles');
  ok(/見つかりません/.test($('wiki-msgs').textContent), 'ui: missing article reported');
  const btns = $('wiki-downloads').querySelectorAll('button');
  ok(btns.length === 2, 'ui: DAT + sources buttons');
  const before = downloads.length; btns[0].dispatchEvent(new w.Event('click')); btns[1].dispatchEvent(new w.Event('click'));
  const dat = await readBlob(downloads[before]), srcTxt = (await readBlob(downloads[before + 1])).toString('utf8');
  ok(dat.slice(0, 4).toString() === 'MWK1' && dat.readUInt32BE(4) === 2, 'ui: WIKI.DAT header');
  ok(/CC BY-SA/.test(srcTxt) && /ja\.wikipedia\.org\/wiki\//.test(srcTxt), 'ui: sources file');
  ok($('wiki-go').disabled === false && $('wiki-cancel').hidden, 'ui: buttons reset');
  // jsonl mode
  d.querySelector('input[name=wiki-mode][value=jsonl]').checked = true; fire(d.querySelector('input[name=wiki-mode][value=jsonl]'), 'change');
  ok(!$('wiki-jsonl-box').hidden && $('wiki-titles-box').hidden, 'ui: mode switch');
  $('wiki-jsonl').value = jl; click('wiki-go');
  ok(/9 件/.test($('wiki-result-msg').textContent), 'ui: jsonl -> 9 articles');
  $('wiki-jsonl').value = '{bad'; click('wiki-go');
  ok(/JSON/.test($('wiki-msgs').textContent), 'ui: bad jsonl message');

  console.log(`web tests: ${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
