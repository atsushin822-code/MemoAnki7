// Compares web/src/htmlprep.js (browser converter) with tools/html_prepare.py (pure-Python quantiser, no Pillow) byte for byte.
// Run from the repo root:  node web/tests/html_run.js
const fs = require('fs'), path = require('path'), os = require('os'), vm = require('vm');
const { execFileSync } = require('child_process');
const root = path.resolve(__dirname, '..', '..');
const src = fs.readFileSync(path.join(root, 'web', 'src', 'htmlprep.js'), 'utf8');
const core = src;
const ctx = { TextDecoder, TextEncoder, Uint8Array, Uint32Array, DataView, Map, Math, console };
ctx.globalThis = ctx; vm.createContext(ctx); vm.runInContext(core, ctx);
const H = ctx.HtmlPrep;
let fails = 0;
const check = (ok, msg) => { console.log((ok ? '  ok: ' : '  FAIL: ') + msg); if (!ok) fails++; };

// ---- fixture
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'htmlprep-'));
const inDir = path.join(tmp, 'site'); fs.mkdirSync(path.join(inDir, 'img'), { recursive: true }); fs.mkdirSync(path.join(inDir, 'sub'));
function ppm(w, h, f) { const b = Buffer.alloc(w * h * 3); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const c = f(x, y); b[(y * w + x) * 3] = c[0]; b[(y * w + x) * 3 + 1] = c[1]; b[(y * w + x) * 3 + 2] = c[2]; } return Buffer.concat([Buffer.from(`P6\n${w} ${h}\n255\n`), b]); }
fs.writeFileSync(path.join(inDir, 'img', 'photo.ppm'), ppm(700, 350, (x, y) => [(x * 255 / 700) | 0, (y * 255 / 350) | 0, ((x * y) >> 4) & 255]));   // many colours + needs shrinking
fs.writeFileSync(path.join(inDir, 'img', 'flat.ppm'), ppm(40, 20, (x) => (x < 20 ? [200, 0, 0] : [0, 0, 200])));                                      // few colours, no shrink
fs.writeFileSync(path.join(inDir, 'style.css'), 'body { background: #ffffee; } h1 { color: navy; }\n');
fs.writeFileSync(path.join(inDir, 'index.html'), '<html><head><link rel="stylesheet" href="style.css"><title>T</title></head><body><h1>Top</h1>\n<img src="img/photo.ppm"><img src=\'img/flat.ppm\'><img src="img/missing.ppm"><img src="http://example.com/a.png">\n<a href="sub/My Page.html#part">next</a> <a href="http://example.com">ext</a> <a href="gone.html">gone</a></body></html>');
fs.writeFileSync(path.join(inDir, 'sub', 'My Page.html'), '<html><body><a href="../index.html">back</a><img src="../img/flat.ppm"></body></html>');
fs.writeFileSync(path.join(inDir, 'sub', 'other_long_name_here.htm'), Buffer.from('<html><body>日本語 テスト</body></html>', 'utf8'));
const sjis = require('child_process').execFileSync('python3', ['-c', "import sys; sys.stdout.buffer.write('<html><body>シフトJIS 日本語</body></html>'.encode('cp932'))"]);
fs.writeFileSync(path.join(inDir, 'sub', 'sjis.htm'), sjis);

function walk(d, base = '') { return fs.readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(d, e.name), base + e.name + '/') : [{ path: base + e.name, data: new Uint8Array(fs.readFileSync(path.join(d, e.name))) }]); }
const files = walk(inDir);

function readPpm(b) { const m = /^P6\s+(\d+)\s+(\d+)\s+255\s/.exec(Buffer.from(b.slice(0, 40)).toString('latin1')); const w = +m[1], h = +m[2]; return { w, h, rgb: b.slice(m[0].length) }; }
const decodeImage = async (bytes) => { const p = readPpm(bytes); return H.shrinkNearest(p.w, p.h, p.rgb, H.MAX_W, H.MAX_H); };

(async () => {
  const res = await H.convert(files, { decodeImage });
  const order = H.orderPages(files);
  console.log('pages:', order.join(', '));
  const pyOut = path.join(tmp, 'py');
  execFileSync('python3', ['-c', `
import sys
sys.path.insert(0, 'tools')
import imgfmt
imgfmt.Image = None
import html_prepare
files, warnings = html_prepare.run(sys.argv[2:], sys.argv[1])
print('py wrote:', ' '.join(files))
`, pyOut, ...order.map(p => path.join(inDir, p))], { cwd: root, stdio: ['ignore', 'inherit', 'inherit'] });
  const pyFiles = fs.readdirSync(pyOut).sort();
  const jsFiles = Object.keys(res.files).sort();
  console.log('js wrote:', jsFiles.join(' '));
  check(JSON.stringify(pyFiles) === JSON.stringify(jsFiles), 'same output file names as the Python tool');
  for (const n of jsFiles) {
    const a = Buffer.from(res.files[n].data), b = fs.existsSync(path.join(pyOut, n)) ? fs.readFileSync(path.join(pyOut, n)) : null;
    check(b && a.equals(b), `${n} identical (${a.length} bytes)`);
  }
  check(res.warnings.some(w => /missing\.ppm/.test(w)), 'warns about the missing image');
  check(res.warnings.some(w => /gone\.html/.test(w)), 'warns about a link target that was not selected');
  check(!res.warnings.some(w => /example\.com/.test(w)), 'no warning for external http links/images');
  const sj = Buffer.from(res.files[Object.keys(res.files).find(n => /^SJIS/.test(n))].data).toString('utf8');
  check(sj.includes('シフトJIS 日本語'), 'Shift_JIS page converted to UTF-8');

  // ZIP -> verify with Python's zipfile
  const zip = H.makeZip(jsFiles.map(n => ({ name: n, data: res.files[n].data })));
  fs.writeFileSync(path.join(tmp, 't.zip'), zip);
  const out = execFileSync('python3', ['-c', `
import zipfile, sys
z = zipfile.ZipFile(sys.argv[1]); assert z.testzip() is None
print(','.join(sorted(z.namelist())))
`, path.join(tmp, 't.zip')]).toString().trim();
  check(out === jsFiles.join(','), 'ZIP is valid and lists the same files');
  const z2 = execFileSync('python3', ['-c', `
import zipfile, sys
z = zipfile.ZipFile(sys.argv[1])
print(all(z.read(n) == open(sys.argv[2] + '/' + n, 'rb').read() for n in z.namelist()))
`, path.join(tmp, 't.zip'), pyOut]).toString().trim();
  check(z2 === 'True', 'ZIP contents equal the Python tool output');
  console.log(fails ? `${fails} FAILED` : 'html converter: all passed');
  process.exit(fails ? 1 : 0);
})();
