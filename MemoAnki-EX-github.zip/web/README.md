# MemoAnki EX データ変換ページ(XServer 用)

ブラウザだけで動く静的なページです(PHP・DB は不要)。Anki / CSV → `IMPORT.DAT`、Wikipedia → `WIKI.DAT` を作ります。

## XServer への置き方
1. `index.html`、`sql-wasm.js`、`sql-wasm.wasm` の3つを、同じフォルダにアップロードします(例: `public_html/memoanki/`)。
2. `https://あなたのドメイン/memoanki/` を開きます(`file://` で直接開くと .apkg の読み込みが動かないことがあります)。
- CSV の変換と Wikipedia の変換は `index.html` だけで動きます。`sql-wasm.*` は `.apkg` を読むときだけ必要です(無い場合は jsDelivr から読み込みます)。
- 変換はブラウザの中だけで行われ、ファイルはサーバーに送られません。Wikipedia の取得だけは、ブラウザから Wikipedia に直接アクセスします。
- `.wasm` が読めない場合は、`.htaccess` に `AddType application/wasm .wasm` を追加します。

## 開発
- `src/core.js`(変換ロジック)、`src/ui.js`(画面)、`src/template.html` を編集し、`python3 build.py` で `index.html` を作り直します。
- テスト: `cd tests && npm install && cd ../.. && NODE_PATH=web/tests/node_modules node web/tests/run.js`
  Python 版ツール(`tools/`)と出力が1バイトまで一致すること、画面操作(jsdom)を確認します。
