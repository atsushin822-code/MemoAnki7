# MemoAnki EX データ変換ページ(XServer 用)

ブラウザだけで動く静的なページです(PHP・DB は不要)。Anki / CSV → `IMPORT.DAT`、Wikipedia → `WIKI.DAT` を作ります。

## オフラインブラウザ用の HTML 変換(「HTML → オフラインブラウザ」タブ)
Files アプリのオフラインブラウザで開くページ(HTML・CSS・画像)を、端末用の `.HTM` / `.CSS` / `.IMG`(8.3 名)に変換します。単語帳・Wikipedia と同じ `index.html` のタブで、追加のファイルやライブラリは要りません。
- ファイルまたはフォルダをドロップ(または選択) → 「変換する」 → 「ZIP でまとめてダウンロード」。出てきたファイルを `MEMAN` フォルダへ入れます。
- 出力は `tools/html_prepare.py` と同じ内容です(テストで1バイトまで一致を確認)。画像の縮小だけはブラウザの機能を使うため、画素の値は少し違います。
- 24KB 超のページ、4KB 超の CSS、画像 9 枚以上、リンク 13 個以上、選ばれていないリンク先・画像などは、結果の上に警告が出ます。

## XServer への置き方
1. `index.html`、`sql-wasm.js`、`sql-wasm.wasm` の3つを、同じフォルダにアップロードします(例: `public_html/memoanki/`)。
2. `https://あなたのドメイン/memoanki/` を開きます(`file://` で直接開くと .apkg の読み込みが動かないことがあります)。
- CSV の変換と Wikipedia の変換は `index.html` だけで動きます。`sql-wasm.*` は `.apkg` を読むときだけ必要です(無い場合は jsDelivr から読み込みます)。
- 変換はブラウザの中だけで行われ、ファイルはサーバーに送られません。Wikipedia の取得だけは、ブラウザから Wikipedia に直接アクセスします。
- `.wasm` が読めない場合は、`.htaccess` に `AddType application/wasm .wasm` を追加します。

## 開発
- `src/core.js`(単語帳・Wikipedia の変換ロジック)、`src/htmlprep.js`(HTML 変換ロジック)、`src/ui.js` / `src/ui_html.js`(画面)、`src/template.html` を編集し、`python3 build.py` で `index.html` を作り直します。
- HTML 変換のテスト: `node web/tests/html_run.js`(リポジトリ直下で実行。Python 版との出力一致と ZIP の正しさを確認)
- テスト: `cd tests && npm install && cd ../.. && NODE_PATH=web/tests/node_modules node web/tests/run.js`
  Python 版ツール(`tools/`)と出力が1バイトまで一致すること、画面操作(jsdom)を確認します。
