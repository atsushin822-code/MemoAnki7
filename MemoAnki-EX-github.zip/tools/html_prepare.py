#!/usr/bin/env python3
"""HTML (+ CSS + images) -> files for the Files app's offline browser (8.3 names).

  python3 tools/html_prepare.py index.html [other.html ...] -o outdir

Writes NAME.HTM, NAME.CSS and NAME.IMG into outdir (copy them to the MEMAN folder). Local pages linked with
<a href> are converted too. Images (PNG/JPEG/GIF/..., needs Pillow; PPM works without) are shrunk to fit the
screen (480x200) and stored as 256-colour .IMG files; every <img src>, <link href> and <a href> is rewritten to
the new names. Flat colours (no dithering) keep drawing fast on the device.
"""
import argparse
import re
import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import imgfmt  # noqa: E402

MAX_W, MAX_H = 480, 200


class Names:
    def __init__(self):
        self.map, self.used = {}, set()

    def get(self, path, ext):
        key = str(Path(path).resolve())
        if key in self.map:
            return self.map[key]
        stem = re.sub(r"[^A-Za-z0-9_]", "", Path(path).stem).upper()[:8] or "FILE"
        name, n = stem, 1
        while name + ext in self.used:
            suffix = str(n)
            name, n = stem[:8 - len(suffix)] + suffix, n + 1
        self.used.add(name + ext)
        self.map[key] = name + ext
        return self.map[key]


def read_text(path):
    data = Path(path).read_bytes()
    for enc in ("utf-8-sig", "cp932"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            pass
    return data.decode("utf-8", "replace")


def convert_image(src, dst):
    w, h, rgb = imgfmt.load_rgb(src, MAX_W, MAX_H)
    pal, idx = imgfmt.quantize(w, h, rgb, dither=False)
    dst.write_bytes(b"IMG1" + struct.pack(">HH", w, h) + imgfmt.pack_pal8(w, h, pal, idx))


def local(base, ref):
    ref = ref.split("#")[0].split("?")[0].strip()
    if not ref or re.match(r"^(https?:|data:|mailto:|//)", ref, re.I):
        return None
    p = (base.parent / ref)
    return p if p.is_file() else None


def run(inputs, outdir):
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    names = Names()
    queue, done, warnings = [Path(p) for p in inputs], set(), []

    def sub(pattern, text, fn):
        return re.sub(pattern, fn, text, flags=re.I | re.S)

    while queue:
        page = queue.pop(0)
        if page.resolve() in done:
            continue
        done.add(page.resolve())
        html = read_text(page)

        def img(m):
            p = local(page, m.group(3))
            if p is None:
                warnings.append(f"{page.name}: image not found: {m.group(3)}")
                return m.group(0)
            name = names.get(p, ".IMG")
            try:
                convert_image(p, out / name)
            except Exception as e:  # pragma: no cover
                warnings.append(f"{p.name}: {e}")
                return m.group(0)
            return m.group(1) + m.group(2) + name + m.group(2)

        def link(m):
            if not re.search(r"stylesheet", m.group(0), re.I):
                return m.group(0)
            return re.sub(r"(href\s*=\s*)([\"'])(.*?)\2", lambda h: _css(h, page, out, names, warnings), m.group(0), flags=re.I | re.S)

        def anchor(m):
            p = local(page, m.group(3))
            if p is None or p.suffix.lower() not in (".htm", ".html"):
                return m.group(0)
            queue.append(p)
            frag = "#" + m.group(3).split("#", 1)[1] if "#" in m.group(3) else ""
            return m.group(1) + m.group(2) + names.get(p, ".HTM") + frag + m.group(2)

        html = sub(r"(<img\b[^>]*?\bsrc\s*=\s*)([\"'])(.*?)\2", html, img)
        html = sub(r"<link\b[^>]*>", html, link)
        html = sub(r"(<a\b[^>]*?\bhref\s*=\s*)([\"'])(.*?)\2", html, anchor)
        (out / names.get(page, ".HTM")).write_text(html, encoding="utf-8")
    return sorted(p.name for p in out.iterdir()), warnings


def _css(m, page, out, names, warnings):
    p = local(page, m.group(3))
    if p is None:
        warnings.append(f"{page.name}: stylesheet not found: {m.group(3)}")
        return m.group(0)
    name = names.get(p, ".CSS")
    (out / name).write_text(read_text(p), encoding="utf-8")
    return m.group(1) + m.group(2) + name + m.group(2)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("html", nargs="+")
    ap.add_argument("-o", "--out", default="html_out")
    a = ap.parse_args(argv)
    files, warnings = run(a.html, a.out)
    for w in warnings:
        print("warning:", w, file=sys.stderr)
    print("wrote:", " ".join(files))


if __name__ == "__main__":
    main()
