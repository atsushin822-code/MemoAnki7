"""Shared code for the PC-side tools: writers for the device's data files and text helpers.

  IMPORT.DAT  deck import  ("MIM1", see anki_to_deck.py / csv_to_deck.py)
  WIKI.DAT    offline articles ("MWK1", see src/wikipedia.h)
Both are big-endian and are read by the app on the XD-A8500.
"""
import re
import struct
import unicodedata
from collections import Counter
from pathlib import Path

CARD_FIELD_BYTES = 127          # device keeps at most 127 bytes per card field (TEXT_MAX 128 incl. NUL)
DECK_NAME_BYTES = 47
MAX_IMPORT_CARDS = 600          # card table of the app
WIKI_KEY_BYTES = 31
WIKI_TITLE_BYTES = 47

HERE = Path(__file__).resolve().parent


def cut_utf8(b: bytes, n: int) -> bytes:
    """Cut to at most n bytes without leaving half of a UTF-8 character."""
    if len(b) <= n:
        return b
    return b[:n].decode("utf-8", "ignore").encode("utf-8")


# --------------------------------------------------------------------------- display check
_font_cps = None


def font_codepoints():
    """Characters the device font can draw (beyond ASCII). None if the list is not available."""
    global _font_cps
    if _font_cps is not None:
        return _font_cps
    cps = None
    txt = HERE / "jfont_cp.txt"
    if txt.exists():
        cps = {int(x, 16) for line in txt.read_text().splitlines() if not line.startswith("#") for x in line.split()}
    else:
        c = HERE.parent / "src" / "jfont_data.c"
        if c.exists():
            s = c.read_text()
            a = s.index("jfont_cp[")
            cps = {int(x, 16) for x in re.findall(r"0x([0-9A-F]{4})", s[a:s.index("};", a)])}
    _font_cps = cps
    return cps


def undisplayable(texts):
    """Counter of characters in `texts` that the device would show as '?'. Empty if the list is unavailable."""
    cps = font_codepoints()
    bad = Counter()
    if cps is None:
        return bad
    for t in texts:
        for ch in t:
            o = ord(ch)
            if o >= 0x80 and o not in cps and not ch.isspace():
                bad[ch] += 1
    return bad


def report_undisplayable(texts, file=None):
    bad = undisplayable(texts)
    if font_codepoints() is None:
        print("note: jfont_cp.txt not found, display check skipped", file=file)
    elif bad:
        shown = " ".join(f"{c}" for c, _ in bad.most_common(40))
        print(f"note: {sum(bad.values())} character(s) ({len(bad)} kinds) cannot be drawn by the device font and "
              f"will appear as '?': {shown}", file=file)
    return bad


# --------------------------------------------------------------------------- IMPORT.DAT
def write_import_dat(name: str, cards, path) -> int:
    """cards: iterable of (front, back, example) strings. Returns the number of cards written."""
    cards = list(cards)
    nb = name.encode("utf-8")
    if not 0 < len(nb) <= DECK_NAME_BYTES:
        nb = cut_utf8(nb, DECK_NAME_BYTES)
        if not nb:
            raise ValueError("deck name is empty")
    if len(cards) > MAX_IMPORT_CARDS:
        raise ValueError(f"at most {MAX_IMPORT_CARDS} cards per import file")
    blob = b"MIM1" + bytes([len(nb)]) + nb + struct.pack(">H", len(cards))
    for card in cards:
        for field in card:
            b = cut_utf8(field.encode("utf-8"), CARD_FIELD_BYTES)
            blob += struct.pack(">H", len(b)) + b
    Path(path).write_bytes(blob)
    return len(cards)


def read_import_dat(path):
    """Parse IMPORT.DAT (used by the tests)."""
    b = Path(path).read_bytes()
    assert b[:4] == b"MIM1"
    n = b[4]
    name = b[5:5 + n].decode("utf-8")
    count = struct.unpack(">H", b[5 + n:7 + n])[0]
    pos = 7 + n
    cards = []
    for _ in range(count):
        card = []
        for _ in range(3):
            ln = struct.unpack(">H", b[pos:pos + 2])[0]
            card.append(b[pos + 2:pos + 2 + ln].decode("utf-8"))
            pos += 2 + ln
        cards.append(tuple(card))
    assert pos == len(b)
    return name, cards


# --------------------------------------------------------------------------- WIKI.DAT
KANA_ONLY = re.compile(r"^[ぁ-ゖー゛゜ァ-ヺ・ \u3000a-zA-Z0-9]+$")
READING = re.compile(r"[（(]([ぁ-ゖァ-ヺー・ ]+)[、，,）)]")


def fold_key(s: str) -> str:
    """Same folding as the device (text_make_key): ASCII lower-case, katakana -> hiragana."""
    out = []
    for ch in unicodedata.normalize("NFKC", s):
        o = ord(ch)
        if "A" <= ch <= "Z":
            ch = ch.lower()
        elif 0x30A1 <= o <= 0x30F6:
            ch = chr(o - 0x60)
        out.append(ch)
    return "".join(out)


def guess_reading(title: str, text: str):
    """Reading for a Japanese title: the first "(よみ)" in the lead text, or None."""
    if KANA_ONLY.match(title):
        return None
    m = READING.search(text[:200])
    return m.group(1) if m else None


IMG_ENTRY = 64
IMG_CAPTION_BYTES = 47


def write_wiki_dat(articles, path, max_bytes=20000):
    """articles: iterable of dicts {title, text, reading?, images?}.
    images: list of dicts from imgfmt.encode_image (w, h, fmt, mask, data, caption).
    Returns (count, size_bytes, n_without_reading).

    Files without images keep the original "MWK1" layout. With images the magic is "MWK2" and the header
    (big-endian) carries: u32 img_count @16, img_index_off @20, img_data_off @24. Each article's 8 reserved
    bytes @88 become u32 first_image + u16 image_count. Image index entry (64 B): u32 off, u32 len, u16 w, u16 h,
    u8 fmt, u8 reserved, u16 mask, caption[48]; `off` is relative to img_data_off.
    """
    entries, no_reading = [], 0
    for a in articles:
        title = a["title"].strip()
        text = a.get("text", "").replace("\r\n", "\n").replace("\r", "\n")
        text = "".join(c if (c == "\n" or c >= " ") else " " for c in text)
        reading = a.get("reading") or guess_reading(title, text)
        if not reading and not KANA_ONLY.match(title):
            no_reading += 1
        key = cut_utf8(fold_key(reading or title).encode("utf-8"), WIKI_KEY_BYTES)
        entries.append((key, cut_utf8(title.encode("utf-8"), WIKI_TITLE_BYTES),
                        cut_utf8(text.encode("utf-8"), max_bytes), list(a.get("images") or [])))
    entries.sort(key=lambda e: e[0])

    hdr, ent = 32, 96
    n_img = sum(len(e[3]) for e in entries)
    index_off = hdr
    img_index_off = index_off + ent * len(entries)
    data_off = img_index_off + IMG_ENTRY * n_img
    index, data, img_index, img_data = bytearray(), bytearray(), bytearray(), bytearray()
    first = 0
    for key, title, text, images in entries:
        index += (key.ljust(32, b"\0") + title.ljust(48, b"\0") + struct.pack(">II", len(data), len(text))
                  + struct.pack(">IHH", first if images else 0, len(images), 0))
        data += text
        for im in images:
            if not (0 < im["w"] <= 528 and 0 < im["h"] <= 256):
                raise ValueError("image %dx%d does not fit the device viewer (max 528x256)" % (im["w"], im["h"]))
            cap = cut_utf8(im.get("caption", "").encode("utf-8"), IMG_CAPTION_BYTES)
            img_index += (struct.pack(">IIHHBBH", len(img_data), len(im["data"]), im["w"], im["h"], im["fmt"], 0, im.get("mask", 0xF81F))
                          + cap.ljust(48, b"\0"))
            img_data += im["data"]
        first += len(images)
    img_data_off = data_off + len(data)
    magic = b"MWK2" if n_img else b"MWK1"
    header = (magic + struct.pack(">III", len(entries), index_off, data_off)
              + struct.pack(">III", n_img, img_index_off if n_img else 0, img_data_off if n_img else 0) + b"\0" * 4)
    Path(path).write_bytes(header + index + img_index + data + img_data)
    return len(entries), hdr + len(index) + len(img_index) + len(data) + len(img_data), no_reading


def read_wiki_dat(path):
    """Parse WIKI.DAT -> list of (key, title, text) (used by the tests)."""
    return [(d["key"], d["title"], d["text"]) for d in read_wiki_dat_full(path)]


def read_wiki_dat_full(path):
    """Parse WIKI.DAT -> list of dicts {key, title, text, images: [{w,h,fmt,mask,caption,data}]}."""
    b = Path(path).read_bytes()
    assert b[:4] in (b"MWK1", b"MWK2")
    count, index_off, data_off = struct.unpack(">III", b[4:16])
    n_img, img_index_off, img_data_off = struct.unpack(">III", b[16:28])
    out = []
    for i in range(count):
        e = b[index_off + i * 96:index_off + (i + 1) * 96]
        key = e[:32].split(b"\0")[0].decode("utf-8")
        title = e[32:80].split(b"\0")[0].decode("utf-8")
        off, ln = struct.unpack(">II", e[80:88])
        first, cnt, _ = struct.unpack(">IHH", e[88:96])
        images = []
        for k in range(first, first + cnt):
            r = b[img_index_off + k * IMG_ENTRY:img_index_off + (k + 1) * IMG_ENTRY]
            ioff, ilen, w, h, fmt, _, mask = struct.unpack(">IIHHBBH", r[:16])
            images.append({"w": w, "h": h, "fmt": fmt, "mask": mask, "caption": r[16:].split(b"\0")[0].decode("utf-8"),
                           "data": b[img_data_off + ioff:img_data_off + ioff + ilen]})
        out.append({"key": key, "title": title, "text": b[data_off + off:data_off + off + ln].decode("utf-8"), "images": images})
    return out
