"""Images for the device (WIKI.DAT): load, shrink, reduce to 256 colours, pack.

Device image formats (big-endian):
  fmt 2  palette: 256 x RGB565 palette (512 bytes) + w*h palette indices
  fmt 1  RGB565 : w*h x RGB565
RGB565 value MASK (0xF81F) is the "transparent" colour of the device's sprite routine, so no pixel/palette
entry may equal it: such values are nudged to 0xF81E.

Pillow (pip install pillow) is optional: with it any JPEG/PNG/GIF/... can be read and shrunk well, and
quantising is fast with dithering. Without it, binary PPM (P6) files are accepted and a slower
pure-Python quantiser is used.
"""
import struct
from pathlib import Path

try:                                   # optional
    from PIL import Image
except ImportError:                    # pragma: no cover - exercised when Pillow is absent
    Image = None

MASK = 0xF81F
DEV_MAX_W, DEV_MAX_H = 528, 256        # what the viewer on the device can show
FMT_RGB565, FMT_PAL8 = 1, 2


class ImageError(Exception):
    pass


def have_pillow():
    return Image is not None


def to565(r, g, b):
    v = (((r * 31 + 127) // 255) << 11) | (((g * 63 + 127) // 255) << 5) | ((b * 31 + 127) // 255)
    return v ^ 1 if v == MASK else v


def from565(v):
    r, g, b = (v >> 11) & 31, (v >> 5) & 63, v & 31
    return (r << 3) | (r >> 2), (g << 2) | (g >> 4), (b << 3) | (b >> 2)


# --------------------------------------------------------------------------- loading / resizing
def read_ppm(data: bytes):
    """Binary PPM (P6) -> (w, h, rgb bytes)."""
    pos = [0]

    def token():
        while True:
            while data[pos[0]:pos[0] + 1].isspace():
                pos[0] += 1
            if data[pos[0]:pos[0] + 1] == b"#":
                while data[pos[0]:pos[0] + 1] not in (b"\n", b""):
                    pos[0] += 1
                continue
            break
        s = pos[0]
        while pos[0] < len(data) and not data[pos[0]:pos[0] + 1].isspace():
            pos[0] += 1
        return data[s:pos[0]]

    if token() != b"P6":
        raise ImageError("only binary PPM (P6) can be read without Pillow; run `pip install pillow` for JPEG/PNG")
    w, h, mx = int(token()), int(token()), int(token())
    pos[0] += 1
    if mx != 255 or len(data) - pos[0] < w * h * 3:
        raise ImageError("unsupported or truncated PPM")
    return w, h, bytes(data[pos[0]:pos[0] + w * h * 3])


def shrink_nearest(w, h, rgb, max_w, max_h):
    """Nearest-neighbour shrink (fallback when Pillow is missing). Never enlarges."""
    if w <= max_w and h <= max_h:
        return w, h, rgb
    scale = min(max_w / w, max_h / h)
    nw, nh = max(1, int(w * scale)), max(1, int(h * scale))
    out = bytearray(nw * nh * 3)
    for y in range(nh):
        sy = y * h // nh
        for x in range(nw):
            sx = x * w // nw
            out[(y * nw + x) * 3:(y * nw + x) * 3 + 3] = rgb[(sy * w + sx) * 3:(sy * w + sx) * 3 + 3]
    return nw, nh, bytes(out)


def load_rgb(source, max_w, max_h):
    """source: path or bytes of an image -> (w, h, rgb bytes) no larger than max_w x max_h."""
    data = Path(source).read_bytes() if isinstance(source, (str, Path)) else bytes(source)
    if Image is not None:
        import io
        im = Image.open(io.BytesIO(data))
        if im.mode in ("RGBA", "LA", "P"):
            im = im.convert("RGBA")
            bg = Image.new("RGBA", im.size, (255, 255, 255, 255))
            im = Image.alpha_composite(bg, im)
        im = im.convert("RGB")
        if im.width > max_w or im.height > max_h:
            im.thumbnail((max_w, max_h), getattr(Image, "Resampling", Image).LANCZOS)
        return im.width, im.height, im.tobytes()
    if data[:2] != b"P6":
        raise ImageError("Pillow is not installed: only PPM (P6) images can be read. Run `pip install pillow`.")
    w, h, rgb = read_ppm(data)
    return shrink_nearest(w, h, rgb, max_w, max_h)


# --------------------------------------------------------------------------- quantising
def _median_cut(hist, n=256):
    """hist: {rgb565: count} -> list of up to n RGB565 palette values (weighted median cut)."""
    boxes = [sorted(hist.items())]

    def rng(box):
        best, chan = -1, 0
        for c in range(3):
            vals = [from565(v)[c] for v, _ in box]
            r = max(vals) - min(vals)
            if r > best:
                best, chan = r, c
        return best, chan

    while len(boxes) < n:
        cand = [(rng(b)[0] * (1 if len(b) > 1 else 0), i) for i, b in enumerate(boxes)]
        score, i = max(cand, key=lambda t: (t[0], -t[1]))
        if score <= 0:
            break
        box = boxes.pop(i)
        chan = rng(box)[1]
        box = sorted(box, key=lambda t: (from565(t[0])[chan], t[0]))
        total, acc, cut = sum(c for _, c in box), 0, 1
        for k, (_, c) in enumerate(box):
            acc += c
            if acc * 2 >= total:
                cut = min(max(k + 1, 1), len(box) - 1)
                break
        boxes.insert(i, box[:cut])
        boxes.insert(i + 1, box[cut:])
    pal = []
    for box in boxes:
        tot = sum(c for _, c in box)
        r = sum(from565(v)[0] * c for v, c in box) // tot
        g = sum(from565(v)[1] * c for v, c in box) // tot
        b = sum(from565(v)[2] * c for v, c in box) // tot
        pal.append(to565(r, g, b))
    return pal


def quantize(w, h, rgb, dither=True):
    """-> (palette: list of RGB565 (<=256), indices: bytes of w*h)."""
    if Image is not None:
        im = Image.frombytes("RGB", (w, h), rgb)
        enum_q = getattr(Image, "Quantize", Image)
        enum_d = getattr(Image, "Dither", Image)
        q = im.quantize(colors=256, method=enum_q.MEDIANCUT,
                        dither=enum_d.FLOYDSTEINBERG if dither else enum_d.NONE)
        p = q.getpalette() or []
        used = max(q.tobytes()) + 1 if w * h else 1
        pal = [to565(p[i * 3], p[i * 3 + 1], p[i * 3 + 2]) for i in range(max(used, 1))]
        return pal, q.tobytes()
    hist = {}
    for i in range(0, w * h * 3, 3):
        v = to565(rgb[i], rgb[i + 1], rgb[i + 2])
        hist[v] = hist.get(v, 0) + 1
    pal = sorted(hist) if len(hist) <= 256 else _median_cut(hist)
    exp = [from565(v) for v in pal]
    cache, out = {}, bytearray(w * h)
    for i in range(w * h):
        v = to565(rgb[i * 3], rgb[i * 3 + 1], rgb[i * 3 + 2])
        k = cache.get(v)
        if k is None:
            r, g, b = from565(v)
            k = min(range(len(exp)), key=lambda j: (exp[j][0] - r) ** 2 + (exp[j][1] - g) ** 2 + (exp[j][2] - b) ** 2)
            cache[v] = k
        out[i] = k
    return pal, bytes(out)


# --------------------------------------------------------------------------- packing
def pack_pal8(w, h, palette, indices):
    pal = list(palette)[:256] + [0] * (256 - len(palette))
    return b"".join(struct.pack(">H", v) for v in pal) + bytes(indices)


def pack_rgb565(w, h, rgb):
    return b"".join(struct.pack(">H", to565(rgb[i], rgb[i + 1], rgb[i + 2])) for i in range(0, w * h * 3, 3))


def encode_image(source, max_w=320, max_h=200, fmt="pal8", dither=True, caption=""):
    """source: path / bytes / (w, h, rgb) -> dict for write_wiki_dat."""
    max_w, max_h = min(max_w, DEV_MAX_W), min(max_h, DEV_MAX_H)
    if isinstance(source, tuple):
        w, h, rgb = shrink_nearest(*source, max_w, max_h)
    else:
        w, h, rgb = load_rgb(source, max_w, max_h)
    if fmt == "rgb565":
        return {"w": w, "h": h, "fmt": FMT_RGB565, "mask": MASK, "data": pack_rgb565(w, h, rgb), "caption": caption}
    pal, idx = quantize(w, h, rgb, dither)
    return {"w": w, "h": h, "fmt": FMT_PAL8, "mask": MASK, "data": pack_pal8(w, h, pal, idx), "caption": caption}


def decode_image(img):
    """Inverse of encode_image -> (w, h, rgb bytes) (used by the tests)."""
    w, h, data = img["w"], img["h"], img["data"]
    out = bytearray()
    if img["fmt"] == FMT_PAL8:
        pal = struct.unpack(">256H", data[:512])
        for k in data[512:512 + w * h]:
            out += bytes(from565(pal[k]))
    else:
        for (v,) in struct.iter_unpack(">H", data[:w * h * 2]):
            out += bytes(from565(v))
    return w, h, bytes(out)


# --------------------------------------------------------------------------- built-in demo pictures (sample data only)
def demo_image(name, w=240, h=150):
    """Synthetic colour pictures so the sample WIKI.DAT can show the image feature without any photo files."""
    px = bytearray(w * h * 3)

    def put(x, y, c):
        if 0 <= x < w and 0 <= y < h:
            px[(y * w + x) * 3:(y * w + x) * 3 + 3] = bytes(c)

    def lerp(a, b, t):
        return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

    if name == "mountain":
        for y in range(h):
            for x in range(w):
                t = y / (h * 0.7)
                put(x, y, lerp((40, 90, 190), (255, 200, 150), min(t, 1.0)) if y < h * 0.7 else lerp((40, 110, 60), (20, 70, 40), (y - h * 0.7) / (h * 0.3)))
        cx, top, base = w // 2, int(h * 0.12), int(h * 0.7)
        for y in range(top, base):
            half = int((y - top) * (w * 0.42) / (base - top))
            for x in range(cx - half, cx + half + 1):
                shade = 0.85 + 0.15 * ((x - cx) / max(half, 1))
                col = (int(70 * shade), int(80 * shade), int(120 * shade))
                if y - top < (base - top) * 0.22:
                    col = (245, 248, 255) if (x + y) % 11 else (225, 232, 245)
                put(x, y, col)
    elif name == "sakura":
        for y in range(h):
            for x in range(w):
                put(x, y, lerp((150, 200, 255), (255, 235, 240), y / h))
        for y in range(int(h * 0.55), h):                      # branch
            for x in range(w):
                if abs(y - (int(h * 0.62) + int(10 * ((x / w) - 0.4) ** 2 * 20))) < 4:
                    put(x, y, (90, 55, 40))
        seed = 12345
        for _ in range(70):
            seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF
            cx, cy = seed % w, (seed >> 8) % int(h * 0.8)
            r = 4 + (seed >> 16) % 6
            for yy in range(-r, r + 1):
                for xx in range(-r, r + 1):
                    if xx * xx + yy * yy <= r * r:
                        put(cx + xx, cy + yy, lerp((255, 255, 255), (255, 150, 180), (xx * xx + yy * yy) / (r * r + 1)))
    else:                                                       # "gradient": rainbow test card
        for y in range(h):
            for x in range(w):
                hue = x / w
                r = int(255 * max(0, min(1, abs(hue * 6 - 3) - 1)))
                g = int(255 * max(0, min(1, 2 - abs(hue * 6 - 2))))
                b = int(255 * max(0, min(1, 2 - abs(hue * 6 - 4))))
                f = 1 - 0.8 * y / h
                put(x, y, (int(r * f), int(g * f), int(b * f)))
    return w, h, bytes(px)
