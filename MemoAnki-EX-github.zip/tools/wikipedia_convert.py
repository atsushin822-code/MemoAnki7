#!/usr/bin/env python3
"""Make WIKI.DAT (offline Wikipedia for MemoAnki EX) from Wikipedia data. Three ways to get articles:

  dump       a MediaWiki XML dump (e.g. jawiki-latest-pages-articles.xml.bz2 from dumps.wikimedia.org)
  extractor  output of WikiExtractor (python -m wikiextractor.WikiExtractor --json ...)
  fetch      download the articles listed in a text file through the Wikipedia API (one title per line)

Examples
  wikipedia_convert.py fetch titles.txt --lang ja -o WIKI.DAT
  wikipedia_convert.py dump jawiki-latest-pages-articles.xml.bz2 --titles-file titles.txt -o WIKI.DAT
  wikipedia_convert.py dump jawiki-latest-pages-articles.xml.bz2 --limit 3000 --min-chars 400 -o WIKI.DAT
  wikipedia_convert.py extractor extracted/AA/wiki_00 extracted/AA/wiki_01 -o WIKI.DAT

The device has limited storage and the app reads up to 32 KB per article, so choose a selection: a titles file
is the best way. Without one, `dump` keeps the first --limit suitable articles it meets (alphabetical order is
NOT guaranteed). Disambiguation pages, redirects, stubs and non-article pages are skipped.

Licence: Wikipedia text is CC BY-SA 4.0. A WIKI_SOURCES.txt (titles and URLs) is written next to the output;
keep it with the data. The tool downloads nothing except in `fetch` mode, where it asks the Wikipedia API
politely (one request at a time with a delay and a descriptive User-Agent).
"""
import argparse
import bz2
import gzip
import html
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import devfmt

# --------------------------------------------------------------------------- wikitext -> plain text
DROP_NS = {"file", "image", "media", "category", "ファイル", "画像", "メディア", "カテゴリ", "分類"}
DROP_SECTIONS = {"脚注", "注釈", "出典", "参考文献", "関連項目", "外部リンク", "参照", "脚注・出典", "注釈・出典",
                 "関連作品", "関連書籍", "関連文献", "脚注・参考文献", "参考資料", "文献", "備考",
                 "references", "external links", "see also", "further reading", "notes", "footnotes",
                 "sources", "bibliography", "citations", "references and notes"}
DROP_TAGS = ("gallery", "math", "timeline", "imagemap", "syntaxhighlight", "source", "pre", "score", "chem", "ce")
DISAMBIG = re.compile(r"\{\{\s*(aimai|disambig|disambiguation|曖昧さ回避|数字見出し|地名の曖昧さ回避|人名の曖昧さ回避)", re.I)
INTERWIKI = re.compile(r"^[a-z]{2,3}(-[a-z]+)?:", re.I)


def _template(m):
    parts = m.group(1).split("|")
    name = parts[0].strip().lower()
    if name in ("lang", "langx") and len(parts) >= 3:
        return parts[2].split("=", 1)[-1] if "=" in parts[2][:6] else parts[2]
    if re.match(r"lang-[a-z]{2,3}$", name) and len(parts) >= 2:
        return parts[1]
    if name in ("ruby", "ルビ") and len(parts) >= 2:
        return parts[1]
    return ""


def _link(m):
    inner = m.group(1)
    target = inner.split("|", 1)[0].strip().lstrip(":")
    prefix = target.split(":", 1)[0].strip().lower() if ":" in target else ""
    if prefix in DROP_NS or (":" in target and INTERWIKI.match(target) and not inner.startswith(":")):
        return ""
    if "|" in inner:
        return inner.rsplit("|", 1)[1]
    return target.split("#", 1)[0] or target.lstrip("#")


def clean_wikitext(t: str) -> str:
    t = re.sub(r"<!--.*?-->", "", t, flags=re.S)
    t = re.sub(r"<ref\b[^>]*/>", "", t, flags=re.I)
    t = re.sub(r"<ref\b[^>]*>.*?</ref>", "", t, flags=re.S | re.I)
    for tag in DROP_TAGS:
        t = re.sub(r"<%s\b[^>]*>.*?</%s>" % (tag, tag), "", t, flags=re.S | re.I)
    for _ in range(60):                                         # templates, innermost first
        n = re.sub(r"\{\{([^{}]*)\}\}", _template, t)
        if n == t:
            break
        t = n
    t = t.replace("{{", "").replace("}}", "")
    for _ in range(4):                                          # tables
        t = re.sub(r"\{\|.*?\|\}", "", t, flags=re.S)
    for _ in range(12):                                         # links, innermost first (file captions nest links)
        n = re.sub(r"\[\[([^\[\]]*)\]\]", _link, t)
        if n == t:
            break
        t = n
    t = re.sub(r"\[(?:https?:)?//\S+\s+([^\]]*)\]", r"\1", t)
    t = re.sub(r"\[(?:https?:)?//\S+\]", "", t)
    t = re.sub(r"'{2,5}", "", t)
    t = re.sub(r"__[A-Z_]+__", "", t)
    return postprocess(t, wikitext=True)


def postprocess(t: str, wikitext=False) -> str:
    """Headings, lists, HTML, whitespace. Shared by wikitext input and API 'explaintext' extracts."""
    t = re.sub(r"(?i)<br\s*/?>", "\n", t)
    t = re.sub(r"</?[a-zA-Z][^>]*>", "", t)
    t = html.unescape(t).replace("\u00a0", " ")
    out, drop_level = [], None
    for ln in t.splitlines():
        ln = ln.rstrip()
        m = re.match(r"^(={2,6})\s*(.*?)\s*\1\s*$", ln)
        if m:
            level, title = len(m.group(1)), m.group(2)
            if drop_level is not None and level > drop_level:
                continue
            drop_level = level if title.strip().lower() in DROP_SECTIONS else None
            if drop_level is None and title:
                out.append("")
                out.append(("■ " if level == 2 else "□ ") + title)
            continue
        if drop_level is not None:
            continue
        if wikitext:
            ln = re.sub(r"^[*#]+\s*", "・", ln)
            ln = re.sub(r"^[:;]+\s*", "", ln)
        out.append(ln)
    t = "\n".join(out)
    t = re.sub(r"[（(][\s、,;；・]*[）)]", "", t)                 # "( )" left after removing templates
    t = re.sub(r"[ \t]+\n", "\n", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()


# --------------------------------------------------------------------------- sources
def read_titles(path):
    if not path:
        return None
    titles = []
    for ln in Path(path).read_text(encoding="utf-8-sig").splitlines():
        ln = ln.strip()
        if ln and not ln.startswith("#"):
            titles.append(ln)
    return titles


def _open_any(path):
    p = str(path)
    if p.endswith(".bz2"):
        return bz2.open(p, "rb")
    if p.endswith(".gz"):
        return gzip.open(p, "rb")
    return open(p, "rb")


def iter_dump(path, wanted, args):
    """Yield dicts {title, text, url} from a MediaWiki XML dump."""
    wanted_set = set(wanted) if wanted else None
    found = 0
    with _open_any(path) as f:
        ctx = ET.iterparse(f, events=("start", "end"))
        _, root = next(ctx)
        for ev, elem in ctx:
            if ev != "end" or elem.tag.rsplit("}", 1)[-1] != "page":
                continue
            title, ns, redirect, text = None, "0", False, ""
            for ch in elem:
                tag = ch.tag.rsplit("}", 1)[-1]
                if tag == "title":
                    title = ch.text or ""
                elif tag == "ns":
                    ns = ch.text or "0"
                elif tag == "redirect":
                    redirect = True
                elif tag == "revision":
                    for r in ch:
                        if r.tag.rsplit("}", 1)[-1] == "text":
                            text = r.text or ""
            root.clear()
            if ns != "0" or redirect or not title or text.lstrip().lower().startswith("#redirect"):
                continue
            if wanted_set is not None and title not in wanted_set:
                continue
            if args.skip_disambig and DISAMBIG.search(text):
                continue
            plain = clean_wikitext(text)
            if len(plain) < args.min_chars:
                continue
            yield {"title": title, "text": plain,
                   "url": "https://%s.wikipedia.org/wiki/%s" % (args.lang, urllib.parse.quote(title.replace(" ", "_")))}
            found += 1
            if wanted_set is not None and found >= len(wanted_set):
                return
            if wanted_set is None and args.limit and found >= args.limit:
                return


def iter_extractor(paths, args):
    n = 0
    for path in paths:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line.startswith("{"):
                    continue
                o = json.loads(line)
                title, text = o.get("title", ""), o.get("text", "")
                if text.startswith(title):                       # some versions repeat the title on the first line
                    text = text[len(title):].lstrip("\n")
                text = postprocess(text)
                if not title or len(text) < args.min_chars:
                    continue
                yield {"title": title, "text": text,
                       "url": o.get("url") or "https://%s.wikipedia.org/wiki/%s" % (args.lang, urllib.parse.quote(title.replace(" ", "_")))}
                n += 1
                if args.limit and n >= args.limit:
                    return


def iter_fetch(titles, args):
    base = args.api_base or "https://%s.wikipedia.org/w/api.php" % args.lang
    for i, title in enumerate(titles):
        q = urllib.parse.urlencode({
            "action": "query", "format": "json", "prop": "extracts", "explaintext": "1", "redirects": "1",
            "titles": title, "formatversion": "2", "maxlag": "5"})
        req = urllib.request.Request(base + "?" + q, headers={"User-Agent": args.user_agent})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                data = json.load(r)
        except (urllib.error.URLError, TimeoutError, ValueError) as e:
            print(f"warning: {title}: {e}", file=sys.stderr)
            continue
        pages = data.get("query", {}).get("pages", [])
        if isinstance(pages, dict):                              # formatversion 1 style
            pages = list(pages.values())
        for pg in pages:
            if pg.get("missing") or not pg.get("extract"):
                print(f"warning: no article for '{title}'", file=sys.stderr)
                continue
            text = postprocess(pg["extract"])
            yield {"title": pg.get("title", title), "text": text,
                   "url": "https://%s.wikipedia.org/wiki/%s" % (args.lang, urllib.parse.quote(pg.get("title", title).replace(" ", "_")))}
        if args.delay and i + 1 < len(titles):
            time.sleep(args.delay)


# --------------------------------------------------------------------------- main
def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="mode", required=True)

    def common(sp):
        sp.add_argument("-o", "--output", default="WIKI.DAT")
        sp.add_argument("--lang", default="ja", help="wikipedia language code (for URLs / API), default ja")
        sp.add_argument("--max-bytes", type=int, default=20000, help="cut each article to this many bytes (device limit 32 KB)")
        sp.add_argument("--min-chars", type=int, default=100, help="skip articles with less text than this")
        sp.add_argument("--limit", type=int, default=2000, help="max number of articles (dump/extractor without a titles file)")
        sp.add_argument("--jsonl", help="also save the cleaned articles as JSONL (for wikipedia_prepare.py)")

    a = sub.add_parser("dump", help="MediaWiki XML dump (.xml, .xml.bz2, .xml.gz)")
    a.add_argument("dump")
    a.add_argument("--titles-file", help="only these titles (one per line)")
    a.add_argument("--no-skip-disambig", dest="skip_disambig", action="store_false")
    common(a)
    b = sub.add_parser("extractor", help="WikiExtractor --json output files")
    b.add_argument("files", nargs="+")
    common(b)
    c = sub.add_parser("fetch", help="download the titles in a file through the Wikipedia API")
    c.add_argument("titles_file")
    c.add_argument("--delay", type=float, default=0.3, help="seconds between requests")
    c.add_argument("--api-base", help="API URL (default https://<lang>.wikipedia.org/w/api.php)")
    c.add_argument("--user-agent", default="MemoAnkiEX-tools/1.0 (personal offline-reader converter; see project README)",
                   help="Wikimedia asks for a descriptive User-Agent with contact info: put yours here")
    common(c)
    args = p.parse_args(argv)
    args.skip_disambig = getattr(args, "skip_disambig", True)

    if args.mode == "dump":
        titles = read_titles(args.titles_file)
        gen = iter_dump(args.dump, titles, args)
    elif args.mode == "extractor":
        gen = iter_extractor(args.files, args)
    else:
        gen = iter_fetch(read_titles(args.titles_file), args)

    arts = list(gen)
    if not arts:
        print("error: no articles were produced", file=sys.stderr)
        return 1
    if args.jsonl:
        with open(args.jsonl, "w", encoding="utf-8") as f:
            for art in arts:
                f.write(json.dumps({"title": art["title"], "text": art["text"]}, ensure_ascii=False) + "\n")
    n, size, no_reading = devfmt.write_wiki_dat(arts, args.output, args.max_bytes)
    src = Path(args.output).with_name("WIKI_SOURCES.txt")
    with open(src, "w", encoding="utf-8") as f:
        f.write("Text in WIKI.DAT comes from Wikipedia (%s) and is available under CC BY-SA 4.0:\n"
                "https://creativecommons.org/licenses/by-sa/4.0/ . Authors: see each article's history.\n"
                "Text was converted to plain text and may be shortened.\n\n" % args.lang)
        for art in arts:
            f.write("%s\t%s\n" % (art["title"], art["url"]))
    print(f"Wrote {n} articles to {args.output} ({size / 1024:.0f} KB); sources listed in {src}")
    if no_reading:
        print(f"note: {no_reading} article(s) have kanji titles and no reading found: browse-only (cannot be typed)")
    devfmt.report_undisplayable([a["title"] + a["text"] for a in arts])
    return 0


if __name__ == "__main__":
    sys.exit(main())
