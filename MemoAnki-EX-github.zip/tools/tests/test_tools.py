"""Tests for the PC-side tools. Run: python3 -m unittest discover tools/tests"""
import bz2
import contextlib
import io
import json
import sqlite3
import sys
import tempfile
import threading
import unittest
import urllib.parse
import zipfile
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

TOOLS = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(TOOLS))
import anki_to_deck       # noqa: E402
import devfmt             # noqa: E402
import wikipedia_convert  # noqa: E402


def run(main, *argv):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        rc = main([str(a) for a in argv])
    return rc, out.getvalue(), err.getvalue()


def make_apkg(path, schema="legacy"):
    """A minimal Anki package: Basic (Front/Back/Example) + Cloze notes in two decks."""
    db = Path(str(path) + ".sqlite")
    db.unlink(missing_ok=True)
    con = sqlite3.connect(db)
    notes = [
        (1, 100, ["abandon", "<b>捨てる</b><br>放棄する", "He abandoned it.&nbsp;[sound:a.mp3]"], [10]),
        (2, 100, ["achieve", "達成する", ""], [10]),
        (3, 100, ["abandon", "捨てる", "dup"], [10]),                      # duplicate of note 1 front/back? (different back) -> kept
        (4, 100, ["", "empty front", ""], [10]),                           # skipped
        (5, 100, ["富士山", "Mount Fuji", ""], [11]),
        (6, 200, ["日本の首都は{{c1::東京}}で、人口は{{c2::約1400万人::数}}。", "補足", ""], [10]),
    ]
    con.executescript("create table notes(id,mid,flds,tags); create table cards(id,nid,did,ord,odid);")
    for nid, mid, flds, dids in notes:
        con.execute("insert into notes values (?,?,?,'')", (nid, mid, "\x1f".join(flds)))
        for did in dids:
            con.execute("insert into cards values (?,?,?,0,0)", (nid * 10 + did, nid, did))
    if schema == "legacy":
        models = {"100": {"name": "Basic", "type": 0, "flds": [{"name": "Front", "ord": 0}, {"name": "Back", "ord": 1}, {"name": "Example", "ord": 2}]},
                  "200": {"name": "Cloze", "type": 1, "flds": [{"name": "Text", "ord": 0}, {"name": "Extra", "ord": 1}]}}
        decks = {"10": {"name": "英語::単語"}, "11": {"name": "地名"}}
        con.execute("create table col(models,decks)")
        con.execute("insert into col values (?,?)", (json.dumps(models), json.dumps(decks)))
    else:                                                                  # new schema (anki21b)
        con.executescript("create table notetypes(id,name,config); create table fields(ntid,ord,name,config);"
                          "create table decks(id,name);")
        con.execute("insert into notetypes values (100,'Basic',x''),(200,'Cloze',x'')")
        for ntid, names in ((100, ["Front", "Back", "Example"]), (200, ["Text", "Extra"])):
            for i, n in enumerate(names):
                con.execute("insert into fields values (?,?,?,x'')", (ntid, i, n))
        con.execute("insert into decks values (10,?),(11,'地名')", ("英語\x1f単語",))
    con.commit()
    con.close()
    data = db.read_bytes()
    db.unlink()
    with zipfile.ZipFile(path, "w") as z:
        if schema == "legacy":
            z.writestr("collection.anki2", data)
        else:
            import zstandard
            z.writestr("collection.anki21b", zstandard.ZstdCompressor().compress(data))
        z.writestr("media", "{}")


class DevFmt(unittest.TestCase):
    def test_cut_utf8(self):
        self.assertEqual(devfmt.cut_utf8("あいう".encode(), 7), "あい".encode())
        self.assertEqual(devfmt.cut_utf8(b"abc", 10), b"abc")

    def test_import_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "I.DAT"
            devfmt.write_import_dat("英単語", [("a", "b", "c"), ("あ" * 100, "x", "")], f)
            name, cards = devfmt.read_import_dat(f)
            self.assertEqual(name, "英単語")
            self.assertEqual(cards[0], ("a", "b", "c"))
            self.assertLessEqual(len(cards[1][0].encode()), 127)
            self.assertTrue(cards[1][0].startswith("あ"))
            with self.assertRaises(ValueError):
                devfmt.write_import_dat("x", [("a", "b", "c")] * 601, f)

    def test_font_check(self):
        bad = devfmt.undisplayable(["漢字 abc ひらがな カタカナ ① 😀"])
        self.assertIn("😀", bad)
        self.assertNotIn("漢", bad)
        self.assertNotIn("ひ", bad)

    def test_wiki_roundtrip_and_keys(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "W.DAT"
            n, size, no_reading = devfmt.write_wiki_dat([
                {"title": "富士山", "text": "富士山(ふじさん)は山です。"},
                {"title": "カメラ", "text": "光を記録する道具。"},
                {"title": "Moon", "text": "The Moon."},
                {"title": "謎", "text": "よみなし"}], f)
            self.assertEqual((n, no_reading), (4, 1))
            rows = devfmt.read_wiki_dat(f)
            keys = [r[0] for r in rows]
            self.assertEqual(keys, sorted(keys))                       # sorted by key bytes
            self.assertIn("ふじさん", keys)
            self.assertIn("かめら", keys)                               # katakana folded to hiragana
            self.assertIn("moon", keys)
            self.assertEqual(dict((r[1], r[2]) for r in rows)["Moon"], "The Moon.")


class Anki(unittest.TestCase):
    def convert(self, apkg, *extra):
        out = Path(apkg).with_suffix(".DAT")
        rc, so, se = run(anki_to_deck.main, apkg, "-o", out, *extra)
        return rc, so, se, out

    def test_list(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "a.apkg"
            make_apkg(p)
            rc, so, _ = run(anki_to_deck.main, p, "--list")
            self.assertEqual(rc, 0)
            self.assertIn("英語::単語", so)
            self.assertIn("Cloze", so)
            self.assertIn("1: Front", so)

    def test_basic_and_cloze(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "a.apkg"
            make_apkg(p)
            rc, so, se, out = self.convert(p, "--deck", "英語")
            self.assertEqual(rc, 0, se)
            name, cards = devfmt.read_import_dat(out)
            self.assertEqual(name, "英語")
            fronts = [c[0] for c in cards]
            self.assertIn("abandon", fronts)
            first = cards[0]
            self.assertEqual(first, ("abandon", "捨てる / 放棄する", "He abandoned it."))   # html, sound, nbsp cleaned
            self.assertNotIn("", fronts)                                                  # empty-front note skipped
            self.assertNotIn("富士山", fronts)                                              # other deck excluded
            cloze = [c for c in cards if "[" in c[0]]
            self.assertEqual(len(cloze), 2)                                               # one card per cloze number
            self.assertEqual(cloze[0][0], "日本の首都は[...]で、人口は約1400万人。")
            self.assertEqual(cloze[0][1], "東京")
            self.assertEqual(cloze[1][0], "日本の首都は東京で、人口は[数]。")
            self.assertEqual(cloze[1][1], "約1400万人")
            self.assertEqual(cloze[0][2], "補足")

    def test_field_selection_model_and_batches(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "a.apkg"
            make_apkg(p)
            rc, so, se, out = self.convert(p, "--model", "Basic", "--front", "Back", "--back", "Front", "--name", "逆")
            self.assertEqual(rc, 0, se)
            name, cards = devfmt.read_import_dat(out)
            self.assertEqual(name, "逆")
            self.assertEqual(cards[0][0], "捨てる / 放棄する")
            self.assertEqual(cards[0][1], "abandon")
            rc, so, se, out = self.convert(p, "--model", "Basic", "--max-cards", "2")
            self.assertIn("--start 2", so)
            n1 = devfmt.read_import_dat(out)[1]
            rc, so, se, out2 = self.convert(p, "--model", "Basic", "--max-cards", "2", "--start", "2")
            n2 = devfmt.read_import_dat(out2)[1]
            self.assertTrue(set(n1).isdisjoint(n2))

    def test_new_format_with_zstd(self):
        try:
            import zstandard  # noqa: F401
        except ImportError:
            self.skipTest("zstandard not installed")
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "b.apkg"
            make_apkg(p, schema="new")
            rc, so, se, out = self.convert(p, "--deck", "地名")
            self.assertEqual(rc, 0, se)
            self.assertEqual(devfmt.read_import_dat(out)[1], [("富士山", "Mount Fuji", "")])

    def test_text_export(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "notes.txt"
            p.write_text("#separator:tab\n#html:true\n#columns:Front\tBack\tTags\n"
                         "犬\t<div>dog</div>\tanimals\n猫\tcat\tanimals\n", encoding="utf-8")
            rc, so, se, out = self.convert(p, "--name", "動物")
            self.assertEqual(rc, 0, se)
            self.assertEqual(devfmt.read_import_dat(out), ("動物", [("犬", "dog", "animals"), ("猫", "cat", "animals")]))
            rc, so, se, out = self.convert(p, "--name", "動物", "--example", "99")
            self.assertEqual(devfmt.read_import_dat(out)[1][0], ("犬", "dog", ""))

    def test_old_cli_still_works(self):
        import csv_to_deck
        with tempfile.TemporaryDirectory() as d:
            c = Path(d) / "x.csv"
            c.write_text("Front,Back,Example\nabandon,捨てる,ex\n", encoding="utf-8")
            out = Path(d) / "I.DAT"
            rc = run(csv_to_deck.main, c, "--deck", "t", "--dat", out)
            self.assertEqual(devfmt.read_import_dat(out), ("t", [("abandon", "捨てる", "ex")]))


DUMP = """<mediawiki xmlns="http://www.mediawiki.org/xml/export-0.11/"><siteinfo/>
<page><title>富士山</title><ns>0</ns><revision><text>{{Infobox}}'''富士山'''(ふじさん)は[[静岡県]]と[[山梨県]]にまたがる日本一高い山である。標高は3776メートル。{{Reflist}}
== 脚注 ==
<references/>
</text></revision></page>
<page><title>Fuji</title><ns>0</ns><redirect title="富士山"/><revision><text>#REDIRECT [[富士山]]</text></revision></page>
<page><title>富士 (曖昧さ回避)</title><ns>0</ns><revision><text>{{aimai}} 富士は次の意味を持つ。ここには十分に長い説明が書かれているものとする。ここには十分に長い説明が書かれているものとする。</text></revision></page>
<page><title>ノート:富士山</title><ns>1</ns><revision><text>議論 議論 議論 議論 議論 議論 議論 議論 議論 議論 議論 議論 議論 議論 議論 議論 議論 議論 議論 議論 議論 議論 議論</text></revision></page>
<page><title>短い</title><ns>0</ns><revision><text>短い。</text></revision></page>
<page><title>Moon</title><ns>0</ns><revision><text>The [[Moon]] is Earth's only natural satellite. It circles the Earth about once every 27 days and shows different phases.</text></revision></page>
</mediawiki>"""


class Wiki(unittest.TestCase):
    def test_clean_wikitext(self):
        t = ("{{Infobox|a=b}}'''東京'''(とうきょう、{{lang|en|Tokyo}})は[[日本]]の[[首都|首都圏]]。<ref>x</ref>\n"
             "[[ファイル:a.jpg|thumb|[[写真]]]]\n== 歴史 ==\n* 古い\n== 外部リンク ==\n* [http://e.org 公式]\n[[Category:都市]]\n[[en:Tokyo]]")
        out = wikipedia_convert.clean_wikitext(t)
        self.assertIn("東京(とうきょう、Tokyo)は日本の首都圏。", out)
        self.assertIn("■ 歴史", out)
        self.assertIn("・古い", out)
        for bad in ("公式", "写真", "Category", "en:", "{{", "[["):
            self.assertNotIn(bad, out)

    def test_dump_titles_and_filters(self):
        with tempfile.TemporaryDirectory() as d:
            x = Path(d) / "dump.xml.bz2"
            x.write_bytes(bz2.compress(DUMP.encode("utf-8")))
            out = Path(d) / "W.DAT"
            rc, so, se = run(wikipedia_convert.main, "dump", x, "-o", out, "--min-chars", "30")
            self.assertEqual(rc, 0, se)
            rows = devfmt.read_wiki_dat(out)
            titles = sorted(r[1] for r in rows)
            self.assertEqual(titles, ["Moon", "富士山"])                 # redirect, disambig, ns!=0, stub dropped
            fuji = [r for r in rows if r[1] == "富士山"][0]
            self.assertEqual(fuji[0], "ふじさん")                       # reading taken from the lead
            self.assertNotIn("脚注", fuji[2])
            src = (Path(d) / "WIKI_SOURCES.txt").read_text(encoding="utf-8")
            self.assertIn("https://ja.wikipedia.org/wiki/", src)
            self.assertIn("CC BY-SA", src)
            tf = Path(d) / "t.txt"
            tf.write_text("# wanted\nMoon\n", encoding="utf-8")
            rc, so, se = run(wikipedia_convert.main, "dump", x, "--titles-file", tf, "-o", out, "--min-chars", "30")
            self.assertEqual([r[1] for r in devfmt.read_wiki_dat(out)], ["Moon"])

    def test_extractor(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "wiki_00"
            long = "東京(とうきょう)は日本の首都です。" * 10
            f.write_text(json.dumps({"id": "1", "url": "https://ja.wikipedia.org/wiki?curid=1", "title": "東京", "text": "東京\n\n" + long}, ensure_ascii=False) + "\n"
                         + json.dumps({"id": "2", "title": "短い", "text": "短い"}, ensure_ascii=False) + "\n", encoding="utf-8")
            out = Path(d) / "W.DAT"
            rc, so, se = run(wikipedia_convert.main, "extractor", f, "-o", out)
            self.assertEqual(rc, 0, se)
            rows = devfmt.read_wiki_dat(out)
            self.assertEqual(len(rows), 1)
            self.assertTrue(rows[0][2].startswith("東京(とうきょう)"))     # duplicated title line removed
            self.assertEqual(rows[0][0], "とうきょう")

    def test_fetch_with_mock_api(self):
        seen = []

        class H(BaseHTTPRequestHandler):
            def do_GET(self):
                q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                seen.append((q["titles"][0], self.headers.get("User-Agent")))
                title = q["titles"][0]
                if title == "無い記事":
                    body = {"query": {"pages": [{"title": title, "missing": True}]}}
                else:
                    body = {"query": {"pages": [{"pageid": 1, "title": title, "extract":
                            "%s(よみ)は説明です。" % title + "とても長い説明文です。" * 10 + "\n\n\n== 歴史 ==\n昔の話。\n== 関連項目 ==\n別の記事"}]}}
                data = json.dumps(body).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(data)

            def log_message(self, *a):
                pass

        srv = HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            with tempfile.TemporaryDirectory() as d:
                tf = Path(d) / "t.txt"
                tf.write_text("桜\n無い記事\n", encoding="utf-8")
                out = Path(d) / "W.DAT"
                rc, so, se = run(wikipedia_convert.main, "fetch", tf, "-o", out, "--delay", "0",
                                 "--api-base", "http://127.0.0.1:%d/w/api.php" % srv.server_port, "--user-agent", "test-agent/1.0")
                self.assertEqual(rc, 0, se)
                self.assertIn("no article for '無い記事'", se)
                rows = devfmt.read_wiki_dat(out)
                self.assertEqual([r[1] for r in rows], ["桜"])
                self.assertIn("■ 歴史", rows[0][2])
                self.assertNotIn("別の記事", rows[0][2])                  # "関連項目" section dropped
                self.assertTrue(all(ua == "test-agent/1.0" for _, ua in seen))
        finally:
            srv.shutdown()


if __name__ == "__main__":
    unittest.main()
