"""Write IMPORT.DAT / WIKI.DAT made by the real converters from synthetic Anki / dump data
(used by tools/sim/run_sim.sh to check that the device code reads what the tools write).
Usage: make_fixtures.py OUTDIR"""
import bz2
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import anki_to_deck
import wikipedia_convert
from test_tools import DUMP, make_apkg

out = Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory() as d:
    apkg = Path(d) / "a.apkg"
    make_apkg(apkg)
    assert anki_to_deck.main([str(apkg), "--deck", "英語", "-o", str(out / "IMPORT.DAT")]) == 0
    dump = Path(d) / "dump.xml.bz2"
    dump.write_bytes(bz2.compress(DUMP.encode("utf-8")))
    assert wikipedia_convert.main(["dump", str(dump), "-o", str(out / "WIKI.DAT"), "--min-chars", "30"]) == 0
