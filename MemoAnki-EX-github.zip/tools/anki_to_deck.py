#!/usr/bin/env python3
"""Convert an Anki deck into IMPORT.DAT for MemoAnki EX.

Accepted input
  *.apkg   Anki package ("Export... > Anki Deck Package"). Tick "Support older Anki versions" when exporting
           if you can: that gives the most compatible file. Newer exports (collection.anki21b) need
           `pip install zstandard` and are less tested.
  *.txt / *.tsv / *.csv   "Notes in Plain Text" export, or any delimited text (UTF-8).

Examples
  anki_to_deck.py my.apkg --list                       show decks, note types, fields and counts
  anki_to_deck.py my.apkg --deck "英単語" -o IMPORT.DAT
  anki_to_deck.py my.apkg --model Basic --front Front --back Back --example 3
  anki_to_deck.py notes.txt --name "My words" -o IMPORT.DAT

Fields are chosen by name or by 1-based number (default: 1 = front, 2 = back, 3 = example).
Cloze notes become one card per cloze: the front shows the sentence with [...], the back the answer.
HTML, images and [sound:] tags are removed. The device imports at most 600 cards per file: use --start N
to write the next batch. Characters the device font cannot draw are listed (they appear as '?').
"""
import argparse
import csv
import html
import io
import json
import re
import sqlite3
import sys
import tempfile
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import devfmt

CLOZE = re.compile(r"\{\{c(\d+)::(.*?)(?:::(.*?))?\}\}", re.S)


# --------------------------------------------------------------------------- text cleanup
def clean(text: str, newline: str = " / ") -> str:
    """Anki field (HTML) -> plain single-line text."""
    t = re.sub(r"\[sound:[^\]]*\]", "", text)
    t = re.sub(r"(?is)<(script|style)\b.*?</\1>", "", t)
    t = re.sub(r"(?i)<br\s*/?>|</(div|p|li|tr|h[1-6])>", "\n", t)
    t = re.sub(r"<[^>]+>", "", t)
    t = html.unescape(t).replace("\u00a0", " ")
    lines = [re.sub(r"[ \t\u3000]+", " ", ln).strip() for ln in t.splitlines()]
    return newline.join(ln for ln in lines if ln)


def cloze_cards(text: str):
    """Yield (front, back) for every cloze number in `text` (raw, may contain HTML)."""
    nums = sorted({int(m.group(1)) for m in CLOZE.finditer(text)})
    for n in nums:
        answers = []

        def hide(m):
            if int(m.group(1)) == n:
                answers.append(m.group(2))
                return "[%s]" % (m.group(3) if m.group(3) else "...")
            return m.group(2)

        front = CLOZE.sub(hide, text)
        yield front, " / ".join(answers)


# --------------------------------------------------------------------------- reading collections
class Note:
    __slots__ = ("nid", "model", "fields", "deck_ids")

    def __init__(self, nid, model, fields, deck_ids):
        self.nid, self.model, self.fields, self.deck_ids = nid, model, fields, deck_ids


class Collection:
    def __init__(self):
        self.models = {}     # mid -> {"name": str, "fields": [names], "cloze": bool}
        self.decks = {}      # did -> name
        self.notes = []


def _open_db(apkg: Path):
    z = zipfile.ZipFile(apkg)
    names = set(z.namelist())
    for cand in ("collection.anki21b", "collection.anki21", "collection.anki2"):
        if cand in names:
            break
    else:
        raise SystemExit("error: no collection.* inside the package (is it really an .apkg?)")
    data = z.read(cand)
    if cand.endswith("21b"):
        try:
            import zstandard
        except ImportError:
            raise SystemExit("error: this package uses the new format. Run `pip install zstandard`, or export again "
                             "with \"Support older Anki versions\" ticked, or use \"Notes in Plain Text\".")
        data = zstandard.ZstdDecompressor().stream_reader(io.BytesIO(data)).read()
    tmp = tempfile.NamedTemporaryFile(suffix=".sqlite", delete=False)
    tmp.write(data)
    tmp.close()
    return sqlite3.connect(tmp.name), tmp.name


def read_apkg(path: Path) -> Collection:
    db, tmpname = _open_db(path)
    try:
        col = Collection()
        tables = {r[0] for r in db.execute("select name from sqlite_master where type='table'")}
        if "notetypes" in tables:                                  # new schema (Anki >= 2.1.50, collection.anki21b)
            for ntid, name in db.execute("select id, name from notetypes"):
                col.models[ntid] = {"name": name, "fields": [], "cloze": False}
            for ntid, ord_, name in db.execute("select ntid, ord, name from fields order by ntid, ord"):
                col.models[ntid]["fields"].append(name)
            for did, name in db.execute("select id, name from decks"):
                col.decks[did] = name.replace("\x1f", "::")
        else:                                                      # legacy schema: JSON in the col table
            models, decks = db.execute("select models, decks from col").fetchone()
            for mid, m in json.loads(models).items():
                flds = [f["name"] for f in sorted(m["flds"], key=lambda f: f["ord"])]
                col.models[int(mid)] = {"name": m["name"], "fields": flds, "cloze": m.get("type") == 1}
            for did, d in json.loads(decks).items():
                col.decks[int(did)] = d["name"]
        cards_of = {}
        cols = {r[1] for r in db.execute("pragma table_info(cards)")}
        for nid, did, odid in db.execute("select nid, did, %s from cards" % ("odid" if "odid" in cols else "0")):
            cards_of.setdefault(nid, set()).add(odid or did)
        for nid, mid, flds in db.execute("select id, mid, flds from notes order by id"):
            col.notes.append(Note(nid, mid, flds.split("\x1f"), cards_of.get(nid, set())))
        return col
    finally:
        db.close()
        Path(tmpname).unlink(missing_ok=True)


def read_text_export(path: Path) -> Collection:
    """Anki 'Notes in Plain Text' (with #header lines) or plain CSV/TSV."""
    raw = path.read_text(encoding="utf-8-sig")
    header, body = {}, []
    for ln in raw.splitlines():
        if ln.startswith("#") and ":" in ln:
            k, v = ln[1:].split(":", 1)
            header[k.strip().lower()] = v.strip("\r\n")
        elif ln.strip():
            body.append(ln)
    sepname = header.get("separator", "")
    sep = {"tab": "\t", "comma": ",", "semicolon": ";", "space": " ", "pipe": "|", "colon": ":"}.get(sepname.lower())
    if sep is None:
        first = body[0] if body else ""
        sep = "\t" if "\t" in first else ("," if "," in first else ";")
    rows = list(csv.reader(io.StringIO("\n".join(body)), delimiter=sep))
    names = [n for n in header.get("columns", "").split(sep)] if "columns" in header else []
    width = max((len(r) for r in rows), default=0)
    if len(names) < width:
        names += ["Field %d" % (i + 1) for i in range(len(names), width)]
    col = Collection()
    col.models[0] = {"name": "text file", "fields": names, "cloze": False}
    col.decks[0] = path.stem
    for i, r in enumerate(rows):
        col.notes.append(Note(i, 0, r, {0}))
    return col


# --------------------------------------------------------------------------- selection
def field_index(spec, names, default):
    """spec: None, '2' (1-based) or a field name. Returns a 0-based index or None."""
    if spec is None:
        return default
    if spec.isdigit():
        return int(spec) - 1
    for i, n in enumerate(names):
        if n.lower() == spec.lower():
            return i
    return None


def deck_matches(name: str, wanted: str) -> bool:
    return name == wanted or name.startswith(wanted + "::") or wanted.lower() in name.lower()


def build_cards(col, args):
    cards, seen, skipped = [], set(), 0
    for note in col.notes:
        model = col.models.get(note.model, {"name": "?", "fields": [], "cloze": False})
        if args.model and args.model.lower() not in model["name"].lower():
            continue
        if args.deck and not any(deck_matches(col.decks.get(d, ""), args.deck) for d in note.deck_ids):
            continue
        names = model["fields"]
        fi = field_index(args.front, names, 0)
        bi = field_index(args.back, names, 1)
        ei = field_index(args.example, names, 2)
        flds = note.fields

        def get(i):
            return flds[i] if i is not None and 0 <= i < len(flds) else ""

        pairs = []
        if CLOZE.search(get(fi)):
            extra = clean(get(bi if bi is not None else 1))
            pairs = [(clean(f, args.newline), clean(b, args.newline), extra) for f, b in cloze_cards(get(fi))]
        else:
            front, back = clean(get(fi), args.newline), clean(get(bi), args.newline)
            if not front or not back:
                skipped += 1
                continue
            pairs = [(front, back, clean(get(ei), args.newline) if ei is not None and ei != fi and ei != bi else "")]
        for p in pairs:
            if (p[0], p[1]) in seen:
                continue
            seen.add((p[0], p[1]))
            cards.append(p)
    return cards, skipped


def print_listing(col):
    print("Decks:")
    for did, name in sorted(col.decks.items(), key=lambda kv: kv[1]):
        n = sum(1 for nt in col.notes if did in nt.deck_ids)
        print(f"  {name}  ({n} notes)")
    print("Note types:")
    for mid, m in col.models.items():
        n = sum(1 for nt in col.notes if nt.model == mid)
        if n:
            print(f"  {m['name']}  ({n} notes){' [cloze]' if m['cloze'] else ''}")
            for i, f in enumerate(m["fields"], 1):
                print(f"      {i}: {f}")


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("input", help=".apkg, or text export (.txt/.tsv/.csv)")
    p.add_argument("-o", "--output", default="IMPORT.DAT")
    p.add_argument("--list", action="store_true", help="only list decks, note types and fields")
    p.add_argument("--deck", help="only notes with a card in this deck (name or part of it; includes sub-decks)")
    p.add_argument("--model", help="only this note type (name or part of it)")
    p.add_argument("--front", help="front field: name or 1-based number (default 1)")
    p.add_argument("--back", help="back field (default 2)")
    p.add_argument("--example", help="example field (default 3 if it exists)")
    p.add_argument("--name", help="deck name on the device (default: the Anki deck name)")
    p.add_argument("--newline", default=" / ", help="what to put between lines of a field (default ' / ')")
    p.add_argument("--max-cards", type=int, default=devfmt.MAX_IMPORT_CARDS)
    p.add_argument("--start", type=int, default=0, help="skip this many cards (for the next batch)")
    args = p.parse_args(argv)

    path = Path(args.input)
    col = read_apkg(path) if path.suffix.lower() == ".apkg" else read_text_export(path)
    if args.list:
        print_listing(col)
        return 0

    cards, skipped = build_cards(col, args)
    if not cards:
        print("error: no cards selected. Use --list to see decks / note types / fields.", file=sys.stderr)
        return 1
    total = len(cards)
    batch = cards[args.start:args.start + min(args.max_cards, devfmt.MAX_IMPORT_CARDS)]
    name = args.name or (args.deck if args.deck else next(iter(col.decks.values()), path.stem))
    if name.endswith("Default") and len(col.decks) > 1:
        name = path.stem
    n = devfmt.write_import_dat(name, batch, args.output)
    print(f"Wrote {n} of {total} cards to {args.output} (deck name \"{name}\")")
    if skipped:
        print(f"note: {skipped} note(s) skipped (empty front or back)")
    if args.start + n < total:
        print(f"note: {total - args.start - n} more card(s): run again with --start {args.start + n} (and an output name like IMPORT2.DAT: the device lists every IMPORT*.DAT)")
    devfmt.report_undisplayable([c for card in batch for c in card])
    return 0


if __name__ == "__main__":
    sys.exit(main())
