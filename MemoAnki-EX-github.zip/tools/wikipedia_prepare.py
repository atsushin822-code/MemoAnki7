#!/usr/bin/env python3
"""Build WIKI.DAT (offline articles for the device) from a JSONL file you already have.

Input: JSONL, one object per line: {"title": "...", "text": "...", "reading": "..."(optional)}
Need to get articles first? See wikipedia_convert.py (dump / WikiExtractor / API).

Search keys: the device searches by typing (romaji becomes hiragana), so every article needs a key made of
ASCII / hiragana: `reading` if given; for Japanese titles with kanji the first "(よみ)" of the text is used;
otherwise the title itself (such articles can only be browsed).
If you use Wikipedia text, follow its licence (CC BY-SA) and keep attribution.
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import devfmt


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("input")
    p.add_argument("-o", "--output", required=True, help="e.g. WIKI.DAT")
    p.add_argument("--max-bytes", type=int, default=20000, help="cut each article to this many bytes (device reads at most 32 KB)")
    args = p.parse_args(argv)

    arts = []
    with open(args.input, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                arts.append(json.loads(line))
    n, size, no_reading = devfmt.write_wiki_dat(arts, args.output, args.max_bytes)
    print(f"Wrote {n} articles to {args.output} ({size} bytes)")
    if no_reading:
        print(f"note: {no_reading} article(s) have kanji titles without a reading: they can be browsed but not typed")
    devfmt.report_undisplayable([a["title"] + a.get("text", "") for a in arts])


if __name__ == "__main__":
    main()
