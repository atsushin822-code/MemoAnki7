#!/usr/bin/env python3
"""Convert the simulator's P6 .ppm screenshots to .png (standard library only)."""
import struct, sys, zlib
from pathlib import Path

def convert(src: Path, dst: Path, scale: int = 2) -> None:
    data = src.read_bytes()
    parts = data.split(b"\n", 3)
    w, h = map(int, parts[1].split())
    pix = parts[3]
    rows = []
    for y in range(h):
        row = pix[y * w * 3:(y + 1) * w * 3]
        if scale > 1:
            row = b"".join(row[x * 3:x * 3 + 3] * scale for x in range(w))
        rows.extend([b"\x00" + row] * scale)
    raw = b"".join(rows)
    def chunk(tag, body):
        c = struct.pack(">I", len(body)) + tag + body
        return c + struct.pack(">I", zlib.crc32(tag + body) & 0xFFFFFFFF)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w * scale, h * scale, 8, 2, 0, 0, 0)) \
          + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
    dst.write_bytes(png)

if __name__ == "__main__":
    for d in sys.argv[1:]:
        for ppm in sorted(Path(d).glob("*.ppm")):
            convert(ppm, ppm.with_suffix(".png"))
            ppm.unlink()
