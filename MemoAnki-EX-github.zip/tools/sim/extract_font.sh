#!/bin/sh
# Extract the device's built-in 8x12 ASCII font from libdataplus (needs $DEVKITPRO / $DEVKITSH4).
# Used only by the host simulator so that screenshots look like the real LCD text.
set -e
OUT="${1:-tools/sim/font8x12.bin}"
TMP="$(mktemp -d)"
( cd "$TMP" && sh-elf-ar x "$DEVKITPRO/libdataplus/lib/libgraphics.a" text.o \
  && sh-elf-objcopy -O binary -j .rodata text.o font.bin )
cp "$TMP/font.bin" "$OUT"
rm -rf "$TMP"
test "$(wc -c < "$OUT")" -eq 1140
