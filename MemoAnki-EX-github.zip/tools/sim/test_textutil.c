/* Unit tests for src/textutil.c and src/editor.c (host). */
#include "../../src/textutil.h"
#include "../../src/editor.h"
#include "../../src/platform.h"
#include "../../src/jfont.h"
#include <stdio.h>
#include <string.h>

static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

/* type a string of keys into a fresh editor in the given mode; returns the text */
static const char *type(int mode, const char *keys) {
    static char buf[128];
    Editor e;
    buf[0] = 0;
    editor_init(&e, buf, sizeof buf);
    e.mode = mode;
    for (; *keys; ++keys) editor_key(&e, *keys);
    editor_commit(&e);
    return buf;
}

int main(void) {
    static WrapLine L[6];
    char b[64];
    int n;
    unsigned int vis;
    const char *p;

    /* --- UTF-8 basics --- */
    p = "a\xE3\x81\x82z";                                  /* a あ z */
    CHECK(text_cells(p) == 3);
    CHECK(text_next(&p) == 'a' && text_next(&p) == 0x3042 && text_next(&p) == 'z' && text_next(&p) == 0);
    b[0] = 0; text_append(b, sizeof b, 0x3042); text_append(b, sizeof b, 'x');
    CHECK(strcmp(b, "\xE3\x81\x82x") == 0);

    text_sanitize(b, "tab\there\x01", sizeof b);           CHECK(strcmp(b, "tab here ") == 0);
    text_sanitize(b, "ok\xFF" "ok", sizeof b);             CHECK(strcmp(b, "ok?ok") == 0);
    text_copy(b, "hello", 4);                               CHECK(strcmp(b, "hel") == 0);
    text_copy(b, "\xE3\x81\x82\xE3\x81\x84", 5);            /* 5 bytes: only あ (3) fits, い must not be cut */
    CHECK(strcmp(b, "\xE3\x81\x82") == 0);
    text_copy_cells(b, "\xE3\x81\x82\xE3\x81\x84\xE3\x81\x86", 2, sizeof b);
    CHECK(strcmp(b, "\xE3\x81\x82\xE3\x81\x84") == 0);

    /* --- line breaking --- */
    CHECK(text_next_line("ab\ncd", 5, 10, &vis) == 3 && vis == 2);              /* newline */
    CHECK(text_next_line("hello world foo", 15, 8, &vis) == 6 && vis == 5);     /* break at a space */
    CHECK(text_next_line("abcdefghij", 10, 4, &vis) == 4 && vis == 4);         /* hard break */
    {
        const char *jp = "\xE3\x81\x82\xE3\x81\x84\xE3\x81\x86\xE3\x81\x88\xE3\x81\x8A";   /* あいうえお */
        CHECK(text_next_line(jp, 15, 3, &vis) == 9 && vis == 9);                /* 3 chars = 9 bytes */
    }
    n = text_wrap("", L, 6, 60);                       CHECK(n == 0);
    n = text_wrap("short line", L, 6, 60);             CHECK(n == 1 && !strcmp(L[0], "short line"));
    n = text_wrap("aaaaaaaaaa bbbbbbbbbb cccccccccc dddddddddd eeeeeeeeee ffffffffff gggggggggg", L, 6, 60);
    CHECK(n == 2 && !strcmp(L[0], "aaaaaaaaaa bbbbbbbbbb cccccccccc dddddddddd eeeeeeeeee") && !strcmp(L[1], "ffffffffff gggggggggg"));
    {
        char longword[200];
        memset(longword, 'x', 150); longword[150] = 0;
        n = text_wrap(longword, L, 6, 60);
        CHECK(n == 3 && strlen(L[0]) == 60 && strlen(L[1]) == 60 && strlen(L[2]) == 30);
        n = text_wrap(longword, L, 2, 60);             CHECK(n == 2);
    }
    CHECK(text_contains_ci("Achieve", "CHI") && !text_contains_ci("Achieve", "xyz") && text_contains_ci("abc", ""));

    /* --- search keys --- */
    text_make_key(b, "Fuji\xE3\x82\xB5\xE3\x83\xB3", sizeof b);                 /* Fujiサン */
    CHECK(strcmp(b, "fuji\xE3\x81\x95\xE3\x82\x93") == 0);                      /* fujiさん */

    /* --- romaji editor --- */
    CHECK(!strcmp(type(ED_ABC, "abc"), "abc"));
    CHECK(!strcmp(type(ED_CAPS, "abc"), "ABC"));
    CHECK(!strcmp(type(ED_HIRA, "aiueo"), "あいうえお"));
    CHECK(!strcmp(type(ED_HIRA, "nihongo"), "にほんご"));
    CHECK(!strcmp(type(ED_HIRA, "kyou"), "きょう"));
    CHECK(!strcmp(type(ED_HIRA, "shashin"), "しゃしん"));
    CHECK(!strcmp(type(ED_HIRA, "konnichiha"), "こんにちは"));
    CHECK(!strcmp(type(ED_HIRA, "kanpai"), "かんぱい"));
    CHECK(!strcmp(type(ED_HIRA, "kitte"), "きって"));
    CHECK(!strcmp(type(ED_HIRA, "nn"), "ん"));
    CHECK(!strcmp(type(ED_HIRA, "sakun"), "さくん"));                           /* trailing n is committed */
    CHECK(!strcmp(type(ED_HIRA, "chizu"), "ちず"));
    CHECK(!strcmp(type(ED_HIRA, "tsukue"), "つくえ"));
    CHECK(!strcmp(type(ED_HIRA, "jikan"), "じかん"));
    CHECK(!strcmp(type(ED_HIRA, "xtu"), "っ"));
    CHECK(!strcmp(type(ED_HIRA, "qa"), "あ"));                                  /* unknown letter ignored */
    CHECK(!strcmp(type(ED_KATA, "kamera"), "カメラ"));
    {
        char buf[64]; Editor e;
        buf[0] = 0; editor_init(&e, buf, sizeof buf); e.mode = ED_HIRA;
        editor_key(&e, 'k'); CHECK(!strcmp(e.pend, "k") && buf[0] == 0);
        editor_key(&e, K_BKSP); CHECK(e.pend[0] == 0);                          /* backspace clears pending first */
        editor_key(&e, 'a'); editor_key(&e, K_BKSP); CHECK(buf[0] == 0);        /* then removes a whole character */
        editor_key(&e, K_F2); CHECK(!strcmp(buf, "ー"));
        editor_key(&e, K_F1); CHECK(e.mode == ED_KATA);
    }

    /* --- font --- */
    CHECK(jfont_glyph(0x3042) != 0);          /* あ */
    CHECK(jfont_glyph(0x6F22) != 0);          /* 漢 */
    CHECK(jfont_glyph(0x6368) != 0);          /* 捨 */
    CHECK(jfont_glyph(0x30FC) != 0);          /* ー */
    CHECK(jfont_glyph('a') == 0);
    CHECK(jfont_glyph(0x20000 & 0xFFFF) == 0 || 1);

    printf("textutil/editor/font: %s\n", fails ? "FAILED" : "all passed");
    return fails ? 1 : 0;
}
