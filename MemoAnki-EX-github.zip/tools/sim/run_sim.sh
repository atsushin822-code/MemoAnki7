#!/bin/sh
# Build the host simulator and run every script in tools/sim/scripts.
# Output: tools/sim/out/<script>/*.png (screenshots of the real UI code).
set -e
cd "$(dirname "$0")/../.."
OUT=tools/sim/out
rm -rf "$OUT"; mkdir -p "$OUT"
[ -f tools/sim/font8x12.bin ] || { [ -n "$DEVKITPRO" ] && tools/sim/extract_font.sh || true; }
export SIM_FONT=tools/sim/font8x12.bin

SRCS=$(ls src/*.c | grep -v -e '/main.c' -e '/platform.c')
cc -std=gnu11 -Wall -Wextra -Wno-unused-parameter -g -fsanitize=address,undefined \
   -Isrc -o "$OUT/sim" tools/sim/sim_main.c tools/sim/platform_sim.c $SRCS

cc -std=gnu11 -Wall -Wextra -g -fsanitize=address,undefined -o "$OUT/test_textutil" \
   tools/sim/test_textutil.c src/textutil.c src/editor.c src/jfont.c src/jfont_data.c
"$OUT/test_textutil"

# PC-side tools: unit tests
python3 -m unittest discover tools/tests 2>&1 | tail -3

# Scripts run in file-name order and share one data directory (so 02_* sees what 01_* saved),
# except *_nomem scripts, which start from an empty directory with memory-pool allocation failing.
mkdir -p "$OUT/data"
# device data files used by the Import / Wikipedia screens
python3 tools/csv_to_deck.py data/decks/sample.csv --deck "英単語" --dat "$OUT/data/IMPORT.DAT" >/dev/null
python3 tools/wikipedia_prepare.py data/wikipedia/sample.jsonl -o "$OUT/data/WIKI.DAT" >/dev/null
for s in tools/sim/scripts/*.txt; do
    name=$(basename "$s" .txt)
    mkdir -p "$OUT/$name"; unset SIM_CASESENS
    case "$name" in
        *_conv)  export MEMANKI_DATA="$OUT/data_conv"; rm -rf "$MEMANKI_DATA"; unset SIM_NOMEM
                 python3 tools/tests/make_fixtures.py "$MEMANKI_DATA" >/dev/null ;;
        *_multi) export MEMANKI_DATA="$OUT/data_multi"; rm -rf "$MEMANKI_DATA"; mkdir -p "$MEMANKI_DATA"; unset SIM_NOMEM SIM_NOLIST
                 cp tools/tests/fixtures/IMPORT.CSV "$MEMANKI_DATA/IMPORT.CSV"
                 cp tools/tests/fixtures/IMPORT2.CSV "$MEMANKI_DATA/IMPORT2.CSV"
                 cp tools/tests/fixtures/IMPORT2.CSV "$MEMANKI_DATA/words.csv"
                 printf 'Front,Back\nsolo,ひとり\n' > "$MEMANKI_DATA/words.csv"
                 python3 tools/csv_to_deck.py data/decks/sample.csv --deck "x" --dat "$MEMANKI_DATA/IMPORT.DAT" >/dev/null
                 python3 tools/wikipedia_prepare.py data/wikipedia/sample.jsonl -o "$MEMANKI_DATA/WIKI.DAT" >/dev/null
                 echo hi > "$MEMANKI_DATA/readme.txt" ;;
        *_lowernolist) export MEMANKI_DATA="$OUT/data_lower"; rm -rf "$MEMANKI_DATA"; mkdir -p "$MEMANKI_DATA"; export SIM_NOLIST=1; unset SIM_NOMEM
                 cp tools/tests/fixtures/IMPORT.CSV "$MEMANKI_DATA/import.csv"
                 python3 tools/csv_to_deck.py data/decks/sample.csv --deck "x" --dat "$MEMANKI_DATA/import2.dat" >/dev/null
                 cp tools/tests/fixtures/IMPORT2.CSV "$MEMANKI_DATA/words.csv" ;;
        *_nolist) export MEMANKI_DATA="$OUT/data_nolist"; rm -rf "$MEMANKI_DATA"; mkdir -p "$MEMANKI_DATA"; export SIM_NOLIST=1; unset SIM_NOMEM
                 cp tools/tests/fixtures/IMPORT.CSV "$MEMANKI_DATA/IMPORT.CSV"
                 cp tools/tests/fixtures/IMPORT2.CSV "$MEMANKI_DATA/IMPORT2.CSV"
                 cp tools/tests/fixtures/IMPORT2.CSV "$MEMANKI_DATA/words.csv" ;;
        *_lowerimport) export MEMANKI_DATA="$OUT/data_lowerimport"; rm -rf "$MEMANKI_DATA"; mkdir -p "$MEMANKI_DATA"; unset SIM_NOMEM SIM_NOLIST; export SIM_CASESENS=1
                 cp tools/tests/fixtures/IMPORT.CSV "$MEMANKI_DATA/import.csv"
                 cp tools/tests/fixtures/IMPORT2.CSV "$MEMANKI_DATA/MyWords.Csv"
                 python3 tools/csv_to_deck.py data/decks/sample.csv --deck "x" --dat "$MEMANKI_DATA/Import2.Dat" >/dev/null
                 python3 tools/wikipedia_prepare.py data/wikipedia/sample.jsonl -o "$MEMANKI_DATA/wiki.dat" >/dev/null
                 echo hi > "$MEMANKI_DATA/readme.txt" ;;
        *_lowerfiles) export MEMANKI_DATA="$OUT/data_lowerfiles"; rm -rf "$MEMANKI_DATA"; mkdir -p "$MEMANKI_DATA"; unset SIM_NOMEM SIM_NOLIST; export SIM_CASESENS=1
                 printf 'Memo\nhello\n' > "$MEMANKI_DATA/note.txt"
                 printf 'Memo2\n' > "$MEMANKI_DATA/Mixed.Txt"
                 printf '<html><body>Hi</body></html>' > "$MEMANKI_DATA/page.htm"
                 printf '<html><body>Hi2</body></html>' > "$MEMANKI_DATA/long.html"
                 printf 'a,b\n1,2\n' > "$MEMANKI_DATA/data.csv" ;;
        *_files) export MEMANKI_DATA="$OUT/data_files"; rm -rf "$MEMANKI_DATA"; mkdir -p "$MEMANKI_DATA"; unset SIM_NOMEM SIM_NOLIST
                 printf 'Memo\nhello world\n' > "$MEMANKI_DATA/NOTE.TXT"
                 mkdir -p "$MEMANKI_DATA/src_html"
                 python3 - "$MEMANKI_DATA/src_html" <<'PY'
import sys
from PIL import Image, ImageDraw
d = sys.argv[1]
im = Image.new("RGB", (200, 60), (255, 200, 0))
g = ImageDraw.Draw(im); g.rectangle((10, 10, 90, 50), fill=(200, 0, 0)); g.ellipse((110, 10, 190, 50), fill=(0, 90, 200))
im.save(d + "/pic.png")
open(d + "/style.css", "w").write("body{background:#ffffee} .red{color:red} h1{text-align:center;color:#006} .hide{display:none}")
open(d + "/index.html", "w").write('<html><head><title>T</title><link rel="stylesheet" href="style.css"></head><body><h1>Title</h1><p class="red">Hello &amp; <b>bye</b></p><p class="hide">SECRET</p><p>Plain text</p><img src="pic.png"><p><a href="p2.html">next</a></p></body></html>')
open(d + "/p2.html", "w").write("<p>Page two</p>")
PY
                 python3 tools/html_prepare.py "$MEMANKI_DATA/src_html/index.html" -o "$MEMANKI_DATA" >/dev/null
                 printf 'item,qty\napple,3\npear,4\n"a,b",5\n' > "$MEMANKI_DATA/SHEET.CSV" ;;
        *_csv)   export MEMANKI_DATA="$OUT/data_csv"; rm -rf "$MEMANKI_DATA"; mkdir -p "$MEMANKI_DATA"; unset SIM_NOMEM
                 cp tools/tests/fixtures/IMPORT.CSV "$MEMANKI_DATA/IMPORT.CSV" ;;
        *_sjis)  export MEMANKI_DATA="$OUT/data_sjis"; rm -rf "$MEMANKI_DATA"; mkdir -p "$MEMANKI_DATA"; unset SIM_NOMEM
                 cp tools/tests/fixtures/IMPORT_sjis.CSV "$MEMANKI_DATA/IMPORT.CSV" ;;
        *_nomem) export MEMANKI_DATA="$OUT/data_nomem"; rm -rf "$MEMANKI_DATA"; mkdir -p "$MEMANKI_DATA"; export SIM_NOMEM=1 ;;
        *)       export MEMANKI_DATA="$OUT/data"; unset SIM_NOMEM ;;
    esac
    echo "== $name"
    "$OUT/sim" "$s" "$OUT/$name"
done
python3 tools/sim/ppm2png.py "$OUT"/*/
echo "screenshots: $(ls "$OUT"/*/*.png | wc -l) files in $OUT"
