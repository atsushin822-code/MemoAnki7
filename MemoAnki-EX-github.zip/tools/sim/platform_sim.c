/*
 * Host simulator of the platform layer (platform.h).
 * The real src/ui.c and the learning logic run unchanged; this file replaces only
 * the XD-A8500 screen/keys/files with a 528x320 framebuffer, a key script and stdio.
 *
 * Script tokens (whitespace separated, '#' starts a comment line):
 *   UP DOWN LEFT RIGHT ENTER BACK POWER PGUP PGDN F1..F8 BKSP SHIFT SYMBOL   a key press
 *   TEXT:hello_world      letter keys; '_' = SYMBOL (space)
 *   SNAP:name             save out/name.ppm of the current screen
 *   EXPECT:some_text      fail (exit 1) unless the current screen contains the text ('_' = space)
 *   NOTEXPECT:some_text   fail unless the current screen does NOT contain the text
 *   DAY:20001             set the simulated "today" (day number)
 */
#include "../../src/platform.h"
#include "../../src/textutil.h"
#include "../../src/jfont.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <dirent.h>

static unsigned char fb[SCREEN_H][SCREEN_W][3];
static char screen_cell[ROWS][COLS][4];     /* UTF-8 of the character in each cell ('' = blank) */
static unsigned char pal[C_COUNT][3] = {
    {0,0,0}, {255,255,255}, {150,150,150}, {0,70,160}, {255,255,255}, {255,255,255},
    {0,0,0}, {255,220,0}, {0,255,0}, {255,90,90}, {50,50,70}
};
void platform_set_color(int idx, int rgb) {
    if (idx < 0 || idx >= C_COUNT) return;
    pal[idx][0] = (unsigned char)(rgb >> 16); pal[idx][1] = (unsigned char)(rgb >> 8); pal[idx][2] = (unsigned char)rgb;
}
static unsigned char font[95 * 12];
static int have_font = 0;

#define MAX_TOK 4096
static char *tok[MAX_TOK];
static int ntok = 0, tpos = 0;
static char pending_letters[256];
static int pending_pos = 0, pending_len = 0;
static const char *outdir = "out";
static unsigned int sim_today = 20000;
static int extra_calls = 0;
static int failures = 0;
static int screens_presented = 0;

static void die(const char *msg, const char *arg) {
    fprintf(stderr, "SIM ERROR: %s %s\n", msg, arg ? arg : "");
    exit(1);
}

void sim_load_script(const char *path, const char *out) {
    FILE *f = fopen(path, "r");
    char line[1024];
    outdir = out;
    if (!f) die("cannot open script", path);
    while (fgets(line, sizeof line, f)) {
        char *p = line, *t;
        if (line[0] == '#') continue;
        for (t = strtok(p, " \t\r\n"); t; t = strtok(0, " \t\r\n")) {
            if (ntok >= MAX_TOK) die("script too long", 0);
            tok[ntok++] = strdup(t);
        }
    }
    fclose(f);
    {
        const char *fp = getenv("SIM_FONT");
        FILE *ff = fopen(fp ? fp : "tools/sim/font8x12.bin", "rb");
        if (ff) { have_font = fread(font, 1, sizeof font, ff) == sizeof font; fclose(ff); }
        if (!have_font) fprintf(stderr, "note: no font file, glyphs drawn as boxes (set SIM_FONT)\n");
    }
}

int sim_failures(void) { return failures; }
int sim_screens(void) { return screens_presented; }

/* ---- drawing ---- */
void platform_init(void) {}
void *platform_alloc(unsigned int bytes) { return getenv("SIM_NOMEM") ? 0 : malloc(bytes); }   /* SIM_NOMEM=1 tests the static fallback */

void platform_rect(int x, int y, int w, int h, int color) {
    int i, j;
    for (j = y < 0 ? 0 : y; j < y + h && j < SCREEN_H; ++j)
        for (i = x < 0 ? 0 : x; i < x + w && i < SCREEN_W; ++i) {
            fb[j][i][0] = pal[color][0]; fb[j][i][1] = pal[color][1]; fb[j][i][2] = pal[color][2];
        }
}

void platform_clear(void) {
    platform_rect(0, 0, SCREEN_W, SCREEN_H, C_BG);
    memset(screen_cell, 0, sizeof screen_cell);
}

void platform_cell_rect(int col, int row, int ncols, int nrows, int color) {
    platform_rect(col * FONT_W, row * FONT_H + Y_OFF, ncols * FONT_W, nrows * FONT_H, color);
}

static void put_px(int x, int y, int color) {
    if (x < 0 || y < 0 || x >= SCREEN_W || y >= SCREEN_H) return;
    fb[y][x][0] = pal[color][0]; fb[y][x][1] = pal[color][1]; fb[y][x][2] = pal[color][2];
}

static void blit_rows(int x, int y, const unsigned char *rows, int nrows, int scale, int color) {
    int r, c, a, b;
    for (r = 0; r < nrows; ++r)
        for (c = 0; c < 8; ++c)
            if ((rows[r] >> (7 - c)) & 1)
                for (a = 0; a < scale; ++a) for (b = 0; b < scale; ++b) put_px(x + c * scale + a, y + r * scale + b, color);
}

static const unsigned char *ascii_rows(unsigned int cp, unsigned char *box) {
    int r;
    if (cp < 32 || cp > 126) cp = 32;
    if (have_font) return font + (cp - 32) * 12;
    for (r = 0; r < 12; ++r) box[r] = (cp != 32 && r > 1 && r < 10) ? 0x7E : 0;
    return box;
}

static void text_impl(int col, int row, const char *s, int color, int scale) {
    int x = col * FONT_W, y = row * FONT_H + Y_OFF, cell = col;
    unsigned int cp;
    unsigned char box[12];
    if (col < 0 || row < 0 || row >= ROWS || !s) return;
    for (;;) {
        const char *start = s;
        cp = text_next(&s);
        if (!cp || cell >= COLS) break;
        if (cp < 0x80) {
            blit_rows(x, y, ascii_rows(cp, box), 12, scale, color);
        } else {
            const unsigned char *g = jfont_glyph(cp);
            if (g) blit_rows(x, y + 2 * scale, g, 8, scale, color);
            else blit_rows(x, y, ascii_rows('?', box), 12, scale, color);
        }
        if (cell < COLS) {                                   /* record the text for EXPECT */
            int k, n = (int)(s - start);
            for (k = 0; k < n && k < 3; ++k) screen_cell[row][cell][k] = start[k];
            screen_cell[row][cell][k] = 0;
            if (scale == 2 && cell + 1 < COLS) screen_cell[row][cell + 1][0] = 1;   /* 2nd half of a big character */
        }
        x += FONT_W * scale; cell += scale;
    }
}

void platform_text(int col, int row, const char *s, int color)     { text_impl(col, row, s, color, 1); }
void platform_text_big(int col, int row, const char *s, int color) { text_impl(col, row, s, color, 2); }

void platform_present(void) { ++screens_presented; }

/* ---- time & files ---- */
unsigned int platform_today(void) { return sim_today; }

#define MAXF 3
static FILE *files[MAXF];
int platform_file_open(const char *name, int for_write) {
    char path[512];
    const char *d = getenv("MEMANKI_DATA");
    int slot;
    for (slot = 0; slot < MAXF && files[slot]; ++slot) {}
    if (slot == MAXF) return -1;
    snprintf(path, sizeof path, "%s/%s", d ? d : ".", name);
    files[slot] = fopen(path, for_write ? "wb" : "rb");
    return files[slot] ? slot : -1;
}
void platform_file_seek(int h, unsigned long pos) { if (h >= 0 && h < MAXF && files[h]) fseek(files[h], (long)pos, SEEK_SET); }
int platform_file_read(int h, void *buf, int n) { return (h >= 0 && h < MAXF && files[h]) ? (int)fread(buf, 1, (size_t)n, files[h]) : -1; }
int platform_file_write(int h, const void *buf, int n) { return (h >= 0 && h < MAXF && files[h]) ? (int)fwrite(buf, 1, (size_t)n, files[h]) : -1; }
int platform_list_files(const char *pattern, void (*cb)(const char *, void *), void *ctx) {
    const char *d = getenv("MEMANKI_DATA");
    const char *ext = strrchr(pattern, '.');
    struct dirent *e;
    DIR *dir;
    int found = 0;
    if (getenv("SIM_NOLIST") || !ext) return 0;                  /* SIM_NOLIST=1: a device that cannot list files */
    dir = opendir(d ? d : ".");
    if (!dir) return 0;
    while ((e = readdir(dir)) != NULL) {
        size_t n = strlen(e->d_name), m = strlen(ext);
        int all = !strcmp(pattern, "*.*");                       /* "*.*": every file */
        int cs = getenv("SIM_CASESENS") != NULL;                 /* SIM_CASESENS=1: a device whose search is case-sensitive */
        if (e->d_name[0] == '.') continue;
        if (all || (n > m && !(cs ? strcmp(e->d_name + n - m, ext) : strcasecmp(e->d_name + n - m, ext)))) { cb(e->d_name, ctx); ++found; }
    }
    closedir(dir);
    return found;
}

void platform_file_close(int h) { if (h >= 0 && h < MAXF && files[h]) { fclose(files[h]); files[h] = 0; } }

/* ---- keys & script ---- */
static const struct { const char *name; int key; } keynames[] = {
    {"UP",K_UP},{"DOWN",K_DOWN},{"LEFT",K_LEFT},{"RIGHT",K_RIGHT},{"ENTER",K_ENTER},{"BACK",K_BACK},
    {"POWER",K_POWER},{"PGUP",K_PGUP},{"PGDN",K_PGDN},{"F1",K_F1},{"F2",K_F2},{"F3",K_F3},{"F4",K_F4},
    {"F5",K_F5},{"F6",K_F6},{"F7",K_F7},{"F8",K_F8},{"BKSP",K_BKSP},{"SHIFT",K_SHIFT},{"SYMBOL",K_SYMBOL}
};

const char *platform_key_name(int key) {
    static char one[2];
    unsigned i;
    for (i = 0; i < sizeof keynames / sizeof keynames[0]; ++i) if (keynames[i].key == key) return keynames[i].name;
    if (key >= 'a' && key <= 'z') { one[0] = (char)(key - 32); one[1] = 0; return one; }
    return "?";
}

static void write_ppm(const char *name) {
    char path[512];
    FILE *f;
    snprintf(path, sizeof path, "%s/%s.ppm", outdir, name);
    f = fopen(path, "wb");
    if (!f) die("cannot write", path);
    fprintf(f, "P6\n%d %d\n255\n", SCREEN_W, SCREEN_H);
    fwrite(fb, 1, sizeof fb, f);
    fclose(f);
}

static void row_text(int r, char *out) {
    int c;
    char *o = out;
    for (c = 0; c < COLS; ++c) {
        const char *cell = screen_cell[r][c];
        if (cell[0] == 1) continue;                  /* covered by the previous big character */
        if (!cell[0]) { *o++ = ' '; continue; }
        while (*cell) *o++ = *cell++;
    }
    *o = 0;
}

static int screen_has(const char *needle) {
    int r;
    char buf[COLS * 4 + 1];
    for (r = 0; r < ROWS; ++r) { row_text(r, buf); if (strstr(buf, needle)) return 1; }
    return 0;
}

static void decode(char *dst, const char *src) {
    for (; *src; ++src) *dst++ = (*src == '_') ? ' ' : *src;
    *dst = 0;
}

int platform_wait_key(void) {
    for (;;) {
        char *t;
        unsigned i;
        if (pending_pos < pending_len) {
            char ch = pending_letters[pending_pos++];
            return ch == ' ' ? K_SYMBOL : ch;
        }
        if (tpos >= ntok) {
            if (++extra_calls > 200) die("script ended but the app did not exit (hang?)", 0);
            return K_POWER;
        }
        t = tok[tpos++];
        if (!strncmp(t, "SNAP:", 5)) { write_ppm(t + 5); continue; }
        if (!strncmp(t, "DAY:", 4)) { sim_today = (unsigned int)atoi(t + 4); continue; }
        if (!strncmp(t, "TEXT:", 5)) {
            pending_len = 0; pending_pos = 0;
            for (t += 5; *t && pending_len < 255; ++t) pending_letters[pending_len++] = (*t == '_') ? ' ' : *t;
            continue;
        }
        if (!strncmp(t, "EXPECT:", 7) || !strncmp(t, "NOTEXPECT:", 10)) {
            int neg = t[0] == 'N';
            char want[256];
            decode(want, t + (neg ? 10 : 7));
            if (screen_has(want) == neg) {
                int r;
                fprintf(stderr, "FAIL (token %d): screen %s \"%s\". Screen text:\n", tpos, neg ? "contains" : "lacks", want);
                for (r = 0; r < ROWS; ++r) { char buf[COLS * 4 + 1]; row_text(r, buf); fprintf(stderr, "  |%s\n", buf); }
                ++failures;
            } else {
                printf("  ok: %s%s\n", neg ? "not " : "", want);
            }
            continue;
        }
        for (i = 0; i < sizeof keynames / sizeof keynames[0]; ++i)
            if (!strcmp(t, keynames[i].name)) return keynames[i].key;
        die("unknown script token", t);
    }
}
