/* Host test runner: sim <script> <outdir>. Exit code 0 = script ran and every EXPECT held. */
#include "../../src/app.h"
#include <stdio.h>

void sim_load_script(const char *path, const char *out);
int sim_failures(void);
int sim_screens(void);

int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "usage: %s script.txt outdir\n", argv[0]); return 2; }
    sim_load_script(argv[1], argv[2]);
    app_init();
    app_run();
    app_shutdown();
    printf("%s: %d screens drawn, %d failed expectations\n", argv[1], sim_screens(), sim_failures());
    return sim_failures() ? 1 : 0;
}
