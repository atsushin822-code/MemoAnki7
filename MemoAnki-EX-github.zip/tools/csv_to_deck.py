#!/usr/bin/env python3
"""Convert a UTF-8 CSV (Front,Back,Example) into a deck for the device.

  --dat IMPORT.DAT   binary file the device imports (Settings -> Import a deck from IMPORT.DAT)
  -o deck.json       optional JSON description (for other tools)

For Anki decks use anki_to_deck.py. Fields longer than 127 bytes are cut. Max 600 cards per file.
"""
import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import devfmt


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("csv_file")
    p.add_argument("-o", "--output", help="JSON output (optional)")
    p.add_argument("--dat", help="write the device import file (IMPORT.DAT)")
    p.add_argument("--deck", required=True, help="deck name shown on the device")
    args = p.parse_args(argv)
    if not args.output and not args.dat:
        p.error("give --dat and/or -o")

    rows = []
    with open(args.csv_file, encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            rows.append({"front": row.get("Front", ""), "back": row.get("Back", ""), "example": row.get("Example", "")})

    if args.output:
        Path(args.output).write_text(json.dumps({"name": args.deck, "cards": rows}, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"Wrote {len(rows)} cards to {args.output}")
    if args.dat:
        if len(rows) > devfmt.MAX_IMPORT_CARDS:
            p.error(f"{len(rows)} cards: at most {devfmt.MAX_IMPORT_CARDS} per import file")
        n = devfmt.write_import_dat(args.deck, [(r["front"], r["back"], r["example"]) for r in rows], args.dat)
        print(f"Wrote {n} cards to {args.dat}")
        devfmt.report_undisplayable([c for r in rows for c in r.values()])


if __name__ == "__main__":
    main()
