/*
 * Persistence: one binary file (MEMANKI.DAT) holding decks, cards and stats.
 * Location is chosen by platform_file_open() (…\_USER\MEMANKI.DAT, else the app folder).
 * The file is validated on load; anything unexpected is ignored (sample deck is created).
 */
#include "storage.h"
#include "platform.h"
#include "deck.h"
#include "card.h"
#include "stats.h"
#include "textutil.h"
#include <string.h>

#define SAVE_NAME   "MEMANKI.DAT"
#define SAVE_MAGIC  "MAK1"
#define SAVE_VER    2u
#define AUTOSAVE_EVERY 5

typedef struct {
    char magic[4];
    unsigned int version, deck_size, card_size, stats_size;
    unsigned int decks, cards, next_deck_id, next_card_id;
} SaveHeader;

static StorageStatus status = STORAGE_UNTOUCHED;
static unsigned int dirty = 0;

static char iobuf[1024];
static unsigned int iolen;
static int ioh;
static int io_error;

static void out_flush(void) {
    if (iolen && !io_error) {
        if (platform_file_write(ioh, iobuf, (int)iolen) != (int)iolen) io_error = 1;
    }
    iolen = 0;
}

static void out_put(const void *p, unsigned int n) {
    const char *s = (const char *)p;
    while (n && !io_error) {
        unsigned int room = sizeof iobuf - iolen;
        unsigned int k = n < room ? n : room;
        memcpy(iobuf + iolen, s, k);
        iolen += k; s += k; n -= k;
        if (iolen == sizeof iobuf) out_flush();
    }
}

static void seed_sample(void) {
    int d;
    unsigned int id;
    deck_init(); card_init(); stats_init();
    d = deck_create("Sample");
    if (d < 0) return;
    id = deck_id_at(d);
    card_add(id, "abandon",   "to leave something behind for good",   "He abandoned the old plan.");
    card_add(id, "achieve",   "to succeed in reaching a goal",        "She achieved her goal.");
    card_add(id, "ancient",   "very old; from a long time ago",       "We visited an ancient temple.");
    card_add(id, "attempt",   "to try to do something",               "He attempted to fix the bike.");
    card_add(id, "benefit",   "a good or helpful result",             "Exercise has many benefits.");
    card_add(id, "candidate", "a person who applies for a job",       "Each candidate had an interview.");
    card_add(id, "decline",   "to become smaller or lower",           "Sales declined last year.");
    card_add(id, "enormous",  "extremely large",                      "They live in an enormous house.");
    deck_recount();
}

int storage_save(void) {
    SaveHeader h;
    int i;
    deck_recount();
    memcpy(h.magic, SAVE_MAGIC, 4);
    h.version = SAVE_VER;
    h.deck_size = sizeof(Deck);
    h.card_size = sizeof(Card);
    h.stats_size = sizeof(Stats);
    h.decks = (unsigned int)deck_count();
    h.cards = (unsigned int)card_total();
    h.next_deck_id = deck_next_id();
    h.next_card_id = card_next_id();

    io_error = 0; iolen = 0;
    ioh = platform_file_open(SAVE_NAME, 1);
    if (ioh < 0) { status = STORAGE_SAVE_FAILED; return -1; }
    out_put(&h, sizeof h);
    out_put(stats_get(), sizeof(Stats));
    for (i = 0; i < deck_count(); ++i) out_put(deck_get(i), sizeof(Deck));
    for (i = 0; i < card_total(); ++i) out_put(card_at(i), sizeof(Card));
    out_flush();
    platform_file_close(ioh);

    if (io_error) { status = STORAGE_SAVE_FAILED; return -1; }
    dirty = 0;
    status = STORAGE_SAVED;
    return 0;
}

static int load_file(void) {
    SaveHeader h;
    Stats s;
    Deck d;
    static Card c;
    unsigned int i;
    int fh = platform_file_open(SAVE_NAME, 0);
    if (fh < 0) return -1;

    if (platform_file_read(fh, &h, sizeof h) != (int)sizeof h) goto bad;
    if (memcmp(h.magic, SAVE_MAGIC, 4) != 0 || h.version != SAVE_VER) goto bad;
    if (h.deck_size != sizeof(Deck) || h.card_size != sizeof(Card) || h.stats_size != sizeof(Stats)) goto bad;
    if (h.decks > MAX_DECKS || h.cards > (unsigned int)card_capacity()) goto bad;
    if (platform_file_read(fh, &s, sizeof s) != (int)sizeof s) goto bad;

    deck_init(); card_init();
    for (i = 0; i < h.decks; ++i) {
        if (platform_file_read(fh, &d, sizeof d) != (int)sizeof d) goto bad_reset;
        if (deck_load_add(&d) < 0) goto bad_reset;
    }
    for (i = 0; i < h.cards; ++i) {
        Card *dst;
        if (platform_file_read(fh, &c, sizeof c) != (int)sizeof c) goto bad_reset;
        c.front[TEXT_MAX - 1] = c.back[TEXT_MAX - 1] = c.example[TEXT_MAX - 1] = 0;
        dst = card_add(c.deck_id, c.front, c.back, c.example);
        if (!dst) goto bad_reset;
        memcpy(dst, &c, sizeof c);      /* restore id and progress */
        dst->front[TEXT_MAX - 1] = dst->back[TEXT_MAX - 1] = dst->example[TEXT_MAX - 1] = 0;
    }
    deck_set_next_id(h.next_deck_id);
    card_set_next_id(h.next_card_id);
    stats_set(&s);
    deck_recount();
    platform_file_close(fh);
    return 0;

bad_reset:
    deck_init(); card_init();
bad:
    platform_file_close(fh);
    return -1;
}

void storage_init(void) {
    deck_init(); card_init(); stats_init();
    if (load_file() == 0) {
        status = STORAGE_LOADED;
    } else {
        seed_sample();
        status = STORAGE_NEW;
        storage_save();                 /* also probes whether saving works on this device */
    }
}

/* ---- IMPORT.DAT: "MIM1", u8 name_len, name, u16 count, then per card 3 x (u16 len + bytes); big-endian ---- */
static int rd(int h, void *p, int n) { return platform_file_read(h, p, n) == n; }

int storage_import_dat(const char *file) {
    unsigned char hdr[5], b2[2];
    char name[DECK_NAME_MAX], f[TEXT_MAX], b[TEXT_MAX], x[TEXT_MAX];
    char *fld[3];
    unsigned int count, i, k, id, n = 0;
    int d = -1, h = platform_file_open(file, 0);
    if (h < 0) return -1;
    fld[0] = f; fld[1] = b; fld[2] = x;

    if (!rd(h, hdr, 5) || memcmp(hdr, "MIM1", 4) != 0 || hdr[4] >= DECK_NAME_MAX) goto bad;
    if (hdr[4] && !rd(h, name, hdr[4])) goto bad;
    name[hdr[4]] = 0;
    if (!hdr[4]) goto bad;
    if (!rd(h, b2, 2)) goto bad;
    count = ((unsigned int)b2[0] << 8) | b2[1];
    if (deck_count() >= MAX_DECKS || (int)count + card_total() > card_capacity()) goto bad;

    d = deck_create(name);
    if (d < 0) goto bad;
    id = deck_id_at(d);
    for (i = 0; i < count; ++i) {
        for (k = 0; k < 3; ++k) {
            unsigned int len, take;
            if (!rd(h, b2, 2)) goto bad_partial;
            len = ((unsigned int)b2[0] << 8) | b2[1];
            take = len < TEXT_MAX - 1 ? len : TEXT_MAX - 1;
            if (take && !rd(h, fld[k], (int)take)) goto bad_partial;
            fld[k][take] = 0;
            {
                unsigned int left = len - take;                      /* discard what does not fit */
                char skip[32];
                while (left) {
                    unsigned int c = left < sizeof skip ? left : (unsigned int)sizeof skip;
                    if (!rd(h, skip, (int)c)) goto bad_partial;
                    left -= c;
                }
            }
        }
        if (!card_add(id, f, b, x)) goto bad_partial;
        ++n;
    }
    platform_file_close(h);
    deck_recount();
    storage_note_change();
    storage_save();
    return (int)n;

bad_partial:
    deck_delete(d);                      /* drop the half-imported deck again */
bad:
    platform_file_close(h);
    return -2;
}

/* ---- CSV import: UTF-8 text, columns Front,Back,Example (Example optional) ---------------------------------
   Comma / tab / semicolon separated (taken from the first line), "quoted, fields" with "" escapes and line
   breaks inside quotes, optional header row (Front,Back,...), optional BOM, LF or CRLF. Streamed in small
   chunks, so file size does not matter. */
#define CSV_FIELD (TEXT_MAX + 4)   /* a little longer than a card field so that cutting never splits a character */

static int utf8_ok(const char *s) {
    while (*s) {
        const char *q = s;
        unsigned int cp = text_next(&q);
        if (cp == 0xFFFD && (q - s) == 1) return 0;
        s = q;
    }
    return 1;
}

static int ieq(const char *a, const char *lower) {
    while (*a && *lower) {
        char c = *a++;
        if (c >= 'A' && c <= 'Z') c = (char)(c + 32);
        if (c != *lower++) return 0;
    }
    return *a == 0 && *lower == 0;
}

/* ---- Which files can be imported? -------------------------------------------------------------------
   Any *.CSV, and *.DAT files whose name starts with IMPORT (so MEMANKI.DAT / WIKI.DAT never show up). */
static int ends_with_ci(const char *s, const char *suffix) {
    unsigned int n = 0, m = 0;
    while (s[n]) ++n;
    while (suffix[m]) ++m;
    if (n < m) return 0;
    return ieq(s + n - m, suffix) ? 1 : 0;
}

static int starts_with_ci(const char *s, const char *prefix) {
    while (*prefix) {
        char a = *s++, b = *prefix++;
        if (a >= 'A' && a <= 'Z') a = (char)(a + 32);
        if (b >= 'A' && b <= 'Z') b = (char)(b + 32);
        if (a != b) return 0;
    }
    return 1;
}

static int lower_c(char c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }

static int cmp_ci(const char *a, const char *b) {
    while (*a && lower_c(*a) == lower_c(*b)) { ++a; ++b; }
    return lower_c(*a) - lower_c(*b);
}

static void list_add(ImportList *l, const char *name) {
    int i, j;
    if (!l->name || l->n >= l->cap) return;
    if (strlen(name) >= IMPORT_NAME_MAX) return;                   /* too long to handle */
    if (!(ends_with_ci(name, ".csv") || (ends_with_ci(name, ".dat") && starts_with_ci(name, "import")))) return;
    for (i = 0; i < l->n; ++i) if (cmp_ci(l->name[i], name) == 0) return;   /* same file seen in both folders */
    for (i = 0; i < l->n && cmp_ci(l->name[i], name) < 0; ++i) {}           /* keep the list sorted */
    for (j = l->n; j > i; --j) memcpy(l->name[j], l->name[j - 1], IMPORT_NAME_MAX);
    text_copy(l->name[i], name, IMPORT_NAME_MAX);
    ++l->n;
}

static void list_cb(const char *name, void *ctx) { list_add((ImportList *)ctx, name); }

void storage_list_imports(ImportList *l) {
    /* The device's file search may be case-sensitive, so ask for upper- and lower-case extensions. */
    static const char *pat[] = { "*.CSV", "*.csv", "*.DAT", "*.dat", "*.*" };
    static const char *base[] = { "IMPORT", "import" };
    int i, k, c, e;
    l->n = 0;
    if (!l->name) return;
    for (i = 0; i < 5; ++i) platform_list_files(pat[i], list_cb, l);
    if (l->n) return;
    /* The device did not list anything (or cannot): try the usual names one by one. */
    for (c = 0; c < 2; ++c)
        for (k = 0; k <= 9; ++k)
            for (e = 0; e < 2; ++e) {
                char nm[16];
                int h;
                strcpy(nm, base[c]);
                if (k) { nm[6] = (char)('0' + k); nm[7] = 0; }
                strcat(nm, e ? (c ? ".csv" : ".CSV") : (c ? ".dat" : ".DAT"));
                h = platform_file_open(nm, 0);
                if (h >= 0) { platform_file_close(h); list_add(l, nm); }
            }
}

/* Streaming CSV reader state */
typedef struct {
    char field[3][CSV_FIELD];
    unsigned int len[3];
    int col;                 /* 0..2 = current field, 3 = ignoring extra columns */
    int in_q, quote_pending, started, first_row, bad_utf8, n;
    unsigned int deck_id;
} CsvState;

static void csv_put(CsvState *s, char c) {
    if (s->col < 3 && s->len[s->col] < CSV_FIELD - 1) s->field[s->col][s->len[s->col]++] = c;
}

/* A row is complete. Returns 0 on success, -1 if the card table is full. */
static int csv_row(CsvState *s) {
    int k, rc = 0;
    if (s->started) {
        for (k = 0; k < 3; ++k) s->field[k][s->len[k]] = 0;
        if (!(utf8_ok(s->field[0]) && utf8_ok(s->field[1]) && utf8_ok(s->field[2]))) s->bad_utf8 = 1;
        if (s->first_row && ieq(s->field[0], "front") && ieq(s->field[1], "back")) {
            /* header row: skipped */
        } else if (s->field[0][0] && s->field[1][0]) {
            if (!card_add(s->deck_id, s->field[0], s->field[1], s->field[2])) rc = -1;
            else ++s->n;
        }
        s->first_row = 0;
    }
    s->col = 0; s->started = 0; s->len[0] = s->len[1] = s->len[2] = 0;
    return rc;
}

int storage_import_csv(const char *file, const char *deck_name) {
    static CsvState st;
    char buf[256], sep;
    int h, d, got, i, eof = 0, rc = -2;

    h = platform_file_open(file, 0);
    if (h < 0) return -1;
    d = (deck_count() < MAX_DECKS) ? deck_create(deck_name) : -1;
    if (d < 0) { platform_file_close(h); return -2; }

    memset(&st, 0, sizeof st);
    st.first_row = 1;
    st.deck_id = deck_id_at(d);

    got = platform_file_read(h, buf, (int)sizeof buf);
    if (got <= 0) goto fail;
    i = 0;
    if (got >= 3 && (unsigned char)buf[0] == 0xEF && (unsigned char)buf[1] == 0xBB && (unsigned char)buf[2] == 0xBF) i = 3;   /* BOM */
    {   /* separator from the first line */
        int k, tab = 0, comma = 0, semi = 0;
        for (k = i; k < got && buf[k] != '\n' && buf[k] != '\r'; ++k) {
            if (buf[k] == '\t') tab = 1; else if (buf[k] == ',') comma = 1; else if (buf[k] == ';') semi = 1;
        }
        sep = tab ? '\t' : (comma ? ',' : (semi ? ';' : ','));
    }

    for (;;) {
        for (; i < got; ++i) {
            char c = buf[i];
            if (st.quote_pending) {                           /* a quote inside quotes: "" = literal quote */
                st.quote_pending = 0;
                if (c == '"') { csv_put(&st, '"'); continue; }
                st.in_q = 0;                                   /* it closed the quoted part: handle c normally */
            }
            if (st.in_q) {
                if (c == '"') st.quote_pending = 1;
                else if (c == '\n' || c == '\r') {             /* line break inside quotes -> " / " */
                    if (c == '\r' && i + 1 < got && buf[i + 1] == '\n') ++i;
                    csv_put(&st, ' '); csv_put(&st, '/'); csv_put(&st, ' ');
                } else csv_put(&st, c);
                continue;
            }
            if (c == '"' && st.col < 3 && st.len[st.col] == 0) { st.in_q = 1; st.started = 1; continue; }
            if (c == sep) { st.started = 1; if (st.col < 3) ++st.col; continue; }
            if (c == '\n' || c == '\r') { if (csv_row(&st) < 0) goto fail; continue; }
            st.started = 1;
            csv_put(&st, c);
        }
        if (eof) break;
        got = platform_file_read(h, buf, (int)sizeof buf);
        if (got <= 0) { eof = 1; got = 0; st.in_q = 0; st.quote_pending = 0; if (csv_row(&st) < 0) goto fail; break; }
        i = 0;
    }
    platform_file_close(h);
    if (st.bad_utf8) { deck_delete(d); return -3; }
    if (st.n == 0) { deck_delete(d); return -2; }
    deck_recount();
    storage_note_change();
    storage_save();
    return st.n;

fail:
    deck_delete(d);
    platform_file_close(h);
    return rc;
}

void storage_note_change(void) { ++dirty; }

void storage_autosave(void) {
    if (dirty >= AUTOSAVE_EVERY) storage_save();
}

void storage_flush(void) {
    if (dirty) storage_save();
}

void storage_reset(void) {
    seed_sample();
    dirty = 1;
    storage_save();
}

StorageStatus storage_status(void) { return status; }

const char *storage_status_text(void) {
    switch (status) {
        case STORAGE_LOADED:      return "loaded from file";
        case STORAGE_NEW:         return "new (sample deck created)";
        case STORAGE_SAVED:       return "saved OK";
        case STORAGE_SAVE_FAILED: return "SAVE FAILED (RAM only)";
        default:                  return "-";
    }
}
