/*
 * UI: every screen of MemoAnki EX. All drawing/keys go through platform.h.
 * The font is the built-in 8x12 ASCII font, so the screen is 66 x 26 characters.
 */
#include "ui.h"
#include "platform.h"
#include "textutil.h"
#include "editor.h"
#include "deck.h"
#include "card.h"
#include "study.h"
#include "dictionary.h"
#include "wikipedia.h"
#include "stats.h"
#include "storage.h"
#include <stdio.h>
#include <string.h>
#include <strings.h>

#define LIST_ROW0   3
#define LIST_ROWS   19          /* rows 3..21 */
#define MSG_ROW     23
#define FOOTER_ROW  25

static int quit_flag = 0;
static char line[256];

/* Truncate (or pad with spaces) to exactly `cells` characters. dst needs 3*cells+1 bytes. */
static void fit(char *dst, const char *src, unsigned int cells) {
    unsigned int n, len;
    text_copy_cells(dst, src, cells, cells * 3 + 1);
    n = text_cells(dst);
    len = (unsigned int)strlen(dst);
    while (n < cells) { dst[len++] = ' '; ++n; }
    dst[len] = 0;
}

/* ------------------------------------------------------------------ */
/* Basics                                                             */
/* ------------------------------------------------------------------ */
static int get_key(void) {
    int k;
    if (quit_flag) return K_BACK;            /* unwind every screen after POWER */
    k = platform_wait_key();
    if (k == K_POWER) { quit_flag = 1; return K_BACK; }
    return k;
}

static void frame(const char *title, const char *footer) {
    platform_clear();
    platform_rect(0, 0, SCREEN_W, FONT_H + Y_OFF, C_TITLE_BG);
    platform_text(1, 0, title, C_TITLE_FG);
    platform_rect(0, FOOTER_ROW * FONT_H + Y_OFF - 3, SCREEN_W, 1, C_DIM);
    platform_text(1, FOOTER_ROW, footer, C_DIM);
}

static void put(int col, int row, const char *s, int color) { platform_text(col, row, s, color); }

static void list_row(int row, const char *s, int selected) {
    if (selected) platform_cell_rect(1, row, COLS - 2, 1, C_SEL_BG);
    platform_text(2, row, s, selected ? C_SEL_FG : C_FG);
}

static void keep_visible(int sel, int *top, int visible) {
    if (sel < *top) *top = sel;
    if (sel >= *top + visible) *top = sel - visible + 1;
    if (*top < 0) *top = 0;
}

/* Up/Down/PageUp/PageDown handling. Returns the new selection. */
static int move_sel(int key, int sel, int count, int wrap) {
    if (count <= 0) return 0;
    if (key == K_UP)   { sel = sel > 0 ? sel - 1 : (wrap ? count - 1 : 0); }
    if (key == K_DOWN) { sel = sel < count - 1 ? sel + 1 : (wrap ? 0 : count - 1); }
    if (key == K_PGUP) { sel = sel > LIST_ROWS ? sel - LIST_ROWS : 0; }
    if (key == K_PGDN) { sel = sel + LIST_ROWS < count ? sel + LIST_ROWS : count - 1; }
    return sel;
}

static void short_name(char *dst, const char *src, unsigned int cells) {
    text_copy_cells(dst, src, cells, cells * 3 + 1);          /* dst needs 3*cells+1 bytes */
}

static void message(const char *title, const char *l1, const char *l2) {
    frame(title, "Press any key");
    put(2, 5, l1, C_FG);
    if (l2) put(2, 7, l2, C_DIM);
    platform_present();
    (void)get_key();
}

static int confirm(const char *title, const char *l1, const char *l2) {
    int k;
    frame(title, "ENTER: Yes      BACK: No");
    put(2, 5, l1, C_ACCENT);
    if (l2) put(2, 7, l2, C_DIM);
    platform_present();
    for (;;) {
        k = get_key();
        if (k == K_ENTER) return 1;
        if (k == K_BACK) return 0;
    }
}

static WrapLine wrap_lines[4];

/* Draw wrapped text; returns the next free row. */
static int put_wrapped(int col, int row, const char *s, int max_lines, int color) {
    int n, i;
    if (max_lines > 4) max_lines = 4;
    n = text_wrap(s, wrap_lines, max_lines, WRAP_W);
    for (i = 0; i < n; ++i) put(col, row + i, wrap_lines[i], color);
    return row + (n ? n : 1);
}

/* Same at double size (31 characters per line, 2 rows each). */
static int put_big(int col, int row, const char *s, int max_lines, int color) {
    int n, i;
    if (max_lines > 4) max_lines = 4;
    n = text_wrap(s, wrap_lines, max_lines, 31);
    for (i = 0; i < n; ++i) platform_text_big(col, row + 2 * i, wrap_lines[i], color);
    return row + 2 * (n ? n : 1);
}

/* ------------------------------------------------------------------ */
/* Text input (Latin + romaji -> kana)                                */
/* ------------------------------------------------------------------ */
/* Draw "<text><pending>_" on a row, showing the tail when it is too long. */
static void draw_edit_line(const Editor *ed, int row, int maxcells) {
    unsigned int cells = text_cells(ed->buf), skip = cells > (unsigned int)maxcells ? cells - (unsigned int)maxcells : 0;
    const char *p = ed->buf;
    int col;
    while (skip--) (void)text_next(&p);
    put(2, row, p, C_FG);
    col = 2 + (int)text_cells(p);
    put(col, row, ed->pend, C_ACCENT);
    put(col + (int)strlen(ed->pend), row, "_", C_ACCENT);
}

/* Returns 1 = OK, 0 = cancelled. */
static int text_input(const char *title, const char *prompt, char *buf, unsigned int maxlen, int allow_empty) {
    Editor ed;
    int k;
    editor_init(&ed, buf, maxlen);
    for (;;) {
        unsigned int len = (unsigned int)strlen(buf);
        frame(title, "ENTER:OK BACK:Cancel F1:Mode SHIFT:Caps BKSP:Del SYMBOL:Space");
        put(2, 3, prompt, C_DIM);
        platform_cell_rect(1, 5, COLS - 2, 1, C_BAR);
        draw_edit_line(&ed, 5, 58);
        sprintf(line, "Input mode: %s     (%u / %u bytes)", editor_mode_name(&ed), len, maxlen - 1);
        put(2, 8, line, C_DIM);
        put(2, 10, "F1 cycles the mode: abc / ABC / hira / kata.", C_DIM);
        put(2, 11, "In hira/kata type romaji: nihongo -> にほんご", C_DIM);
        put(2, 12, "F2 = ー / -     F3 = 、 / ,     F4 = 。 / .     SYMBOL = space", C_DIM);
        platform_present();

        k = get_key();
        if (k == K_BACK) return 0;
        if (k == K_ENTER) {
            editor_commit(&ed);
            if (buf[0] || allow_empty) return 1;
            continue;
        }
        editor_key(&ed, k);
    }
}

/* ------------------------------------------------------------------ */
/* Study / review session                                             */
/* ------------------------------------------------------------------ */
static const char *rating_label[5] = { "0:Blank", "1:Hard", "2:Okay", "3:Good", "4:Easy" };

static void run_session(int deck_index, StudyMode mode) {
    const Deck *deck = deck_get(deck_index);
    char name[3 * 30 + 1];
    int n;
    if (!deck) return;
    short_name(name, deck->name, 30);

    n = study_begin(deck->id, mode);
    if (n == 0) {
        message(mode == STUDY_NEW ? "Study" : "Review",
                mode == STUDY_NEW ? "No new cards in this deck." : "Nothing is due for review.",
                mode == STUDY_NEW ? "Add cards in Decks, or use Review." : "Come back later, or use Study for new cards.");
        return;
    }

    for (;;) {
        Card *c = study_current();
        int phase = 0, sel = 2, k, row, i;
        if (!c) break;

        for (;;) {
            sprintf(line, "%s: %s", mode == STUDY_NEW ? "Study" : "Review", name);
            frame(line, phase == 0 ? "ENTER:Show answer       BACK:End session"
                                   : "LEFT/RIGHT+ENTER or F1-F5: rate       BACK:End session");
            sprintf(line, "Done %u / %u        Left in queue: %u",
                    study_done(), study_total(), (unsigned int)(study_total() - study_done()));
            put(2, 2, line, C_DIM);

            put(2, 4, "FRONT", C_DIM);
            row = put_big(2, 5, c->front, 2, C_FG);

            if (phase == 1) {
                platform_rect(16, 9 * FONT_H + Y_OFF - 3, SCREEN_W - 32, 1, C_BAR);
                put(2, 10, "BACK", C_DIM);
                row = put_big(2, 11, c->back, 2, C_ACCENT);
                if (c->example[0]) {
                    put(2, 16, "EXAMPLE", C_DIM);
                    row = put_wrapped(2, 17, c->example, 2, C_FG);
                }
                (void)row;
                for (i = 0; i < 5; ++i) {
                    int col = 2 + i * 12;
                    platform_cell_rect(col, 20, 11, 2, i == sel ? C_SEL_BG : C_BAR);
                    put(col + 1, 20, rating_label[i], i == sel ? C_SEL_FG : C_FG);
                    if (i <= 1) sprintf(line, "again");
                    else sprintf(line, "next %ud", study_next_interval(c->interval, i));
                    put(col + 1, 21, line, i == sel ? C_SEL_FG : C_DIM);
                }
            }
            platform_present();

            k = get_key();
            if (k == K_BACK) goto end_session;
            if (phase == 0) { if (k == K_ENTER) phase = 1; continue; }
            if (k == K_LEFT)  { sel = sel > 0 ? sel - 1 : 4; continue; }
            if (k == K_RIGHT) { sel = sel < 4 ? sel + 1 : 0; continue; }
            if (k >= K_F1 && k <= K_F5) { sel = k - K_F1; k = K_ENTER; }
            if (k == K_ENTER) break;
        }
        study_answer(sel);
        storage_autosave();
    }

end_session:
    storage_flush();
    {
        unsigned int a = study_answers(), ok = study_correct();
        frame("Session summary", "Press any key");
        sprintf(line, "Deck: %s", name);
        put(2, 4, line, C_FG);
        sprintf(line, "Ratings given : %u", a);
        put(2, 6, line, C_FG);
        sprintf(line, "Remembered (2+): %u", ok);
        put(2, 7, line, C_GOOD);
        if (a) { sprintf(line, "Accuracy      : %u%c", (ok * 100u) / a, '%'); put(2, 8, line, C_FG); }
        if (study_current()) put(2, 10, "Some cards are still in the queue; they stay due.", C_DIM);
        else put(2, 10, "All cards in this session are finished.", C_GOOD);
        platform_present();
        (void)get_key();
    }
}

/* ------------------------------------------------------------------ */
/* Deck picker (for Study / Review)                                   */
/* ------------------------------------------------------------------ */
static void pick_deck_and_run(StudyMode mode) {
    int sel = 0, top = 0, k, i;
    for (;;) {
        int n = deck_count();
        unsigned int today = platform_today();
        frame(mode == STUDY_NEW ? "Study: choose a deck" : "Review: choose a deck",
              "UP/DOWN:Select   ENTER:Start   BACK:Home");
        if (n == 0) {
            put(2, 5, "No decks yet. Create one in Decks.", C_DIM);
        } else {
            if (sel >= n) sel = n - 1;
            keep_visible(sel, &top, LIST_ROWS);
            for (i = 0; i < LIST_ROWS && top + i < n; ++i) {
                const Deck *d = deck_get(top + i);
                char nm[3 * 30 + 1];
                fit(nm, d->name, 30);
                sprintf(line, "%s  new %3u   due %3u", nm,
                        card_new_in_deck(d->id), card_due_in_deck(d->id, today));
                list_row(LIST_ROW0 + i, line, top + i == sel);
            }
        }
        platform_present();
        k = get_key();
        if (k == K_BACK) return;
        if (k == K_ENTER && n > 0) { run_session(sel, mode); continue; }
        sel = move_sel(k, sel, n, 0);
    }
}

/* ------------------------------------------------------------------ */
/* Decks                                                              */
/* ------------------------------------------------------------------ */
static void add_cards(int deck_index) {
    char f[TEXT_MAX], b[TEXT_MAX], e[TEXT_MAX];
    const Deck *d = deck_get(deck_index);
    unsigned int id;
    if (!d) return;
    id = d->id;
    for (;;) {
        f[0] = b[0] = e[0] = 0;
        if (!text_input("Add card (1/3)", "Front (the word / question):", f, sizeof f, 0)) return;
        if (!text_input("Add card (2/3)", "Back (the meaning / answer):", b, sizeof b, 0)) return;
        if (!text_input("Add card (3/3)", "Example sentence (optional, ENTER to skip):", e, sizeof e, 1)) return;
        if (!card_add(id, f, b, e)) {
            message("Add card", "The card pool is full.", "Delete a deck or reset data to free space.");
            return;
        }
        storage_note_change();
        deck_recount();
        storage_save();
        frame("Add card", "ENTER:Add another      BACK:Done");
        put(2, 5, "Card added:", C_GOOD);
        put(2, 7, f, C_FG);
        put(2, 9, b, C_ACCENT);
        platform_present();
        if (get_key() != K_ENTER) return;
    }
}

static void deck_actions(int deck_index) {
    static const char *items[] = {
        "Study new cards", "Review due cards", "Add cards", "Rename deck", "Copy deck", "Delete deck", "Back"
    };
    int sel = 0, k, i;
    for (;;) {
        const Deck *d = deck_get(deck_index);
        char nm[3 * 36 + 1], nb[DECK_NAME_MAX];
        if (!d) return;
        short_name(nm, d->name, 36);
        sprintf(line, "Deck: %s", nm);
        frame(line, "UP/DOWN:Select   ENTER:Run   BACK:Back");
        sprintf(line, "%u cards", card_count_in_deck(d->id));
        put(2, 2, line, C_DIM);
        for (i = 0; i < 7; ++i) list_row(4 + i, items[i], i == sel);
        platform_present();

        k = get_key();
        if (k == K_BACK) return;
        if (k != K_ENTER) { sel = move_sel(k, sel, 7, 1); continue; }

        switch (sel) {
            case 0: run_session(deck_index, STUDY_NEW); break;
            case 1: run_session(deck_index, STUDY_REVIEW); break;
            case 2: add_cards(deck_index); break;
            case 3:
                text_copy(nb, d->name, sizeof nb);
                if (text_input("Rename deck", "New deck name:", nb, sizeof nb, 0)) {
                    deck_rename(deck_index, nb);
                    storage_note_change(); storage_save();
                }
                break;
            case 4:
                text_copy(nb, d->name, sizeof nb);
                if (strlen(nb) + 6 < sizeof nb) strcat(nb, " copy");
                if (text_input("Copy deck", "Name for the copy:", nb, sizeof nb, 0)) {
                    int n = deck_copy(deck_index, nb);
                    if (n < 0) message("Copy deck", "Could not copy (too many decks or cards?).", 0);
                    else { storage_note_change(); storage_save(); }
                }
                break;
            case 5:
                sprintf(line, "Delete \"%s\" and all of its cards?", nm);
                if (confirm("Delete deck", line, "This cannot be undone.")) {
                    deck_delete(deck_index);
                    storage_note_change(); storage_save();
                    return;
                }
                break;
            default: return;
        }
        if (quit_flag) return;
    }
}

void ui_show_decks(void) {
    int sel = 0, top = 0, k, i;
    for (;;) {
        int n = deck_count();
        int rows = n + 1;                       /* row 0 = "+ New deck" */
        frame("Decks", "UP/DOWN:Select   ENTER:Open   BACK:Home");
        if (sel >= rows) sel = rows - 1;
        keep_visible(sel, &top, LIST_ROWS);
        deck_recount();
        for (i = 0; i < LIST_ROWS && top + i < rows; ++i) {
            int idx = top + i;
            if (idx == 0) { list_row(LIST_ROW0 + i, "+ New deck...", sel == 0); continue; }
            {
                const Deck *d = deck_get(idx - 1);
                char nm[3 * 36 + 1];
                fit(nm, d->name, 36);
                sprintf(line, "%s %4u cards", nm, d->card_count);
                list_row(LIST_ROW0 + i, line, sel == idx);
            }
        }
        platform_present();

        k = get_key();
        if (k == K_BACK) return;
        if (k == K_ENTER) {
            if (sel == 0) {
                char nb[DECK_NAME_MAX];
                nb[0] = 0;
                if (text_input("New deck", "Deck name:", nb, sizeof nb, 0)) {
                    int d = deck_create(nb);
                    if (d < 0) message("New deck", "Could not create the deck (limit reached?).", 0);
                    else { storage_note_change(); storage_save(); sel = d + 1; }
                }
            } else {
                deck_actions(sel - 1);
            }
            if (quit_flag) return;
            continue;
        }
        sel = move_sel(k, sel, rows, 0);
    }
}

/* ------------------------------------------------------------------ */
/* Study / Review entry points                                        */
/* ------------------------------------------------------------------ */
void ui_show_study(void)  { pick_deck_and_run(STUDY_NEW); }
void ui_show_review(void) { pick_deck_and_run(STUDY_REVIEW); }

/* ------------------------------------------------------------------ */
/* Dictionary (search over all cards)                                 */
/* ------------------------------------------------------------------ */
static void dictionary_detail(const Card *c) {
    char dn[DECK_NAME_MAX];
    int i, n = deck_count();
    dn[0] = 0;
    for (i = 0; i < n; ++i) if (deck_get(i)->id == c->deck_id) text_copy(dn, deck_get(i)->name, sizeof dn);
    frame("Dictionary", "Press any key");
    sprintf(line, "Deck: %s", dn);
    put(2, 2, line, C_DIM);
    put(2, 4, "FRONT", C_DIM);
    put_wrapped(2, 5, c->front, 3, C_FG);
    put(2, 9, "BACK", C_DIM);
    put_wrapped(2, 10, c->back, 3, C_ACCENT);
    if (c->example[0]) { put(2, 14, "EXAMPLE", C_DIM); put_wrapped(2, 15, c->example, 3, C_FG); }
    platform_present();
    (void)get_key();
}

void ui_show_dictionary(void) {
    char q[40];
    Editor ed;
    int sel = 0, top = 0, n, k, i;
    q[0] = 0;
    editor_init(&ed, q, sizeof q);
    for (;;) {
        n = dictionary_search(q);
        if (sel >= n) sel = n ? n - 1 : 0;
        keep_visible(sel, &top, 17);
        frame("Dictionary", "Type:Search F1:Mode UP/DOWN:Select ENTER:Detail BACK:Home");
        platform_cell_rect(1, 2, COLS - 2, 1, C_BAR);
        put(2, 2, "Search: ", C_DIM);
        {   /* "<text><pending>_" after the label */
            unsigned int cells = text_cells(q);
            put(10, 2, q, C_FG);
            put(10 + (int)cells, 2, ed.pend, C_ACCENT);
            put(10 + (int)cells + (int)strlen(ed.pend), 2, "_", C_ACCENT);
            sprintf(line, "[%s]", editor_mode_name(&ed));
            put(COLS - 8, 2, line, C_DIM);
        }
        if (!q[0]) {
            put(2, 5, "Type letters to look up words in all of your decks.", C_DIM);
            put(2, 6, "Matches the front and back text of every card.", C_DIM);
        } else if (n == 0) {
            put(2, 5, "No matches.", C_DIM);
        } else {
            sprintf(line, "%d match%s", n, n == 1 ? "" : "es");
            put(2, 3, line, C_DIM);
            for (i = 0; i < 17 && top + i < n; ++i) {
                const Card *c = dictionary_result(top + i);
                char f[3 * 20 + 1], b[3 * 40 + 1];
                fit(f, c->front, 20);
                text_copy_cells(b, c->back, 40, sizeof b);
                sprintf(line, "%s %s", f, b);
                list_row(5 + i, line, top + i == sel);
            }
        }
        platform_present();

        k = get_key();
        if (k == K_BACK) return;
        if (k == K_ENTER && n > 0) { dictionary_detail(dictionary_result(sel)); continue; }
        if (k == K_UP || k == K_DOWN || k == K_PGUP || k == K_PGDN) { sel = move_sel(k, sel, n, 0); continue; }
        if (k == K_ENTER) { editor_commit(&ed); continue; }
        if (editor_key(&ed, k)) { sel = 0; top = 0; }
    }
}

/* ------------------------------------------------------------------ */
/* Wikipedia (offline reader)                                         */
/* ------------------------------------------------------------------ */
#define WK_W          62          /* article text width in cells */
#define WK_ROW0       2
#define WK_ROWS       21
#define WK_TEXT_POOL  (32 * 1024)
#define WK_LINES_POOL 3000
#define WK_WIN        17

static char *wk_text = 0;
static unsigned int *wk_line = 0;
static unsigned int wk_cap = 0, wk_line_cap = 0;
static char wk_text_fb[1200];
static unsigned int wk_line_fb[48];

static void wk_alloc(void) {
    if (wk_text) return;
    wk_text = (char *)platform_alloc(WK_TEXT_POOL + 1);
    wk_line = (unsigned int *)platform_alloc(WK_LINES_POOL * (unsigned int)sizeof(unsigned int));
    if (wk_text && wk_line) { wk_cap = WK_TEXT_POOL; wk_line_cap = WK_LINES_POOL; return; }
    wk_text = wk_text_fb; wk_cap = sizeof wk_text_fb - 1;          /* small static fallback */
    wk_line = wk_line_fb; wk_line_cap = sizeof wk_line_fb / sizeof wk_line_fb[0];
}

/* Back of a card made from an article: its first sentence. */
static void first_sentence(char *dst, unsigned int dstsize, const char *text) {
    char tmp[3 * 60 + 4];
    unsigned int i;
    text_copy_cells(tmp, text, 60, sizeof tmp);
    for (i = 0; tmp[i]; ++i) if (tmp[i] == '\n') { tmp[i] = 0; break; }
    for (i = 0; tmp[i]; ++i)
        if ((unsigned char)tmp[i] == 0xE3 && (unsigned char)tmp[i + 1] == 0x80 && (unsigned char)tmp[i + 2] == 0x82) { tmp[i + 3] = 0; break; }
    text_sanitize(dst, tmp, dstsize);
}

/* List the decks and let the user choose one. Returns its index or -1. */
static int choose_deck(const char *title) {
    int sel = 0, top = 0, k, i, n;
    for (;;) {
        n = deck_count();
        frame(title, "UP/DOWN:Select   ENTER:Choose   BACK:Cancel");
        if (n == 0) put(2, 5, "No decks yet. Create one in Decks first.", C_DIM);
        keep_visible(sel, &top, LIST_ROWS);
        deck_recount();
        for (i = 0; i < LIST_ROWS && top + i < n; ++i) {
            const Deck *d = deck_get(top + i);
            char nm[3 * 36 + 1];
            fit(nm, d->name, 36);
            sprintf(line, "%s %4u cards", nm, d->card_count);
            list_row(LIST_ROW0 + i, line, top + i == sel);
        }
        platform_present();
        k = get_key();
        if (k == K_BACK) return -1;
        if (k == K_ENTER && n > 0) return sel;
        sel = move_sel(k, sel, n, 0);
    }
}

static void wiki_make_card(const WikiEntry *e, const char *text) {
    char back[TEXT_MAX];
    int d = choose_deck("Make a card: choose a deck");
    const Deck *deck;
    if (d < 0) return;
    deck = deck_get(d);
    first_sentence(back, sizeof back, text);
    if (!card_add(deck->id, e->title, back, "")) {
        message("Make a card", "The card pool is full.", 0);
        return;
    }
    storage_note_change();
    deck_recount();
    storage_save();
    frame("Make a card", "Press any key");
    put(2, 4, "Card added to the deck:", C_GOOD);
    put(2, 6, deck->name, C_FG);
    put(2, 8, e->title, C_FG);
    put(2, 9, back, C_ACCENT);
    platform_present();
    (void)get_key();
}

static int wk_big = 0;                 /* 1 = double-size text (kept between articles) */

/* Compute where each display line starts for the given width. */
static unsigned int wk_layout(unsigned int len, unsigned int width) {
    unsigned int pos, nlines = 0, vis;
    for (pos = 0; pos < len && nlines < wk_line_cap; ) {
        unsigned int used = text_next_line(wk_text + pos, len - pos, width, &vis);
        wk_line[nlines++] = pos;
        if (!used) break;
        pos += used;
    }
    return nlines;
}

static void wiki_view(const WikiEntry *e) {
    long got;
    unsigned int len, nlines, top = 0, i, vis, width, per_page;
    int k, r;
    char tmp[3 * WK_W + 1];

    wk_alloc();
    got = wikipedia_read_text(e, wk_text, wk_cap);
    if (got < 0) { message("Wikipedia", "Could not read the article.", 0); return; }
    len = (unsigned int)got;
    wk_text[len] = 0;
    width = wk_big ? WK_W / 2 : WK_W;
    nlines = wk_layout(len, width);
    for (;;) {
        char title[3 * 50 + 1];
        per_page = wk_big ? WK_ROWS / 2 : WK_ROWS;
        short_name(title, e->title, 50);
        frame(title, "UP/DOWN:Scroll  PAGE:Page  ENTER:Make card  F1:Size  BACK:List");
        for (r = 0; r < (int)per_page && top + (unsigned int)r < nlines; ++r) {
            unsigned int st = wk_line[top + (unsigned int)r];
            (void)text_next_line(wk_text + st, len - st, width, &vis);
            if (vis > sizeof tmp - 1) vis = sizeof tmp - 1;
            for (i = 0; i < vis; ++i) tmp[i] = wk_text[st + i];
            tmp[vis] = 0;
            if (wk_big) platform_text_big(2, WK_ROW0 + 2 * r, tmp, C_FG);
            else put(2, WK_ROW0 + r, tmp, C_FG);
        }
        sprintf(line, "Lines %u-%u of %u%s", nlines ? top + 1 : 0,
                top + per_page < nlines ? top + per_page : nlines, nlines,
                (unsigned long)len < e->len ? "   (text cut: article is longer)" : "");
        put(2, MSG_ROW, line, C_DIM);
        platform_present();

        k = get_key();
        if (k == K_BACK) return;
        if (k == K_ENTER) { wiki_make_card(e, wk_text); continue; }
        if (k == K_F1 || k == K_ZOOM) {                    /* toggle text size, keep the reading position */
            unsigned int at = nlines ? wk_line[top] : 0, j;
            wk_big = !wk_big;
            width = wk_big ? WK_W / 2 : WK_W;
            nlines = wk_layout(len, width);
            for (top = 0, j = 0; j < nlines; ++j) { if (wk_line[j] > at) break; top = j; }
            continue;
        }
        if (k == K_UP && top > 0) --top;
        if (k == K_DOWN && top + 1 < nlines) ++top;
        if (k == K_PGUP || k == K_LEFT)  top = top > per_page ? top - per_page : 0;
        if ((k == K_PGDN || k == K_RIGHT) && top + per_page < nlines) top += per_page;
    }
}

void ui_show_wikipedia(void) {
    static char wt[WK_WIN][WIKI_TITLE_MAX];
    char q[40], qk[3 * 40 + 1];
    Editor ed;
    unsigned long first = 0, base = 0;
    int sel = 0, nvalid = 0, k, i, reload = 1;

    if (!wikipedia_available()) {
        message("Wikipedia (offline)", "WIKI.DAT is not installed.",
                "Put it in the app folder (see tools/wikipedia_prepare.py).");
        return;
    }
    q[0] = 0;
    editor_init(&ed, q, sizeof q);
    for (;;) {
        WikiEntry e;
        if (reload) {                                   /* query changed: restart from the first match */
            text_make_key(qk, q, sizeof qk);
            base = first = wikipedia_lower_bound(qk);
            sel = 0;
            reload = 0;
        }
        nvalid = 0;
        for (i = 0; i < WK_WIN; ++i) {                   /* load the visible window */
            if (wikipedia_entry(first + (unsigned long)i, &e) != 0 || !wikipedia_key_matches(&e, qk)) break;
            text_copy(wt[i], e.title, WIKI_TITLE_MAX);
            ++nvalid;
        }
        if (sel >= nvalid) sel = nvalid ? nvalid - 1 : 0;

        frame("Wikipedia (offline)", "Type:Search F1:Mode UP/DOWN:Select ENTER:Read BACK:Home");
        platform_cell_rect(1, 2, COLS - 2, 1, C_BAR);
        put(2, 2, "Search: ", C_DIM);
        {
            unsigned int cells = text_cells(q);
            put(10, 2, q, C_FG);
            put(10 + (int)cells, 2, ed.pend, C_ACCENT);
            put(10 + (int)cells + (int)strlen(ed.pend), 2, "_", C_ACCENT);
            sprintf(line, "[%s]", editor_mode_name(&ed));
            put(COLS - 8, 2, line, C_DIM);
        }
        if (!q[0]) { sprintf(line, "%u articles - type to search (romaji works for Japanese)", (unsigned int)wikipedia_count()); put(2, 3, line, C_DIM); }
        else if (!nvalid) put(2, 5, "No matching article.", C_DIM);
        for (i = 0; i < nvalid; ++i) list_row(5 + i, wt[i], i == sel);
        platform_present();

        k = get_key();
        if (k == K_BACK) break;
        if (k == K_ENTER) {
            editor_commit(&ed);
            if (nvalid && wikipedia_entry(first + (unsigned long)sel, &e) == 0) wiki_view(&e);
            continue;
        }
        if (k == K_UP)   { if (sel > 0) --sel; else if (first > base) --first; continue; }
        if (k == K_DOWN) {
            if (sel + 1 < nvalid) ++sel;
            else if (nvalid == WK_WIN && wikipedia_entry(first + WK_WIN, &e) == 0 && wikipedia_key_matches(&e, qk)) ++first;
            continue;
        }
        if (k == K_PGUP) { first = first > base + WK_WIN ? first - WK_WIN : base; sel = 0; continue; }
        if (k == K_PGDN) {
            if (nvalid == WK_WIN && wikipedia_entry(first + 2 * WK_WIN - 1, &e) == 0 && wikipedia_key_matches(&e, qk)) first += WK_WIN;
            continue;
        }
        if (editor_key(&ed, k)) reload = 1;
    }
    wikipedia_close();
}

/* ------------------------------------------------------------------ */
/* Statistics                                                         */
/* ------------------------------------------------------------------ */
void ui_show_stats(void) {
    static const char *lab[5] = { "0 Blank", "1 Hard", "2 Okay", "3 Good", "4 Easy" };
    const Stats *s = stats_get();
    unsigned int today = platform_today(), mx = 1, i;
    frame("Statistics", "Press any key");

    sprintf(line, "Decks: %d     Cards: %d", deck_count(), card_total());
    put(2, 2, line, C_FG);
    sprintf(line, "New cards: %u     Due today: %u", card_new_total(), card_due_total(today));
    put(2, 3, line, C_FG);
    sprintf(line, "Reviews today: %u", stats_today_reviews());
    put(2, 5, line, C_FG);
    sprintf(line, "Reviews total: %u", s->reviews);
    put(2, 6, line, C_FG);
    if (s->reviews) {
        sprintf(line, "Remembered (rating 2+): %u%c", (s->correct * 100u) / s->reviews, '%');
        put(2, 7, line, C_GOOD);
    } else {
        put(2, 7, "No reviews yet.", C_DIM);
    }

    put(2, 9, "Ratings given (all time)", C_DIM);
    for (i = 0; i < 5; ++i) if (s->by_rating[i] > mx) mx = s->by_rating[i];
    for (i = 0; i < 5; ++i) {
        unsigned int w = (s->by_rating[i] * 300u) / mx;
        put(2, 11 + (int)i * 2, lab[i], C_FG);
        if (w) platform_rect(10 * FONT_W, (11 + (int)i * 2) * FONT_H + Y_OFF + 2, (int)w, 8, i >= 2 ? C_GOOD : C_BAD);
        sprintf(line, "%u", s->by_rating[i]);
        put(10 + (int)(w / FONT_W) + 2, 11 + (int)i * 2, line, C_DIM);
    }
    platform_present();
    (void)get_key();
}

/* ------------------------------------------------------------------ */
/* Settings / diagnostics                                             */
/* ------------------------------------------------------------------ */
static void key_test(void) {
    int last = K_NONE, backs = 0, k;
    for (;;) {
        frame("Key test", "Press BACK 3 times in a row to leave");
        put(2, 3, "Press any key. The name the app received is shown below.", C_DIM);
        if (last != K_NONE) {
            sprintf(line, "Last key: %s", platform_key_name(last));
            put(2, 6, line, C_ACCENT);
        }
        put(2, 9, "Use this to check that every key reaches the app", C_DIM);
        put(2, 10, "(e.g. SYMBOL is used as the space key in text entry).", C_DIM);
        platform_present();
        k = platform_wait_key();                /* raw: POWER is shown, not treated as quit */
        last = k;
        backs = (k == K_BACK) ? backs + 1 : 0;
        if (backs >= 3) return;
    }
}

/* ------------------------------------------------------------------ */
/* Import: choose a file (any *.CSV, IMPORT*.DAT)                     */
/* ------------------------------------------------------------------ */
static ImportList imports;
static char imports_fallback[IMPORT_MIN_FILES][IMPORT_NAME_MAX];

static void imports_init(void) {
    if (imports.name) return;
    imports.name = (char (*)[IMPORT_NAME_MAX])platform_alloc(IMPORT_MAX_FILES * IMPORT_NAME_MAX);
    if (imports.name) imports.cap = IMPORT_MAX_FILES;
    else { imports.name = imports_fallback; imports.cap = IMPORT_MIN_FILES; }
}

static void import_screen(void) {
    int sel = 0, top = 0, k, i, n;
    imports_init();
    for (;;) {
        storage_list_imports(&imports);
        n = imports.n;
        frame("Import a deck", "UP/DOWN:Select   ENTER:Import   BACK:Back");
        if (n == 0) {
            put(2, 4, "No import files were found.", C_ACCENT);
            put(2, 6, "Put a CSV file (UTF-8, columns Front,Back,Example) or an", C_DIM);
            put(2, 7, "IMPORT*.DAT file (from the converter) next to the app.", C_DIM);
            put(2, 9, "Any name works for .CSV; upper/lower case both OK (import.csv).", C_DIM);
        } else {
            if (sel >= n) sel = n - 1;
            keep_visible(sel, &top, LIST_ROWS);
            for (i = 0; i < LIST_ROWS && top + i < n; ++i) {
                const char *nm = imports.name[top + i];
                int is_csv = 0;
                unsigned int len = (unsigned int)strlen(nm);
                if (len >= 4 && (nm[len - 1] == 'v' || nm[len - 1] == 'V')) is_csv = 1;
                sprintf(line, "%-30s %s", nm, is_csv ? "CSV (asks for a deck name)" : "MemoAnki import file");
                list_row(LIST_ROW0 + i, line, top + i == sel);
            }
        }
        platform_present();

        k = get_key();
        if (k == K_BACK) return;
        if (k == K_ENTER && n > 0) {
            char file[IMPORT_NAME_MAX];
            unsigned int len;
            int r;
            text_copy(file, imports.name[sel], sizeof file);
            len = (unsigned int)strlen(file);
            if (len >= 4 && (file[len - 1] == 'v' || file[len - 1] == 'V')) {           /* .CSV: ask for the deck name */
                char nb[DECK_NAME_MAX];
                unsigned int j;
                for (j = 0; j + 4 < len && j + 1 < sizeof nb; ++j) nb[j] = file[j];     /* file name without extension */
                nb[j] = 0;
                if (!text_input("Import CSV", "Name for the new deck:", nb, sizeof nb, 0)) continue;
                r = storage_import_csv(file, nb);
            } else {
                r = storage_import_dat(file);
            }
            if (r >= 0) { sprintf(line, "Imported %d cards as a new deck.", r); message("Import", line, 0); }
            else if (r == -1) message("Import", "The file was not found.", 0);
            else if (r == -3) message("Import", "This CSV is not UTF-8.", "Save it as \"CSV UTF-8\" (Excel) and try again.");
            else message("Import", "The file is empty, invalid or does not fit.", "Too many decks/cards, or not a MemoAnki import file.");
            continue;
        }
        sel = move_sel(k, sel, n, 0);
    }
}

/* Shows exactly what the device's file search returns, to find out why a file is not listed.
   Every entry is kept (up to FC_MAX in total) and the screen scrolls with UP/DOWN/PAGE. */
#define FC_MAX     128
#define FC_MIN     16
#define FC_FOLDERS 4

typedef struct { char name[IMPORT_NAME_MAX]; unsigned long type; } FcEntry;
typedef struct {
    FcEntry *e; int cap, stored;           /* entries kept so far (all folders, in folder order) */
    int first[FC_FOLDERS], kept[FC_FOLDERS], total[FC_FOLDERS], ret[FC_FOLDERS];
    int cur;                               /* folder being collected */
} FcCtx;

static FcEntry fc_fallback[FC_MIN];
static FcEntry *fc_pool;          /* allocated once: the memory pool has no free */

static void raw_cb(const char *name, unsigned long type, void *ctx) {
    FcCtx *c = (FcCtx *)ctx;
    if (c->stored < c->cap) {
        text_copy(c->e[c->stored].name, name, IMPORT_NAME_MAX);
        c->e[c->stored].type = type;
        ++c->stored; ++c->kept[c->cur];
    }
    ++c->total[c->cur];
}

/* Number of display rows: per folder 1 title + kept entries + 1 summary. */
static int fc_rows(const FcCtx *c) {
    int v, n = 0;
    for (v = 0; v < FC_FOLDERS; ++v) n += c->kept[v] + 2;
    return n;
}

static void fc_row_text(const FcCtx *c, int r, int *dim) {
    int v;
    *dim = 0;
    for (v = 0; v < FC_FOLDERS; ++v) {
        int len = c->kept[v] + 2;
        if (r < len) {
            if (r == 0) { sprintf(line, "%s", platform_dir(v)); *dim = 1; }
            else if (r <= c->kept[v]) {
                const FcEntry *e = &c->e[c->first[v] + r - 1];
                sprintf(line, "  %-31s type %lu", e->name, e->type);
            } else {
                *dim = 1;
                if (c->ret[v] != 0 && c->total[v] == 0) sprintf(line, "  nothing found (search code %d)", c->ret[v]);
                else if (c->total[v] > c->kept[v]) sprintf(line, "  %d entries (%d shown)", c->total[v], c->kept[v]);
                else sprintf(line, "  %d entries", c->total[v]);
            }
            return;
        }
        r -= len;
    }
    line[0] = 0;
}

static void file_check(void) {
    FcCtx c;
    int v, sel = 0, top = 0, k, i, rows;
    memset(&c, 0, sizeof c);
    if (!fc_pool) fc_pool = (FcEntry *)platform_alloc(FC_MAX * sizeof(FcEntry));
    if (fc_pool) { c.e = fc_pool; c.cap = FC_MAX; } else { c.e = fc_fallback; c.cap = FC_MIN; }
    for (v = 0; v < FC_FOLDERS; ++v) {
        c.cur = v; c.first[v] = c.stored;
        c.ret[v] = platform_raw_list(v, raw_cb, &c);
    }
    rows = fc_rows(&c);
    for (;;) {
        frame("File check", "UP/DOWN:Scroll   BACK:Back");
        keep_visible(sel, &top, LIST_ROWS);
        for (i = 0; i < LIST_ROWS && top + i < rows; ++i) {
            int dim;
            fc_row_text(&c, top + i, &dim);
            put(2, LIST_ROW0 + i, line, dim ? C_DIM : C_FG);
        }
        platform_present();
        k = get_key();
        if (k == K_BACK || k == K_ENTER) return;
        sel = move_sel(k, sel, rows, 0);
    }
}

void ui_show_settings(void) {
    static const char *items[] = { "Key test", "Save data now", "Reset all data (back to sample deck)", "Import a deck from a file (CSV etc.)", "File check (which files the app can see)" };
    int sel = 0, k, i;
    for (;;) {
        frame("Settings", "UP/DOWN:Select   ENTER:Run   BACK:Home");
        for (i = 0; i < 5; ++i) list_row(3 + i, items[i], i == sel);
        sprintf(line, "Data file : %s", storage_status_text());
        put(2, 9, line, storage_status() == STORAGE_SAVE_FAILED ? C_BAD : C_DIM);
        sprintf(line, "Day number: %u (from the clock)", platform_today());
        put(2, 10, line, C_DIM);
        sprintf(line, "Screen    : %dx%d, %dx%d chars", SCREEN_W, SCREEN_H, COLS, ROWS);
        put(2, 11, line, C_DIM);
        put(2, 13, "MemoAnki EX - development build", C_DIM);
        platform_present();

        k = get_key();
        if (k == K_BACK) return;
        if (k == K_ENTER) {
            if (sel == 0) key_test();
            else if (sel == 1) storage_save();
            else if (sel == 3) import_screen();
            else if (sel == 4) file_check();
            else if (confirm("Reset all data", "Delete ALL decks, cards and statistics?", "The sample deck will be created again.")) storage_reset();
            continue;
        }
        sel = move_sel(k, sel, 5, 1);
    }
}

#include "fileapp.inc"

/* ------------------------------------------------------------------ */
/* Home                                                               */
/* ------------------------------------------------------------------ */
static const char *menu_items[] = {
    "Study       - learn new cards",
    "Review      - cards that are due",
    "Decks       - create / rename / copy / delete / add cards",
    "Dictionary  - search your cards",
    "Wikipedia   - offline articles",
    "Statistics",
    "Settings    - key test, save, reset",
    "Files       - text editor / offline browser / sheet"
};
#define MENU_COUNT 8

void ui_init(void) {
    quit_flag = 0;
}

void ui_show_home(void) {
    int sel = 0, k, i;
    while (!quit_flag) {
        unsigned int today = platform_today();
        frame("MemoAnki EX", "UP/DOWN:Select   ENTER:Open   BACK or POWER:Exit");
        sprintf(line, "New cards: %u    Due for review: %u    Decks: %d",
                card_new_total(), card_due_total(today), deck_count());
        put(2, 2, line, C_ACCENT);
        for (i = 0; i < MENU_COUNT; ++i) list_row(4 + i * 2, menu_items[i], i == sel);
        if (storage_status() == STORAGE_SAVE_FAILED)
            put(2, 21, "Warning: progress cannot be saved on this device (see Settings).", C_BAD);
        platform_present();

        k = get_key();
        if (k == K_BACK) { quit_flag = 1; break; }
        if (k == K_ENTER) {
            switch (sel) {
                case 0: ui_show_study(); break;
                case 1: ui_show_review(); break;
                case 2: ui_show_decks(); break;
                case 3: ui_show_dictionary(); break;
                case 4: ui_show_wikipedia(); break;
                case 5: ui_show_stats(); break;
                case 6: ui_show_settings(); break;
                default: ui_show_files(); break;
            }
            continue;
        }
        sel = move_sel(k, sel, MENU_COUNT, 1);
    }
}

void ui_main_menu(void) {
    ui_show_home();
}
