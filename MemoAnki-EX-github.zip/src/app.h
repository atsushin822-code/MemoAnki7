#ifndef MEMOANKI_APP_H
#define MEMOANKI_APP_H

void app_init(void);
void app_run(void);
void app_shutdown(void);

#endif
