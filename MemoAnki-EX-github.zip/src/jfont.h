#ifndef MEMOANKI_JFONT_H
#define MEMOANKI_JFONT_H

/* 8x8 Japanese bitmap font (Misaki), generated into jfont_data.c. */
extern const unsigned int jfont_count;
extern const unsigned short jfont_cp[];
extern const unsigned char jfont_bits[][8];

/* 8 bytes (MSB = left pixel) for a code point >= 0x80, or NULL if the font has no glyph. */
const unsigned char *jfont_glyph(unsigned int cp);

#endif
