#ifndef MEMOANKI_DECK_H
#define MEMOANKI_DECK_H

#define MAX_DECKS 32
#define DECK_NAME_MAX 48

typedef struct {
    unsigned int id;                 /* stable id; cards refer to this */
    char name[DECK_NAME_MAX];        /* user-defined name */
    unsigned int card_count;         /* refreshed by deck_recount() */
} Deck;

void deck_init(void);
int deck_create(const char *name);                 /* returns index, or -1 */
int deck_rename(int index, const char *name);
int deck_delete(int index);                        /* also deletes the deck's cards */
int deck_copy(int index, const char *new_name);    /* copies cards, progress reset */
const Deck *deck_get(int index);
int deck_count(void);
void deck_recount(void);
unsigned int deck_id_at(int index);

/* Used by storage only. */
unsigned int deck_next_id(void);
void deck_set_next_id(unsigned int v);
int deck_load_add(const Deck *d);

#endif
