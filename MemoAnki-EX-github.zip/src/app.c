#include "app.h"
#include "ui.h"
#include "deck.h"
#include "card.h"
#include "study.h"
#include "dictionary.h"
#include "wikipedia.h"
#include "stats.h"
#include "storage.h"
#include "platform.h"

void app_init(void) {
    platform_init();
    storage_init();     /* sets up decks/cards/stats: loads the data file or seeds the sample deck */
    study_init();       /* must come after storage_init(): sizes its queue from the card capacity */
    dictionary_init();
    wikipedia_init();
    ui_init();
}

void app_run(void) {
    ui_main_menu();     /* returns when the user leaves the app (BACK on Home / POWER) */
}

void app_shutdown(void) {
    storage_flush();
}
