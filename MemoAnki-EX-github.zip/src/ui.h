#ifndef MEMOANKI_UI_H
#define MEMOANKI_UI_H

void ui_init(void);
void ui_main_menu(void);     /* Home loop; returns when the user exits */

void ui_show_home(void);
void ui_show_decks(void);
void ui_show_study(void);
void ui_show_review(void);
void ui_show_dictionary(void);
void ui_show_wikipedia(void);
void ui_show_stats(void);
void ui_show_files(void);
void ui_show_settings(void);

#endif
