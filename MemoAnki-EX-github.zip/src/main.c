/*
 * MemoAnki EX
 * XD-A8500 / DATAPLUS 5.
 *
 * Hardware-specific calls live in platform.c; learning logic is independent of it.
 * Returning -2 from main() is how an EX-word add-on hands control back to the system.
 */

#include "app.h"

int main(void) {
    app_init();
    app_run();
    app_shutdown();
    return -2;
}
