//----------------------------------------------------------------
// Statically-allocated memory manager
//
// by Eli Bendersky (eliben@gmail.com)
//  
// This code is in the public domain.
//----------------------------------------------------------------
#include <stdlib.h>
#include <string.h>

#include "logger.h"
#include "memmgr.h"

typedef ulong Align;

union mem_header_union
{
    struct 
    {
        // Pointer to the next block in the free list
        //
        union mem_header_union* next;

        // Size of the block (in quantas of sizeof(mem_header_t))
        //
        ulong size; 
    } s;

    // Used to align headers in memory to a boundary
    //
    Align align_dummy;
};

typedef union mem_header_union mem_header_t;

// Initial empty list
//
static mem_header_t base;

// Start of free list
//
static mem_header_t* freep = 0;

// Static pool for new allocations
//
static byte * pool;
static ulong pool_size = 0;
static ulong pool_free_pos = 0;

struct r_hdr {
    char sig[12];
    char model[4];
    unsigned long magic;
    unsigned long nor_size;
};

struct r_hdr* get_r_hdr() {
    struct r_hdr *hdr;
    hdr = (struct r_hdr*)0x8001ff80;
    if (memcmp(hdr->sig, "CASIODICS", 9) == 0) {
        return hdr;
    }
    return 0;
}

void set_mem_pool()
{
    int model = 0;
    pool_size = 0;
    struct r_hdr *hdr = get_r_hdr();
    if (hdr != 0) {
        if (hdr->model[0] == 'C') {
            model = atoi(hdr->model + 1);
            if (model < 160) {
                pool_size = 3072 * 1024;
                pool = (byte *)0x8c4be400;
            } else {
                pool_size = 8192 * 1024;
                pool = (byte *)0x8c800000;
            }
        }
    }
}


void memmgr_init()
{
    base.s.next = 0;
    base.s.size = 0;
    freep = 0;
    pool_free_pos = 0;
    set_mem_pool();
}


void memmgr_print_stats()
{
    #ifdef DEBUG_MEMMGR_SUPPORT_STATS
    mem_header_t* p;

    log_write("------ Memory manager stats ------\n\n");
    log_write(    "Pool: free_pos = %u (%u bytes left)\n\n\n", 
            pool_free_pos, pool_size - pool_free_pos);

    p = (mem_header_t*) pool;

    while (p < (mem_header_t*) (pool + pool_free_pos))
    {
        log_write(    "  * Addr: 0x%08x; Size: %08u\n",
                p, p->s.size);

        p += p->s.size;
    }

    log_write("\nFree list:\n\n");

    if (freep)
    {
        p = freep;

        while (1)
        {
            log_write(    "  * Addr: 0x%08x; Size: %08u; Next: 0x%08x\n", 
                    p, p->s.size, p->s.next);

            p = p->s.next;

            if (p == freep)
                break;
        }
    }
    else
    {
        log_write("Empty\n");
    }
    
    log_write("\n");
    #endif // DEBUG_MEMMGR_SUPPORT_STATS
}


static mem_header_t* get_mem_from_pool(ulong nquantas)
{
    ulong total_req_size;

    mem_header_t* h;

    if (nquantas < MIN_POOL_ALLOC_QUANTAS)
        nquantas = MIN_POOL_ALLOC_QUANTAS;

    total_req_size = nquantas * sizeof(mem_header_t);

    if (pool_free_pos + total_req_size <= pool_size)
    {
        h = (mem_header_t*) (pool + pool_free_pos);
        h->s.size = nquantas;
        memmgr_free((void*) (h + 1));
        pool_free_pos += total_req_size;
    }
    else
    {
        return 0;
    }

    return freep;
}


// Allocations are done in 'quantas' of header size.
// The search for a free block of adequate size begins at the point 'freep' 
// where the last block was found.
// If a too-big block is found, it is split and the tail is returned (this 
// way the header of the original needs only to have its size adjusted).
// The pointer returned to the user points to the free space within the block,
// which begins one quanta after the header.
//
void* memmgr_alloc(ulong nbytes)
{
    mem_header_t* p;
    mem_header_t* prevp;

    if (nbytes == 0)
        return 0;

    // Calculate how many quantas are required: we need enough to house all
    // the requested bytes, plus the header. The -1 and +1 are there to make sure
    // that if nbytes is a multiple of nquantas, we don't allocate too much
    //
    ulong nquantas = (nbytes + sizeof(mem_header_t) - 1) / sizeof(mem_header_t) + 1;

    // First alloc call, and no free list yet ? Use 'base' for an initial
    // denegerate block of size 0, which points to itself
    // 
    if ((prevp = freep) == 0)
    {
        base.s.next = freep = prevp = &base;
        base.s.size = 0;
    }

    for (p = prevp->s.next; ; prevp = p, p = p->s.next)
    {
        // big enough ?
        if (p->s.size >= nquantas) 
        {
            // exactly ?
            if (p->s.size == nquantas)
            {
                // just eliminate this block from the free list by pointing
                // its prev's next to its next
                //
                prevp->s.next = p->s.next;
            }
            else // too big
            {
                p->s.size -= nquantas;
                p += p->s.size;
                p->s.size = nquantas;
            }

            freep = prevp;
            return (void*) (p + 1);
        }
        // Reached end of free list ?
        // Try to allocate the block from the pool. If that succeeds,
        // get_mem_from_pool adds the new block to the free list and
        // it will be found in the following iterations. If the call
        // to get_mem_from_pool doesn't succeed, we've run out of
        // memory
        //
        else if (p == freep)
        {
            if ((p = get_mem_from_pool(nquantas)) == 0)
            {
                return 0;
            }
        }
    }
}

void *memmgr_realloc(void *ptr, ulong size)
{

	mem_header_t* block;
	void *newptr = 0;

	if (!ptr)
		return memmgr_alloc(size);
	if (!size) {
		memmgr_free(ptr);
		return memmgr_alloc(0);
	}

	newptr = memmgr_alloc(size);
	if (newptr) {
		block = ((mem_header_t*) ptr) - 1;
		ulong old_size = (block->s.size - 1) * sizeof(mem_header_t);
		memcpy(newptr, ptr, (old_size < size ? old_size : size));
		memmgr_free(ptr);
	}
	return newptr;
}


// Scans the free list, starting at freep, looking the the place to insert the 
// free block. This is either between two existing blocks or at the end of the
// list. In any case, if the block being freed is adjacent to either neighbor,
// the adjacent blocks are combined.
//
void memmgr_free(void* ap)
{
    mem_header_t* block;
    mem_header_t* p;

    if (ap == 0)
        return;

    // acquire pointer to block header
    block = ((mem_header_t*) ap) - 1;

    // Find the correct place to place the block in (the free list is sorted by
    // address, increasing order)
    //
    for (p = freep; !(block > p && block < p->s.next); p = p->s.next)
    {
        // Since the free list is circular, there is one link where a 
        // higher-addressed block points to a lower-addressed block. 
        // This condition checks if the block should be actually 
        // inserted between them
        //
        if (p >= p->s.next && (block > p || block < p->s.next))
            break;
    }

    // Try to combine with the higher neighbor
    //
    if (block + block->s.size == p->s.next)
    {
        block->s.size += p->s.next->s.size;
        block->s.next = p->s.next->s.next;
    }
    else
    {
        block->s.next = p->s.next;
    }

    // Try to combine with the lower neighbor
    //
    if (p + p->s.size == block)
    {
        p->s.size += block->s.size;
        p->s.next = block->s.next;
    }
    else
    {
        p->s.next = block;
    }

    freep = p;
}
