#include "textutil.h"

char text_lower(char c) {
    return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
}

unsigned int text_next(const char **p) {
    const unsigned char *s = (const unsigned char *)*p;
    unsigned int c = s[0];
    if (!c) return 0;
    if (c < 0x80) { *p += 1; return c; }
    if (c >= 0xE0 && c < 0xF0 && (s[1] & 0xC0) == 0x80 && (s[2] & 0xC0) == 0x80) {
        *p += 3;
        return ((c & 0x0Fu) << 12) | ((s[1] & 0x3Fu) << 6) | (s[2] & 0x3Fu);
    }
    if (c >= 0xC2 && c < 0xE0 && (s[1] & 0xC0) == 0x80) {
        *p += 2;
        return ((c & 0x1Fu) << 6) | (s[1] & 0x3Fu);
    }
    if (c >= 0xF0 && c < 0xF5 && (s[1] & 0xC0) == 0x80) {      /* 4-byte: skip, show as unknown */
        unsigned int k = 1;
        while (k < 4 && (s[k] & 0xC0) == 0x80) ++k;
        *p += k;
        return 0xFFFD;
    }
    *p += 1;                                                    /* stray byte */
    return 0xFFFD;
}

int text_append(char *buf, unsigned int max, unsigned int cp) {
    unsigned int len = 0;
    while (buf[len]) ++len;
    if (cp < 0x80) {
        if (len + 2 > max) return 0;
        buf[len] = (char)cp; buf[len + 1] = 0;
    } else if (cp < 0x800) {
        if (len + 3 > max) return 0;
        buf[len] = (char)(0xC0 | (cp >> 6)); buf[len + 1] = (char)(0x80 | (cp & 0x3F)); buf[len + 2] = 0;
    } else {
        if (len + 4 > max) return 0;
        buf[len] = (char)(0xE0 | (cp >> 12)); buf[len + 1] = (char)(0x80 | ((cp >> 6) & 0x3F));
        buf[len + 2] = (char)(0x80 | (cp & 0x3F)); buf[len + 3] = 0;
    }
    return 1;
}

unsigned int text_cells(const char *s) {
    unsigned int n = 0;
    while (text_next(&s)) ++n;
    return n;
}

void text_copy(char *dst, const char *src, unsigned int max) {
    unsigned int i = 0, j;
    if (!max) return;
    while (src && src[i] && i + 1 < max) ++i;
    /* cut inside a multi-byte character? then stop before that character */
    while (src && i > 0 && src[i] && ((unsigned char)src[i] & 0xC0) == 0x80) --i;
    for (j = 0; j < i; ++j) dst[j] = src[j];
    dst[i] = 0;
}

void text_copy_cells(char *dst, const char *src, unsigned int max_cells, unsigned int dstsize) {
    const char *p = src;
    unsigned int n = 0, bytes = 0;
    if (!dstsize) return;
    while (src && n < max_cells) {
        const char *q = p;
        if (!text_next(&q)) break;
        if (bytes + (unsigned int)(q - p) + 1 > dstsize) break;
        bytes += (unsigned int)(q - p);
        p = q; ++n;
    }
    {
        unsigned int i;
        for (i = 0; i < bytes; ++i) dst[i] = src[i];
        dst[bytes] = 0;
    }
}

void text_sanitize(char *dst, const char *src, unsigned int max) {
    unsigned int o = 0;
    const char *p = src;
    if (!max) return;
    while (p && *p) {
        const char *q = p;
        unsigned int cp = text_next(&q), k = (unsigned int)(q - p), i;
        if (cp == 0xFFFD && k == 1) { if (o + 2 > max) break; dst[o++] = '?'; p = q; continue; }
        if (cp < 0x20 || cp == 0x7F) { if (o + 2 > max) break; dst[o++] = ' '; p = q; continue; }
        if (o + k + 1 > max) break;
        for (i = 0; i < k; ++i) dst[o++] = p[i];
        p = q;
    }
    dst[o] = 0;
}

unsigned int text_next_line(const char *s, unsigned int n, unsigned int width, unsigned int *visible) {
    unsigned int p = 0, cells = 0;
    int last_space = -1;
    if (width < 1) width = 1;
    while (p < n && s[p]) {
        const char *q = s + p;
        unsigned int cp;
        if (s[p] == '\n') { *visible = p; return p + 1; }
        cp = text_next(&q);
        ++cells;
        if (cp == ' ') last_space = (int)p;
        if (cells > width) {
            if (cp == ' ') { *visible = p; return p + 1; }
            if (last_space >= 0) { *visible = (unsigned int)last_space; return (unsigned int)last_space + 1; }
            *visible = p; return p;                      /* hard break before this character */
        }
        p += (unsigned int)(q - (s + p));
    }
    *visible = p;
    return p;
}

int text_wrap(const char *src, WrapLine *lines, int max_lines, unsigned int width) {
    char buf[400];
    unsigned int pos = 0, len, n = 0;
    text_sanitize(buf, src, sizeof buf);
    len = 0; while (buf[len]) ++len;
    while (pos < len && (int)n < max_lines) {
        unsigned int vis, used, i;
        used = text_next_line(buf + pos, len - pos, width, &vis);
        if (vis > WRAP_BYTES - 1) vis = WRAP_BYTES - 1;
        for (i = 0; i < vis; ++i) lines[n][i] = buf[pos + i];
        lines[n][vis] = 0;
        ++n;
        pos += used;
        if (!used) break;
    }
    return (int)n;
}

int text_contains_ci(const char *hay, const char *needle) {
    unsigned int i, j;
    if (!needle || !*needle) return 1;
    for (i = 0; hay[i]; ++i) {
        for (j = 0; needle[j] && hay[i + j]; ++j)
            if (text_lower(hay[i + j]) != text_lower(needle[j])) break;
        if (!needle[j]) return 1;
    }
    return 0;
}

void text_make_key(char *dst, const char *src, unsigned int max) {
    const char *p = src;
    if (!max) return;
    dst[0] = 0;
    while (*p) {
        unsigned int cp = text_next(&p);
        if (cp >= 'A' && cp <= 'Z') cp += 32;
        else if (cp >= 0x30A1 && cp <= 0x30F6) cp -= 0x60;       /* katakana -> hiragana */
        if (!text_append(dst, max, cp)) break;
    }
}
