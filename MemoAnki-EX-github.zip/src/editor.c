#include "editor.h"
#include "platform.h"
#include "textutil.h"

typedef struct { const char *r; const char *kana; } Roma;

static const Roma table[] = {
    {"a","あ"},{"i","い"},{"u","う"},{"e","え"},{"o","お"},
    {"ka","か"},{"ki","き"},{"ku","く"},{"ke","け"},{"ko","こ"},
    {"sa","さ"},{"si","し"},{"shi","し"},{"su","す"},{"se","せ"},{"so","そ"},
    {"ta","た"},{"ti","ち"},{"chi","ち"},{"tu","つ"},{"tsu","つ"},{"te","て"},{"to","と"},
    {"na","な"},{"ni","に"},{"nu","ぬ"},{"ne","ね"},{"no","の"},
    {"ha","は"},{"hi","ひ"},{"hu","ふ"},{"fu","ふ"},{"he","へ"},{"ho","ほ"},
    {"ma","ま"},{"mi","み"},{"mu","む"},{"me","め"},{"mo","も"},
    {"ya","や"},{"yu","ゆ"},{"yo","よ"},
    {"ra","ら"},{"ri","り"},{"ru","る"},{"re","れ"},{"ro","ろ"},
    {"wa","わ"},{"wo","を"},
    {"ga","が"},{"gi","ぎ"},{"gu","ぐ"},{"ge","げ"},{"go","ご"},
    {"za","ざ"},{"zi","じ"},{"ji","じ"},{"zu","ず"},{"ze","ぜ"},{"zo","ぞ"},
    {"da","だ"},{"di","ぢ"},{"du","づ"},{"de","で"},{"do","ど"},
    {"ba","ば"},{"bi","び"},{"bu","ぶ"},{"be","べ"},{"bo","ぼ"},
    {"pa","ぱ"},{"pi","ぴ"},{"pu","ぷ"},{"pe","ぺ"},{"po","ぽ"},
    {"fa","ふぁ"},{"fi","ふぃ"},{"fe","ふぇ"},{"fo","ふぉ"},{"va","ゔぁ"},{"vu","ゔ"},
    {"kya","きゃ"},{"kyu","きゅ"},{"kyo","きょ"},{"gya","ぎゃ"},{"gyu","ぎゅ"},{"gyo","ぎょ"},
    {"sha","しゃ"},{"shu","しゅ"},{"sho","しょ"},{"sya","しゃ"},{"syu","しゅ"},{"syo","しょ"},
    {"ja","じゃ"},{"ju","じゅ"},{"jo","じょ"},{"jya","じゃ"},{"jyu","じゅ"},{"jyo","じょ"},
    {"cha","ちゃ"},{"chu","ちゅ"},{"cho","ちょ"},{"tya","ちゃ"},{"tyu","ちゅ"},{"tyo","ちょ"},
    {"nya","にゃ"},{"nyu","にゅ"},{"nyo","にょ"},{"hya","ひゃ"},{"hyu","ひゅ"},{"hyo","ひょ"},
    {"mya","みゃ"},{"myu","みゅ"},{"myo","みょ"},{"rya","りゃ"},{"ryu","りゅ"},{"ryo","りょ"},
    {"bya","びゃ"},{"byu","びゅ"},{"byo","びょ"},{"pya","ぴゃ"},{"pyu","ぴゅ"},{"pyo","ぴょ"},
    {"xa","ぁ"},{"xi","ぃ"},{"xu","ぅ"},{"xe","ぇ"},{"xo","ぉ"},{"xtu","っ"},{"xya","ゃ"},{"xyu","ゅ"},{"xyo","ょ"},
    {"la","ぁ"},{"li","ぃ"},{"lu","ぅ"},{"le","ぇ"},{"lo","ぉ"},{"ltu","っ"},{"lya","ゃ"},{"lyu","ゅ"},{"lyo","ょ"}
};
#define NTAB ((int)(sizeof table / sizeof table[0]))

static int is_vowel(char c) { return c == 'a' || c == 'i' || c == 'u' || c == 'e' || c == 'o'; }

/* 0 = no entry starts with p, 1 = prefix of a longer entry, 2 = exact (and maybe also a prefix) */
static int lookup(const char *p, const char **kana, int *longer) {
    int i, exact = 0;
    *longer = 0; *kana = 0;
    for (i = 0; i < NTAB; ++i) {
        const char *r = table[i].r, *q = p;
        while (*q && *r == *q) { ++r; ++q; }
        if (*q) continue;                 /* p is not a prefix of r */
        if (!*r) { exact = 1; *kana = table[i].kana; }
        else *longer = 1;
    }
    return exact ? 2 : (*longer ? 1 : 0);
}

static void put_kana(Editor *e, const char *k) {
    const char *p = k;
    unsigned int cp;
    while ((cp = text_next(&p)) != 0) {
        if (e->mode == ED_KATA && cp >= 0x3041 && cp <= 0x3096) cp += 0x60;
        text_append(e->buf, e->max, cp);
    }
}

void editor_init(Editor *e, char *buf, unsigned int max) {
    e->buf = buf; e->max = max; e->mode = ED_ABC; e->pend[0] = 0;
}

const char *editor_mode_name(const Editor *e) {
    static const char *names[ED_MODES] = { "abc", "ABC", "hira", "kata" };
    return names[e->mode];
}

void editor_commit(Editor *e) {
    if (e->pend[0] == 'n' && (!e->pend[1] || (e->pend[1] == 'n' && !e->pend[2]))) put_kana(e, "ん");   /* "n" or "nn" */
    e->pend[0] = 0;
}

/* Feed one letter in a kana mode. pend holds at most 2 letters between calls. */
static void kana_letter(Editor *e, char c) {
    for (;;) {
        unsigned int n = 0;
        const char *kana;
        int longer, r;
        while (e->pend[n]) ++n;

        /* "nn" is held back: before a vowel/y it is ん + n.., otherwise just ん */
        if (n == 2 && e->pend[0] == 'n' && e->pend[1] == 'n') {
            put_kana(e, "ん");
            e->pend[1] = 0;                           /* the second n starts the next syllable */
            continue;
        }
        if (n == 1 && e->pend[0] == 'n' && c == 'n') { e->pend[1] = 'n'; e->pend[2] = 0; return; }

        /* doubled consonant ("kk") -> small tsu; 'n' is excluded ("nn" is ん) */
        if (n == 1 && e->pend[0] == c && !is_vowel(c) && c != 'n') {
            put_kana(e, "っ");
            return;                                   /* pend keeps the consonant */
        }
        /* "n" + consonant (not y / n) -> ん, then handle the consonant afresh */
        if (n == 1 && e->pend[0] == 'n' && !is_vowel(c) && c != 'y' && c != 'n') {
            put_kana(e, "ん");
            e->pend[0] = 0;
            continue;
        }
        e->pend[n] = c;
        e->pend[n + 1] = 0;
        r = lookup(e->pend, &kana, &longer);
        if (r == 2) { put_kana(e, kana); e->pend[0] = 0; return; }
        if (r == 1) return;                           /* a longer romaji may follow */

        /* no romaji starts like this: forget the oldest pending letter and retry */
        e->pend[n] = 0;
        if (n == 0) return;                           /* unknown letter on its own: ignore */
        e->pend[0] = e->pend[1];                      /* shift left (pend[1] may be NUL) */
        e->pend[1] = 0;
    }
}

int editor_key(Editor *e, int key) {
    if (key >= 'a' && key <= 'z') {
        if (e->mode == ED_HIRA || e->mode == ED_KATA) kana_letter(e, (char)key);
        else text_append(e->buf, e->max, e->mode == ED_CAPS ? (unsigned int)(key - 32) : (unsigned int)key);
        return 1;
    }
    switch (key) {
        case K_SYMBOL:
            editor_commit(e);
            text_append(e->buf, e->max, ' ');
            return 1;
        case K_SHIFT:                              /* toggle abc <-> ABC; kana modes -> abc */
            editor_commit(e);
            e->mode = (e->mode == ED_ABC) ? ED_CAPS : ED_ABC;
            return 1;
        case K_F1:                                 /* cycle input mode */
            editor_commit(e);
            e->mode = (e->mode + 1) % ED_MODES;
            return 1;
        case K_F2: editor_commit(e); text_append(e->buf, e->max, e->mode >= ED_HIRA ? 0x30FC : '-'); return 1;
        case K_F3: editor_commit(e); text_append(e->buf, e->max, e->mode >= ED_HIRA ? 0x3001 : ','); return 1;
        case K_F4: editor_commit(e); text_append(e->buf, e->max, e->mode >= ED_HIRA ? 0x3002 : '.'); return 1;
        case K_BKSP: {
            unsigned int len = 0;
            if (e->pend[0]) { e->pend[0] = 0; return 1; }
            while (e->buf[len]) ++len;
            if (!len) return 1;
            --len;
            while (len > 0 && ((unsigned char)e->buf[len] & 0xC0) == 0x80) --len;
            e->buf[len] = 0;
            return 1;
        }
        default: return 0;
    }
}
