#ifndef MEMOANKI_STUDY_H
#define MEMOANKI_STUDY_H

#include "card.h"

#define STUDY_NEW_LIMIT 20      /* new cards per Study session */

typedef enum { STUDY_NEW = 0, STUDY_REVIEW = 1 } StudyMode;

void study_init(void);
/* Build the queue for a deck. Returns the number of cards queued. */
int study_begin(unsigned int deck_id, StudyMode mode);
Card *study_current(void);                 /* NULL when the queue is empty */
unsigned int study_total(void);            /* cards queued at start */
unsigned int study_done(void);             /* cards finished (rated >= 2) */
unsigned int study_answers(void);          /* ratings given this session */
unsigned int study_correct(void);          /* ratings >= 2 this session */
/* Apply a 0..4 rating to the current card. 0/1 put it back at the end of the queue. */
void study_answer(int rating);

unsigned int study_next_interval(unsigned int old_interval, int rating);
void study_record(int rating);

#endif
