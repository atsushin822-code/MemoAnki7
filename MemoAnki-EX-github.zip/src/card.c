#include "card.h"
#include "textutil.h"
#include "platform.h"
#include <string.h>

/* The static RAM of an EX-word add-on is tiny (~32 KB), so the card table lives in the
   system memory pool. If that is unavailable we fall back to a small static table. */
static Card fallback_pool[FALLBACK_CARDS];
static Card *pool = 0;
static int capacity = 0;
static int total = 0;
static unsigned int next_id = 1;

void card_init(void) {
    if (!pool) {
        pool = (Card *)platform_alloc(MAX_CARDS * (unsigned int)sizeof(Card));
        capacity = MAX_CARDS;
        if (!pool) { pool = fallback_pool; capacity = FALLBACK_CARDS; }
    }
    total = 0; next_id = 1;
}
int card_total(void) { return total; }
int card_capacity(void) { return capacity; }
Card *card_at(int i) { return (i >= 0 && i < total) ? &pool[i] : 0; }
void card_set_total(int n) { total = (n < 0) ? 0 : (n > capacity ? capacity : n); }
unsigned int card_next_id(void) { return next_id; }
void card_set_next_id(unsigned int v) { next_id = v ? v : 1; }

static void reset_progress(Card *c) {
    c->ease = 0; c->interval = 0; c->due_day = 0; c->reviews = 0; c->correct = 0;
}

Card *card_add(unsigned int deck_id, const char *front, const char *back, const char *example) {
    Card *c;
    if (!pool || total >= capacity) return 0;
    c = &pool[total++];
    c->id = next_id++;
    c->deck_id = deck_id;
    text_copy(c->front, front, TEXT_MAX);
    text_copy(c->back, back, TEXT_MAX);
    text_copy(c->example, example, TEXT_MAX);
    reset_progress(c);
    return c;
}

void card_remove_deck(unsigned int deck_id) {
    int i, o = 0;
    for (i = 0; i < total; ++i) {
        if (pool[i].deck_id == deck_id) continue;
        if (o != i) memcpy(&pool[o], &pool[i], sizeof(Card));
        ++o;
    }
    total = o;
}

int card_copy_deck(unsigned int src, unsigned int dst) {
    int i, n = total, copied = 0;
    for (i = 0; i < n; ++i) {
        if (pool[i].deck_id != src) continue;
        if (!card_add(dst, pool[i].front, pool[i].back, pool[i].example)) break;
        ++copied;
    }
    return copied;
}

unsigned int card_count_in_deck(unsigned int deck_id) {
    unsigned int n = 0; int i;
    for (i = 0; i < total; ++i) if (pool[i].deck_id == deck_id) ++n;
    return n;
}

unsigned int card_new_in_deck(unsigned int deck_id) {
    unsigned int n = 0; int i;
    for (i = 0; i < total; ++i)
        if (pool[i].deck_id == deck_id && pool[i].reviews == 0) ++n;
    return n;
}

unsigned int card_due_in_deck(unsigned int deck_id, unsigned int today) {
    unsigned int n = 0; int i;
    for (i = 0; i < total; ++i)
        if (pool[i].deck_id == deck_id && pool[i].reviews > 0 && pool[i].due_day <= today) ++n;
    return n;
}

unsigned int card_new_total(void) {
    unsigned int n = 0; int i;
    for (i = 0; i < total; ++i) if (pool[i].reviews == 0) ++n;
    return n;
}

unsigned int card_due_total(unsigned int today) {
    unsigned int n = 0; int i;
    for (i = 0; i < total; ++i)
        if (pool[i].reviews > 0 && pool[i].due_day <= today) ++n;
    return n;
}
