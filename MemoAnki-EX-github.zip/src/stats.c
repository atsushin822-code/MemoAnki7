#include "stats.h"
#include "platform.h"
#include <string.h>

static Stats st;

void stats_init(void) {
    unsigned char *p = (unsigned char *)&st;
    unsigned int i;
    for (i = 0; i < sizeof st; ++i) p[i] = 0;
}

void stats_record_review(int rating) {
    unsigned int today = platform_today();
    if (rating < 0) rating = 0;
    if (rating > 4) rating = 4;
    if (st.today != today) { st.today = today; st.today_reviews = 0; }
    ++st.reviews;
    ++st.today_reviews;
    ++st.by_rating[rating];
    if (rating >= 2) ++st.correct;
}

unsigned int stats_reviews(void) { return st.reviews; }
unsigned int stats_correct(void) { return st.correct; }

unsigned int stats_today_reviews(void) {
    return st.today == platform_today() ? st.today_reviews : 0;
}

const Stats *stats_get(void) { return &st; }
void stats_set(const Stats *s) { memcpy(&st, s, sizeof st); }
