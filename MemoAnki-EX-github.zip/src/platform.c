/*
 * Device platform layer for CASIO EX-word DATAPLUS 5 (XD-A8500).
 * Uses libdataplus: graphics (528x320 RGB565), keypad, file syscalls.
 */
#include "platform.h"
#include "textutil.h"
#include "jfont.h"

#include <graphics/drawing.h>
#include <graphics/color.h>
#include <graphics/text.h>
#include <graphics/lcdc.h>
#include <sh4a/input/keypad.h>
#include <syscalls/syscalls.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static uint16_t pal[C_COUNT];

/* ------------------------------------------------------------------ */
/* Keys                                                               */
/* ------------------------------------------------------------------ */
typedef struct { unsigned char code; short key; } KeyMap;

static const KeyMap keymap[] = {
    { KEY_POWER, K_POWER },   { KEY_BACK, K_BACK },     { KEY_ENTER, K_ENTER },
    { KEY_UP, K_UP },         { KEY_DOWN, K_DOWN },     { KEY_LEFT, K_LEFT },
    { KEY_RIGHT, K_RIGHT },   { KEY_PAGE_UP, K_PGUP },  { KEY_PAGE_DOWN, K_PGDN },
    { KEY_FUNC_1, K_F1 },     { KEY_FUNC_2, K_F2 },     { KEY_FUNC_3, K_F3 },
    { KEY_FUNC_4, K_F4 },     { KEY_FUNC_5, K_F5 },     { KEY_FUNC_6, K_F6 },
    { KEY_FUNC_7, K_F7 },     { KEY_FUNC_8, K_F8 },
    { KEY_BACKSPACE, K_BKSP },{ KEY_SHIFT, K_SHIFT },   { KEY_SYMBOL, K_SYMBOL },
    { KEY_ZOOM, K_ZOOM },     { KEY_JUMP, K_JUMP },     { KEY_HISTORY, K_HISTORY },
    { KEY_AUDIO, K_AUDIO },
    { KEY_CHAR_A, 'a' }, { KEY_CHAR_B, 'b' }, { KEY_CHAR_C, 'c' }, { KEY_CHAR_D, 'd' },
    { KEY_CHAR_E, 'e' }, { KEY_CHAR_F, 'f' }, { KEY_CHAR_G, 'g' }, { KEY_CHAR_H, 'h' },
    { KEY_CHAR_I, 'i' }, { KEY_CHAR_J, 'j' }, { KEY_CHAR_K, 'k' }, { KEY_CHAR_L, 'l' },
    { KEY_CHAR_M, 'm' }, { KEY_CHAR_N, 'n' }, { KEY_CHAR_O, 'o' }, { KEY_CHAR_P, 'p' },
    { KEY_CHAR_Q, 'q' }, { KEY_CHAR_R, 'r' }, { KEY_CHAR_S, 's' }, { KEY_CHAR_T, 't' },
    { KEY_CHAR_U, 'u' }, { KEY_CHAR_V, 'v' }, { KEY_CHAR_W, 'w' }, { KEY_CHAR_X, 'x' },
    { KEY_CHAR_Y, 'y' }, { KEY_CHAR_Z, 'z' }
};
#define NKEYS ((int)(sizeof keymap / sizeof keymap[0]))

static unsigned char held[NKEYS];

int platform_wait_key(void) {
    int i;
    for (;;) {
        keypad_read();
        for (i = 0; i < NKEYS; ++i) {
            unsigned char now = get_key_state(keymap[i].code) ? 1 : 0;
            if (now && !held[i]) {          /* new press edge */
                held[i] = 1;
                return keymap[i].key;
            }
            held[i] = now;
        }
    }
}

static const char *letter_names = "abcdefghijklmnopqrstuvwxyz";
const char *platform_key_name(int key) {
    static char one[2];
    switch (key) {
        case K_UP: return "UP";           case K_DOWN: return "DOWN";
        case K_LEFT: return "LEFT";       case K_RIGHT: return "RIGHT";
        case K_ENTER: return "ENTER";     case K_BACK: return "BACK";
        case K_POWER: return "POWER";     case K_PGUP: return "PAGE UP";
        case K_PGDN: return "PAGE DOWN";  case K_F1: return "F1";
        case K_F2: return "F2";           case K_F3: return "F3";
        case K_F4: return "F4";           case K_F5: return "F5";
        case K_F6: return "F6";           case K_F7: return "F7";
        case K_F8: return "F8";           case K_BKSP: return "BACKSPACE";
        case K_SHIFT: return "SHIFT";     case K_SYMBOL: return "SYMBOL";
        case K_ZOOM: return "ZOOM";       case K_JUMP: return "JUMP";
        case K_HISTORY: return "HISTORY"; case K_AUDIO: return "AUDIO";
        default: break;
    }
    if (key >= 'a' && key <= 'z') { one[0] = letter_names[key - 'a']; one[1] = 0; return one; }
    return "?";
}

/* ------------------------------------------------------------------ */
/* Graphics                                                           */
/* ------------------------------------------------------------------ */
void platform_init(void) {
    int i;
    memmgr_init();                      /* bulk-memory pool (see platform_alloc) */
    pal[C_BG]       = create_rgb16(0, 0, 0);
    pal[C_FG]       = create_rgb16(255, 255, 255);
    pal[C_DIM]      = create_rgb16(150, 150, 150);
    pal[C_TITLE_BG] = create_rgb16(0, 70, 160);
    pal[C_TITLE_FG] = create_rgb16(255, 255, 255);
    pal[C_SEL_BG]   = create_rgb16(255, 255, 255);
    pal[C_SEL_FG]   = create_rgb16(0, 0, 0);
    pal[C_ACCENT]   = create_rgb16(255, 220, 0);
    pal[C_GOOD]     = create_rgb16(0, 255, 0);
    pal[C_BAD]      = create_rgb16(255, 90, 90);
    pal[C_BAR]      = create_rgb16(50, 50, 70);

    /* A key that is still held from launching the app must not count as a press. */
    keypad_read();
    for (i = 0; i < NKEYS; ++i) held[i] = get_key_state(keymap[i].code) ? 1 : 0;
}

void platform_rect(int x, int y, int w, int h, int color) {
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > SCREEN_W) w = SCREEN_W - x;
    if (y + h > SCREEN_H) h = SCREEN_H - y;
    if (w <= 0 || h <= 0) return;
    set_pen(pal[color]);
    draw_rect((uint16_t)x, (uint16_t)y, (uint16_t)w, (uint16_t)h);
}

void platform_set_color(int idx, int rgb) {
    if (idx >= 0 && idx < C_COUNT) pal[idx] = create_rgb16((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255);
}

void platform_clear(void) { platform_rect(0, 0, SCREEN_W, SCREEN_H, C_BG); }

void platform_cell_rect(int col, int row, int ncols, int nrows, int color) {
    platform_rect(col * FONT_W, row * FONT_H + Y_OFF, ncols * FONT_W, nrows * FONT_H, color);
}

/* Draw a 1-bit bitmap (MSB = left pixel), merging pixels into horizontal runs.
   scale 1 or 2. */
static void blit_rows(int x, int y, const unsigned char *rows, int nrows, int scale, int color) {
    int r, c;
    set_pen(pal[color]);
    for (r = 0; r < nrows; ++r) {
        unsigned char b = rows[r];
        c = 0;
        while (c < 8) {
            int start;
            if (!((b >> (7 - c)) & 1)) { ++c; continue; }
            start = c;
            while (c < 8 && ((b >> (7 - c)) & 1)) ++c;
            draw_rect((uint16_t)(x + start * scale), (uint16_t)(y + r * scale),
                      (uint16_t)((c - start) * scale), (uint16_t)scale);
        }
    }
}

static const unsigned char *ascii_rows(unsigned int cp) {
    struct font *f = get_font();
    if (cp < 32 || cp > 126) cp = 32;
    return f->data + (cp - 32) * 12;
}

static void text_impl(int col, int row, const char *s, int color, int scale) {
    int x = col * FONT_W, y = row * FONT_H + Y_OFF;
    unsigned int cp;
    static char run[COLS + 1];
    int runlen = 0, runx = x;
    if (col < 0 || row < 0 || row >= ROWS || !s) return;
    for (;;) {
        cp = text_next(&s);
        if (cp == 0 || x >= SCREEN_W) break;
        if (cp < 0x80 && scale == 1) {                  /* batch ASCII into one render_text call */
            if (runlen == 0) runx = x;
            run[runlen++] = (cp < 0x20) ? ' ' : (char)cp;
            x += FONT_W;
            continue;
        }
        if (runlen) {
            run[runlen] = 0; set_pen(pal[color]);
            render_text((uint16_t)runx, (uint16_t)y, run); runlen = 0;
        }
        if (cp < 0x80) {
            blit_rows(x, y, ascii_rows(cp), 12, scale, color);
        } else {
            const unsigned char *g = jfont_glyph(cp);
            if (!g) g = ascii_rows('?');
            if (g == ascii_rows('?')) blit_rows(x, y, g, 12, scale, color);
            else blit_rows(x, y + 2 * scale, g, 8, scale, color);
        }
        x += FONT_W * scale;
    }
    if (runlen) {
        run[runlen] = 0; set_pen(pal[color]);
        render_text((uint16_t)runx, (uint16_t)y, run);
    }
}

void platform_text(int col, int row, const char *s, int color)     { text_impl(col, row, s, color, 1); }
void platform_text_big(int col, int row, const char *s, int color) { text_impl(col, row, s, color, 2); }

void platform_present(void) { lcdc_copy_vram(); }

void *platform_alloc(unsigned int bytes) { return memmgr_alloc(bytes); }

/* ------------------------------------------------------------------ */
/* Time                                                               */
/* ------------------------------------------------------------------ */
unsigned int platform_today(void) {
    return (unsigned int)(time(0) / 86400UL);
}

/* ------------------------------------------------------------------ */
/* Files: <media>\<dict id>\_USER\NAME, falling back to <dict id>\NAME */
/* ------------------------------------------------------------------ */
static const char *media[2] = { "\\\\drv0\\", "\\\\crd0\\" };

#define MAXF 3
static struct { int fd; unsigned long pos; int used; } files[MAXF];

static const char *data_path(const char *name, int variant) {
    static char path[100];
    char id[10];
    unsigned long drv = 0;
    sys_dict_info(&drv, id);
    if (drv > 1) drv = 0;
    strcpy(path, media[drv]);
    strcat(path, id);
    strcat(path, variant == 0 ? "\\_USER\\" : "\\");
    strcat(path, name);
    return path;
}

int platform_file_open(const char *name, int for_write) {
    int variant, fd, slot;
    for (slot = 0; slot < MAXF && files[slot].used; ++slot) {}
    if (slot == MAXF) return -1;
    for (variant = 0; variant < 2; ++variant) {
        const char *path = data_path(name, variant);
        if (for_write) {
            sys_delete(path);
            if (sys_create(path, 1) < 0) continue;
            fd = sys_open(path, FILE_WR);
        } else {
            fd = sys_open(path, FILE_RD);
        }
        if (fd >= 0) { files[slot].fd = fd; files[slot].pos = 0; files[slot].used = 1; return slot; }
    }
    return -1;
}

void platform_file_seek(int h, unsigned long pos) {
    if (h >= 0 && h < MAXF && files[h].used) files[h].pos = pos;
}

int platform_file_read(int h, void *buf, int n) {
    int r;
    if (h < 0 || h >= MAXF || !files[h].used) return -1;
    sys_seek(files[h].fd, (int)files[h].pos, 0);
    r = sys_read(files[h].fd, buf, n);
    if (r > 0) files[h].pos += (unsigned long)r;
    return r;
}

int platform_file_write(int h, const void *buf, int n) {
    if (h < 0 || h >= MAXF || !files[h].used) return -1;
    return sys_write(files[h].fd, buf, n);
}

int platform_list_files(const char *pattern, void (*cb)(const char *, void *), void *ctx) {
    /* Same call sequence as the ROM menu of Gnuboy EX (type 1 = regular file). Only type 2 (folder) is skipped here, in case a device reports other values for files. */
    int variant, found = 0;
    for (variant = 0; variant < 2; ++variant) {
        int handle = 0, ret;
        char name[64];
        unsigned long type = 0;
        ret = sys_findfirst(data_path(pattern, variant), &handle, name, &type);
        while (ret == 0) {
            if (type != 2) { cb(name, ctx); ++found; }      /* any entry but a folder: the callers filter by extension */
            ret = sys_findnext(handle, name, &type);
        }
        sys_findclose(handle);
    }
    return found;
}

const char *platform_dir(int variant) { return data_path("", variant); }

int platform_raw_list(int variant, void (*cb)(const char *, unsigned long, void *), void *ctx) {
    int handle = 0, ret, first, guard = 0;
    char name[64];
    unsigned long type = 0;
    first = ret = sys_findfirst(data_path("*.*", variant), &handle, name, &type);
    while (ret == 0 && guard++ < 200) {
        cb(name, type, ctx);
        ret = sys_findnext(handle, name, &type);
    }
    sys_findclose(handle);
    return first;
}

void platform_file_close(int h) {
    if (h < 0 || h >= MAXF || !files[h].used) return;
    sys_close(files[h].fd);
    files[h].used = 0;
}
