#ifndef MEMOANKI_PLATFORM_H
#define MEMOANKI_PLATFORM_H

/*
 * Platform layer: the ONLY place that touches XD-A8500 (DATAPLUS 5) APIs.
 *   - device build : src/platform.c        (libdataplus: graphics, keypad, file syscalls)
 *   - host build   : tools/sim/platform_sim.c (framebuffer + scripted keys, for CI screenshots)
 */

#define SCREEN_W 528
#define SCREEN_H 320
#define FONT_W   8
#define FONT_H   12
#define COLS     (SCREEN_W / FONT_W)      /* 66 */
#define ROWS     26                       /* 26 * 12 = 312 px, 4 px margin top/bottom */
#define Y_OFF    4

/* Palette (logical colours). */
enum {
    C_BG, C_FG, C_DIM, C_TITLE_BG, C_TITLE_FG, C_SEL_BG, C_SEL_FG,
    C_ACCENT, C_GOOD, C_BAD, C_BAR,
    C_USER1, C_USER2,                 /* free slots: set with platform_set_color() */
    C_COUNT
};

/* Logical keys. Letter keys are returned as lower-case ASCII 'a'..'z'. */
enum {
    K_NONE = 0,
    K_UP, K_DOWN, K_LEFT, K_RIGHT, K_ENTER, K_BACK, K_POWER,
    K_PGUP, K_PGDN,
    K_F1, K_F2, K_F3, K_F4, K_F5, K_F6, K_F7, K_F8,
    K_BKSP, K_SHIFT, K_SYMBOL, K_ZOOM, K_JUMP, K_HISTORY, K_AUDIO
};

void platform_init(void);
/* Redefine a palette slot (use C_USER1 / C_USER2). rgb = 0xRRGGBB. */
void platform_set_color(int idx, int rgb);
void platform_clear(void);
/* Pixel rectangle (clipped to the screen). */
void platform_rect(int x, int y, int w, int h, int color);
/* Rectangle aligned to the character grid. */
void platform_cell_rect(int col, int row, int ncols, int nrows, int color);
/* Draw UTF-8 text at a character cell; one code point = one cell. ASCII uses the device's 8x12 font,
   Japanese the built-in 8x8 Misaki font (jfont.h); unknown characters are shown as '?'. */
void platform_text(int col, int row, const char *s, int color);
/* Same, doubled in size: each character covers 2 cells x 2 rows. */
void platform_text_big(int col, int row, const char *s, int color);
/* Push the off-screen buffer to the LCD. */
void platform_present(void);
/* Block until a NEW key press happens; returns K_* or a lower-case letter. */
int platform_wait_key(void);
const char *platform_key_name(int key);

/* Bulk memory. The device has only ~32 KB of static RAM, so large tables come from
   the system memory pool (memmgr). Returns NULL when unavailable. Never freed. */
void *platform_alloc(unsigned int bytes);

/* Days since 1970-01-01 from the RTC. */
unsigned int platform_today(void);

/* Persistent data files (up to 3 open at once). Return handle >= 0 or -1. */
int  platform_file_open(const char *name, int for_write);
void platform_file_seek(int h, unsigned long pos);          /* next read starts here */
int  platform_file_read(int h, void *buf, int n);          /* bytes read, <0 on error */
int  platform_file_write(int h, const void *buf, int n);   /* bytes written, <0 on error */
void platform_file_close(int h);
/* Call cb(name, ctx) for every file in the data folders (_USER\ and the app folder) matching a pattern such as
   "*.CSV". Returns the number of files found (0 also when the device cannot list files). */
int  platform_list_files(const char *pattern, void (*cb)(const char *name, void *ctx), void *ctx);

/* For the "File check" screen: the folder that is searched (variant 0 = _USER\, 1 = the app folder) and a raw "*.*"
   search of it. Returns the sys_findfirst result (0 = ok); cb gets every entry with its type value. */
const char *platform_dir(int variant);
int  platform_raw_list(int variant, void (*cb)(const char *name, unsigned long type, void *ctx), void *ctx);

#endif
