#ifndef MEMOANKI_CARD_H
#define MEMOANKI_CARD_H

#define TEXT_MAX   128     /* bytes per text field (UTF-8), including NUL */
#define MAX_CARDS  600     /* capacity when the system memory pool is available */
#define FALLBACK_CARDS 16  /* capacity of the small static pool used otherwise */

typedef struct {
    unsigned int id;
    unsigned int deck_id;     /* stable deck id (see deck.h) */
    char front[TEXT_MAX];
    char back[TEXT_MAX];
    char example[TEXT_MAX];
    unsigned char ease;       /* last rating 0..4 */
    unsigned int interval;    /* days */
    unsigned long due_day;    /* days since 1970-01-01 */
    unsigned int reviews;
    unsigned int correct;
} Card;

void  card_init(void);
int   card_total(void);
int   card_capacity(void);
Card *card_at(int index);
Card *card_add(unsigned int deck_id, const char *front, const char *back, const char *example);
void  card_remove_deck(unsigned int deck_id);
int   card_copy_deck(unsigned int src_deck, unsigned int dst_deck);   /* progress is reset; returns copied */

unsigned int card_count_in_deck(unsigned int deck_id);
unsigned int card_new_in_deck(unsigned int deck_id);
unsigned int card_due_in_deck(unsigned int deck_id, unsigned int today);
unsigned int card_new_total(void);
unsigned int card_due_total(unsigned int today);

/* Used by storage only. */
void card_set_total(int n);
unsigned int card_next_id(void);
void card_set_next_id(unsigned int v);

#endif
