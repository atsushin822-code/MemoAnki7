#ifndef MEMOANKI_WIKIPEDIA_H
#define MEMOANKI_WIKIPEDIA_H

/*
 * Offline Wikipedia reader. Data file WIKI.DAT is prepared on a PC (tools/wikipedia_prepare.py):
 *   header (32 bytes): "MWK1", u32 count, u32 index_off, u32 data_off, 16 reserved   (big-endian)
 *   index  (96 bytes each, sorted by key): key[32], title[48], u32 off, u32 len, 8 reserved
 *   data   : article texts (UTF-8), addressed by data_off + off
 * Search keys are lower-case ASCII / hiragana (katakana folded), so Japanese can be found by typing romaji.
 */
#define WIKI_KEY_MAX    32
#define WIKI_TITLE_MAX  48

typedef struct {
    char key[WIKI_KEY_MAX];
    char title[WIKI_TITLE_MAX];
    unsigned long off, len;
} WikiEntry;

void wikipedia_init(void);
int  wikipedia_available(void);                       /* opens and validates WIKI.DAT (stays open) */
void wikipedia_close(void);
unsigned long wikipedia_count(void);
unsigned long wikipedia_lower_bound(const char *key_prefix);   /* first index whose key >= prefix */
int  wikipedia_entry(unsigned long index, WikiEntry *e);       /* 0 = ok */
int  wikipedia_key_matches(const WikiEntry *e, const char *key_prefix);
/* Read the article text; returns bytes read (<= max), or -1. */
long wikipedia_read_text(const WikiEntry *e, char *buf, unsigned long max);

#endif
