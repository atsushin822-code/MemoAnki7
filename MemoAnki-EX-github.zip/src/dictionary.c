#include "dictionary.h"
#include "textutil.h"

static int results[DICT_MAX_RESULTS];
static int nresults = 0;

void dictionary_init(void) { nresults = 0; }

int dictionary_search(const char *query) {
    int i;
    nresults = 0;
    if (!query || !*query) return 0;
    for (i = 0; i < card_total() && nresults < DICT_MAX_RESULTS; ++i) {
        const Card *c = card_at(i);
        if (text_contains_ci(c->front, query) || text_contains_ci(c->back, query))
            results[nresults++] = i;
    }
    return nresults;
}

int dictionary_count(void) { return nresults; }

const Card *dictionary_result(int index) {
    return (index >= 0 && index < nresults) ? card_at(results[index]) : 0;
}
