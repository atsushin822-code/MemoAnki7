#include "study.h"
#include "stats.h"
#include "storage.h"
#include "platform.h"

/* Queue of card indices, as a ring buffer. Allocated once from the system memory pool
   (the device has very little static RAM); a small static ring is the fallback. */
static unsigned short queue_fallback[FALLBACK_CARDS];
static unsigned short *queue = 0;
static unsigned int qcap = 0;
static unsigned int qhead, qlen, q_total, q_done, s_answers, s_correct, s_today;

void study_init(void) {
    qhead = qlen = q_total = q_done = s_answers = s_correct = 0;
    if (!queue) {
        qcap = (unsigned int)card_capacity();
        if (qcap > FALLBACK_CARDS) queue = (unsigned short *)platform_alloc(qcap * (unsigned int)sizeof(unsigned short));
        if (!queue) { queue = queue_fallback; qcap = FALLBACK_CARDS; }
    }
}

int study_begin(unsigned int deck_id, StudyMode mode) {
    int i;
    study_init();
    s_today = platform_today();
    for (i = 0; i < card_total() && qlen < qcap; ++i) {
        Card *c = card_at(i);
        if (c->deck_id != deck_id) continue;
        if (mode == STUDY_NEW) {
            if (c->reviews == 0 && qlen < STUDY_NEW_LIMIT) queue[qlen++] = (unsigned short)i;
        } else if (c->reviews > 0 && c->due_day <= s_today) {
            queue[qlen++] = (unsigned short)i;
        }
    }
    q_total = qlen;
    return (int)qlen;
}

Card *study_current(void) { return qlen ? card_at(queue[qhead]) : 0; }
unsigned int study_total(void) { return q_total; }
unsigned int study_done(void) { return q_done; }
unsigned int study_answers(void) { return s_answers; }
unsigned int study_correct(void) { return s_correct; }

void study_answer(int rating) {
    int idx;
    Card *c = study_current();
    if (!c) return;
    if (rating < 0) rating = 0;
    if (rating > 4) rating = 4;

    idx = queue[qhead];
    if (++qhead >= qcap) qhead = 0;
    --qlen;

    c->reviews++;
    if (rating >= 2) c->correct++;
    c->ease = (unsigned char)rating;
    c->interval = study_next_interval(c->interval, rating);
    if (c->interval > 3650) c->interval = 3650;

    if (rating <= 1) {                       /* see it again in this session */
        unsigned int tail = qhead + qlen;
        if (tail >= qcap) tail -= qcap;
        queue[tail] = (unsigned short)idx;
        ++qlen;
        c->due_day = s_today;
    } else {
        c->due_day = s_today + c->interval;
        ++q_done;
        ++s_correct;
    }
    ++s_answers;
    study_record(rating);
}

unsigned int study_next_interval(unsigned int old_interval, int rating) {
    unsigned int n = old_interval ? old_interval : 1;
    switch (rating) {
        case 0: return 1;
        case 1: return 1;
        case 2: return n < 2 ? 2 : n + 1;
        case 3: return n < 3 ? 3 : n * 2;
        case 4: return n < 4 ? 4 : n * 3;
        default: return n;
    }
}

void study_record(int rating) {
    stats_record_review(rating);
    storage_note_change();
}
