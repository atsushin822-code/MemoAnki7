#ifndef MEMOANKI_EDITOR_H
#define MEMOANKI_EDITOR_H

/* Text editor state with Latin and romaji->kana input. No platform dependency. */
enum { ED_ABC = 0, ED_CAPS, ED_HIRA, ED_KATA, ED_MODES };

typedef struct {
    char *buf;              /* text being edited (UTF-8) */
    unsigned int max;       /* size of buf, including NUL */
    int mode;               /* ED_* */
    char pend[4];           /* romaji typed but not yet converted */
} Editor;

void editor_init(Editor *e, char *buf, unsigned int max);
/* Feed one key (platform.h K_* or 'a'..'z'). Returns 1 if the key was consumed as editing. */
int  editor_key(Editor *e, int key);
void editor_commit(Editor *e);      /* flush a pending "n" as ん */
const char *editor_mode_name(const Editor *e);

#endif
