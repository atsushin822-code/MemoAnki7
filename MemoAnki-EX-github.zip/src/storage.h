#ifndef MEMOANKI_STORAGE_H
#define MEMOANKI_STORAGE_H

typedef enum {
    STORAGE_UNTOUCHED = 0,
    STORAGE_LOADED,        /* existing data file read OK */
    STORAGE_NEW,           /* no usable file: sample deck created */
    STORAGE_SAVED,         /* last save succeeded */
    STORAGE_SAVE_FAILED    /* last save failed (data kept in RAM only) */
} StorageStatus;

void storage_init(void);          /* load data, or seed the sample deck */
int  storage_save(void);          /* write everything now; 0 = ok */
void storage_flush(void);         /* save if there are unsaved changes */
void storage_note_change(void);   /* mark data dirty */
void storage_autosave(void);      /* save when enough changes piled up */
void storage_reset(void);         /* wipe everything, re-seed sample deck, save */
/* Files that can be imported: any *.CSV and IMPORT*.DAT in the data folders. */
#define IMPORT_MAX_FILES 24
#define IMPORT_NAME_MAX  32
typedef struct { int n; char name[IMPORT_MAX_FILES][IMPORT_NAME_MAX]; } ImportList;
void storage_list_imports(ImportList *list);

/* Import a deck from a MemoAnki import file (made by the converter tools, "MIM1").
   Returns the number of cards imported, -1 if the file is missing, -2 if it is invalid or does not fit. */
int  storage_import_dat(const char *file);
/* Import a deck from a UTF-8 CSV (Front,Back,Example) into a new deck called deck_name.
   Returns the number of cards, -1 if missing, -2 if empty / invalid / does not fit,
   -3 if the file is not UTF-8 (e.g. Shift_JIS from Excel). */
int  storage_import_csv(const char *file, const char *deck_name);

StorageStatus storage_status(void);
const char *storage_status_text(void);

#endif
