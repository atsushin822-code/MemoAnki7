#ifndef MEMOANKI_TEXTUTIL_H
#define MEMOANKI_TEXTUTIL_H

/*
 * UTF-8 text helpers. One code point = one screen cell (8 px): ASCII uses the
 * device's 8x12 font, Japanese the 8x8 Misaki font, so layout can count characters.
 */
#define WRAP_W      60                 /* default wrap width in cells */
#define WRAP_BYTES  (3 * 66 + 1)       /* worst case bytes of one line (3 bytes/char, 66 cells) */
typedef char WrapLine[WRAP_BYTES];

/* Decode the next code point and advance *p (always by >= 1 byte). Invalid/4-byte -> 0xFFFD. Returns 0 at NUL. */
unsigned int text_next(const char **p);
/* Append a code point as UTF-8; returns 1 if it fitted (NUL kept). */
int  text_append(char *buf, unsigned int max, unsigned int cp);
unsigned int text_cells(const char *s);

/* Bounded copy; always NUL-terminates and never cuts a multi-byte character. max includes the NUL. */
void text_copy(char *dst, const char *src, unsigned int max);
/* Like text_copy but also limited to max_cells characters. */
void text_copy_cells(char *dst, const char *src, unsigned int max_cells, unsigned int dstsize);
/* Copy as valid UTF-8 with control characters turned into spaces (invalid bytes -> '?'). */
void text_sanitize(char *dst, const char *src, unsigned int max);

/* Find where the next display line ends. s has n bytes. Returns bytes consumed (>= 1 unless n == 0);
   *visible = bytes to show. Breaks at '\n', at spaces, or hard at `width` cells. */
unsigned int text_next_line(const char *s, unsigned int n, unsigned int width, unsigned int *visible);
/* Wrap into at most max_lines lines of `width` cells. Returns the number of lines. */
int  text_wrap(const char *src, WrapLine *lines, int max_lines, unsigned int width);

/* Case-insensitive (ASCII) substring test. Empty needle matches. */
int  text_contains_ci(const char *hay, const char *needle);
char text_lower(char c);

/* Search key: ASCII lower-cased, katakana folded to hiragana. */
void text_make_key(char *dst, const char *src, unsigned int max);

#endif
