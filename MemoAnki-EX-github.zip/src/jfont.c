#include "jfont.h"

const unsigned char *jfont_glyph(unsigned int cp) {
    unsigned int lo = 0, hi = jfont_count;
    if (cp < 0x80 || cp > 0xFFFF) return 0;
    while (lo < hi) {
        unsigned int mid = (lo + hi) >> 1;
        unsigned int v = jfont_cp[mid];
        if (v == cp) return jfont_bits[mid];
        if (v < cp) lo = mid + 1; else hi = mid;
    }
    return 0;
}
