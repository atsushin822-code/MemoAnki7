#include "wikipedia.h"
#include "platform.h"
#include <string.h>

#define HDR_SIZE   32
#define ENTRY_SIZE 96
#define WIKI_FILE  "WIKI.DAT"

static int fh = -1;
static unsigned long n_entries = 0, index_off = 0, data_off = 0;

static unsigned long be32(const unsigned char *p) {
    return ((unsigned long)p[0] << 24) | ((unsigned long)p[1] << 16) | ((unsigned long)p[2] << 8) | p[3];
}

void wikipedia_init(void) { fh = -1; n_entries = 0; }

void wikipedia_close(void) {
    if (fh >= 0) platform_file_close(fh);
    fh = -1;
}

int wikipedia_available(void) {
    unsigned char h[HDR_SIZE];
    if (fh >= 0) return 1;
    fh = platform_file_open(WIKI_FILE, 0);
    if (fh < 0) return 0;
    platform_file_seek(fh, 0);
    if (platform_file_read(fh, h, HDR_SIZE) != HDR_SIZE || memcmp(h, "MWK1", 4) != 0) { wikipedia_close(); return 0; }
    n_entries = be32(h + 4);
    index_off = be32(h + 8);
    data_off = be32(h + 12);
    if (n_entries == 0) { wikipedia_close(); return 0; }
    return 1;
}

unsigned long wikipedia_count(void) { return fh >= 0 ? n_entries : 0; }

int wikipedia_entry(unsigned long index, WikiEntry *e) {
    unsigned char b[ENTRY_SIZE];
    if (fh < 0 || index >= n_entries) return -1;
    platform_file_seek(fh, index_off + index * ENTRY_SIZE);
    if (platform_file_read(fh, b, ENTRY_SIZE) != ENTRY_SIZE) return -1;
    memcpy(e->key, b, WIKI_KEY_MAX);            e->key[WIKI_KEY_MAX - 1] = 0;
    memcpy(e->title, b + 32, WIKI_TITLE_MAX);   e->title[WIKI_TITLE_MAX - 1] = 0;
    e->off = be32(b + 80);
    e->len = be32(b + 84);
    return 0;
}

int wikipedia_key_matches(const WikiEntry *e, const char *prefix) {
    unsigned int i;
    for (i = 0; prefix[i]; ++i) if (e->key[i] != prefix[i]) return 0;
    return 1;
}

unsigned long wikipedia_lower_bound(const char *prefix) {
    unsigned long lo = 0, hi = wikipedia_count();
    unsigned int m = (unsigned int)strlen(prefix), i;
    while (lo < hi) {
        unsigned long mid = lo + ((hi - lo) >> 1);
        WikiEntry e;
        int cmp = 0;
        if (wikipedia_entry(mid, &e) != 0) return lo;
        for (i = 0; i < m; ++i) {
            unsigned char a = (unsigned char)e.key[i], c = (unsigned char)prefix[i];
            if (a != c) { cmp = a < c ? -1 : 1; break; }
            if (!a) break;
        }
        if (cmp < 0) lo = mid + 1; else hi = mid;
    }
    return lo;
}

long wikipedia_read_text(const WikiEntry *e, char *buf, unsigned long max) {
    unsigned long n = e->len < max ? e->len : max;
    int r;
    if (fh < 0) return -1;
    platform_file_seek(fh, data_off + e->off);
    r = platform_file_read(fh, buf, (int)n);
    return r < 0 ? -1 : r;
}
