#ifndef MEMOANKI_DICTIONARY_H
#define MEMOANKI_DICTIONARY_H

#include "card.h"

#define DICT_MAX_RESULTS 64

void dictionary_init(void);
/* Case-insensitive search over the front/back text of every card in every deck.
   Returns the number of hits (0 for an empty query). */
int dictionary_search(const char *query);
int dictionary_count(void);
const Card *dictionary_result(int index);

#endif
