#ifndef MEMOANKI_STATS_H
#define MEMOANKI_STATS_H

typedef struct {
    unsigned int reviews;          /* all-time */
    unsigned int correct;          /* all-time, rating >= 2 */
    unsigned int by_rating[5];     /* all-time count per rating 0..4 */
    unsigned int today;            /* day number of 'today_reviews' */
    unsigned int today_reviews;
} Stats;

void stats_init(void);
void stats_record_review(int rating);
unsigned int stats_reviews(void);
unsigned int stats_correct(void);
unsigned int stats_today_reviews(void);
const Stats *stats_get(void);
void stats_set(const Stats *s);

#endif
