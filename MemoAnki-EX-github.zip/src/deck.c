#include "deck.h"
#include "card.h"
#include "textutil.h"
#include <string.h>

static Deck decks[MAX_DECKS];
static int deck_total = 0;
static unsigned int next_id = 1;

void deck_init(void) { deck_total = 0; next_id = 1; }

unsigned int deck_next_id(void) { return next_id; }
void deck_set_next_id(unsigned int v) { next_id = v ? v : 1; }

int deck_load_add(const Deck *d) {
    if (deck_total >= MAX_DECKS) return -1;
    memcpy(&decks[deck_total], d, sizeof(Deck));
    decks[deck_total].name[DECK_NAME_MAX - 1] = 0;
    return deck_total++;
}

int deck_create(const char *name) {
    if (!name || !*name || deck_total >= MAX_DECKS) return -1;
    decks[deck_total].id = next_id++;
    text_copy(decks[deck_total].name, name, DECK_NAME_MAX);
    decks[deck_total].card_count = 0;
    return deck_total++;
}

int deck_rename(int index, const char *name) {
    if (index < 0 || index >= deck_total || !name || !*name) return -1;
    text_copy(decks[index].name, name, DECK_NAME_MAX);
    return 0;
}

int deck_delete(int index) {
    int i;
    if (index < 0 || index >= deck_total) return -1;
    card_remove_deck(decks[index].id);
    for (i = index; i + 1 < deck_total; ++i) memcpy(&decks[i], &decks[i + 1], sizeof(Deck));
    --deck_total;
    return 0;
}

int deck_copy(int index, const char *new_name) {
    int n;
    unsigned int src;
    if (index < 0 || index >= deck_total) return -1;
    src = decks[index].id;
    if ((int)card_count_in_deck(src) + card_total() > card_capacity()) return -1;   /* would not fit */
    n = deck_create(new_name);
    if (n < 0) return -1;
    card_copy_deck(src, decks[n].id);
    decks[n].card_count = card_count_in_deck(decks[n].id);
    return n;
}

const Deck *deck_get(int index) {
    if (index < 0 || index >= deck_total) return 0;
    return &decks[index];
}

unsigned int deck_id_at(int index) {
    return (index >= 0 && index < deck_total) ? decks[index].id : 0;
}

int deck_count(void) { return deck_total; }

void deck_recount(void) {
    int i;
    for (i = 0; i < deck_total; ++i) decks[i].card_count = card_count_in_deck(decks[i].id);
}
