/*
 * Files app (included by ui.c): lists *.TXT / *.HTM / *.CSV and opens them in
 *   - a text editor (TXT; typing appends at the end, UP/DOWN scroll, F5 save),
 *   - an offline HTML browser (HTM; tags stripped, local links followed with F2),
 *   - a spreadsheet (CSV; SUM/AVG formulas, +/- keys because the device has no digit keys).
 * Integer arithmetic only (no FPU / signed division on the device).
 */
#define FA_MAX    (24 * 1024)
#define FA_NAMES  24
#define FA_LINKS  12
#define FA_W      62

static char *fa_buf;
static unsigned int fa_cap;
static char fa_names[FA_NAMES][IMPORT_NAME_MAX];
static int fa_n;
static char fa_link[FA_LINKS][IMPORT_NAME_MAX];
static int fa_nlink;

static void fa_collect(const char *name, void *ctx) {
    (void)ctx;
    if (fa_n < FA_NAMES && strlen(name) < IMPORT_NAME_MAX) text_copy(fa_names[fa_n++], name, IMPORT_NAME_MAX);
}

static int fa_init(void) {
    if (!fa_buf) {
        fa_cap = FA_MAX;
        fa_buf = (char *)platform_alloc(fa_cap);
        if (!fa_buf) { fa_cap = 1024; fa_buf = (char *)platform_alloc(fa_cap); }
    }
    return fa_buf != 0;
}

static int fa_load(const char *name) {
    int h = platform_file_open(name, 0), n, tot = 0;
    if (h < 0) return -1;
    while (tot < (int)fa_cap - 1 && (n = platform_file_read(h, fa_buf + tot, (int)fa_cap - 1 - tot)) > 0) tot += n;
    platform_file_close(h);
    fa_buf[tot] = 0;
    return tot;
}

static int fa_save(const char *name, const char *data, unsigned int len) {
    int h = platform_file_open(name, 1), ok;
    if (h < 0) return -1;
    ok = platform_file_write(h, data, (int)len) == (int)len;
    platform_file_close(h);
    return ok ? 0 : -1;
}

static int fa_kind(const char *n) {
    int l = (int)strlen(n);
    if (l >= 4 && !strcasecmp(n + l - 4, ".htm")) return 'h';
    if (l >= 4 && !strcasecmp(n + l - 4, ".csv")) return 'c';
    return 't';
}

static const char *fa_find(const char *h, const char *n) {
    unsigned int l = (unsigned int)strlen(n);
    for (; *h; ++h) if (!memcmp(h, n, l)) return h;
    return 0;
}

static int fa_scroll(int k, int top, int total) {
    if (k == K_UP && top > 0) --top;
    if (k == K_DOWN && top + 1 < total) ++top;
    if (k == K_PGUP) top = top > LIST_ROWS ? top - LIST_ROWS : 0;
    if (k == K_PGDN && top + LIST_ROWS < total) top += LIST_ROWS;
    return top;
}

/* Draw wrapped lines [top, top+LIST_ROWS) of s. Returns the line count; er and ec = line index and cell
   column where the text ends (the cursor position). Pass a huge top to only measure. */
static int fa_lines(const char *s, int top, int *er, int *ec) {
    static char raw[3 * 66 + 1];
    unsigned int n = (unsigned int)strlen(s), off = 0, vis, used;
    int nl = 0, lastc = 0;
    while (off < n) {
        used = text_next_line(s + off, n - off, FA_W, &vis);
        if (vis > sizeof raw - 1) vis = sizeof raw - 1;
        memcpy(raw, s + off, vis); raw[vis] = 0;
        lastc = (int)text_cells(raw);
        if (nl >= top && nl < top + LIST_ROWS) { text_sanitize(line, raw, sizeof line); put(2, LIST_ROW0 + nl - top, line, C_FG); }
        off += used ? used : 1;
        ++nl;
    }
    if (n == 0 || s[n - 1] == '\n') { *er = nl; *ec = 0; } else { *er = nl - 1; *ec = lastc; }
    return nl;
}

/* ---- text editor ---------------------------------------------------- */
static void fa_text(const char *name) {
    Editor ed;
    int top = 0, follow = 1, dirty = 0, k, nl, er, ec;
    unsigned int len0;
    if (fa_load(name) < 0) fa_buf[0] = 0;
    editor_init(&ed, fa_buf, fa_cap);
    for (;;) {
        frame("Text editor", "F5:Save F1:Mode ENTER:Newline UP/DN:Scroll BACK:Close");
        nl = fa_lines(fa_buf, 1 << 20, &er, &ec);
        if (follow) top = er >= LIST_ROWS ? er - LIST_ROWS + 1 : 0;
        (void)nl;
        fa_lines(fa_buf, top, &er, &ec);
        if (er >= top && er < top + LIST_ROWS) {
            put(2 + ec, LIST_ROW0 + er - top, ed.pend, C_ACCENT);
            put(2 + ec + (int)strlen(ed.pend), LIST_ROW0 + er - top, "_", C_ACCENT);
        }
        sprintf(line, "%s  [%s]  %u/%u bytes%s", name, editor_mode_name(&ed), (unsigned int)strlen(fa_buf), fa_cap - 1, dirty ? "  *" : "");
        put(2, MSG_ROW, line, C_DIM);
        platform_present();

        k = get_key();
        if (k == K_BACK) {
            editor_commit(&ed);
            if (dirty && confirm("Text editor", "Save changes?", name)) fa_save(name, fa_buf, (unsigned int)strlen(fa_buf));
            return;
        }
        if (k == K_F5) {
            editor_commit(&ed);
            if (fa_save(name, fa_buf, (unsigned int)strlen(fa_buf)) == 0) dirty = 0; else message("Text editor", "Save failed.", name);
            continue;
        }
        if (k == K_UP || k == K_DOWN || k == K_PGUP || k == K_PGDN) { top = fa_scroll(k, top, er + 1); follow = 0; continue; }
        len0 = (unsigned int)strlen(fa_buf);
        if (k == K_ENTER) text_append(fa_buf, fa_cap, '\n'); else editor_key(&ed, k);
        if (strlen(fa_buf) != len0) { dirty = 1; follow = 1; }
    }
}

/* ---- offline HTML browser ------------------------------------------- */
/*
 * The HTML is converted once into a display stream (in place, in fa_buf): text with '\n' at line ends and
 * control codes  1 rgb(4 bytes of 6 bits) / 7 = colour, 2 / 3 = big on/off, 5 / 6 = centre on/off, 4 n = image n.
 * CSS subset: color, background(-color), font-size (big or normal), text-align:center, display:none;
 * selectors tag, .class, #id (last simple selector of a rule). Images are *.IMG files (tools/html_prepare.py).
 */
typedef struct { int fg, bg; signed char big, ctr, hide; char tag[8]; } FaStyle;   /* -1 = not set */
typedef struct { char kind; char name[15]; FaStyle s; } FaRule;
#define FA_RULES    32
#define FA_CSS_MAX  4096
#define FA_IMGS     8
#define FA_DEPTH    16
static FaRule fa_rule[FA_RULES];
static int fa_nrule, fa_bg;
static char *fa_css;
static char fa_img[FA_IMGS][IMPORT_NAME_MAX];
static int fa_nimg, fa_iw[FA_IMGS], fa_ih[FA_IMGS];
static char *fa_w;
static int fa_bol, fa_sp;
static FaStyle fa_cur;

static void fa_style_init(FaStyle *s) { s->fg = s->bg = -1; s->big = s->ctr = s->hide = -1; s->tag[0] = 0; }
static void fa_merge(FaStyle *d, const FaStyle *s) {
    if (s->fg >= 0) d->fg = s->fg;
    if (s->bg >= 0) d->bg = s->bg;
    if (s->big >= 0) d->big = s->big;
    if (s->ctr >= 0) d->ctr = s->ctr;
    if (s->hide >= 0) d->hide = s->hide;
}

static int fa_hex(char c) { return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1; }

static int fa_color(const char *s) {          /* 0xRRGGBB or -1 */
    static const struct { const char *n; int v; } nm[] = {
        {"black",0x000000},{"white",0xFFFFFF},{"red",0xFF0000},{"green",0x008000},{"blue",0x0000FF},{"yellow",0xFFFF00},
        {"gray",0x808080},{"grey",0x808080},{"orange",0xFFA500},{"purple",0x800080},{"navy",0x000080},{"silver",0xC0C0C0},
        {"maroon",0x800000},{"teal",0x008080},{"lime",0x00FF00},{"aqua",0x00FFFF},{"fuchsia",0xFF00FF},{"olive",0x808000}
    };
    int i, j, n = 0, v = 0;
    while (*s == ' ') ++s;
    if (*s == '#') {
        for (++s; fa_hex(*s) >= 0; ++s, ++n) v = v * 16 + fa_hex(*s);
        if (n == 6) return v;
        if (n == 3) return (((v >> 8) & 15) * 17 << 16) | (((v >> 4) & 15) * 17 << 8) | ((v & 15) * 17);
        return -1;
    }
    for (i = 0; i < (int)(sizeof nm / sizeof nm[0]); ++i) {
        for (j = 0; nm[i].n[j] && text_lower(s[j]) == nm[i].n[j]; ++j) {}
        if (!nm[i].n[j] && !((s[j] >= 'a' && s[j] <= 'z') || (s[j] >= 'A' && s[j] <= 'Z'))) return nm[i].v;
    }
    return -1;
}

static int fa_bigsize(const char *v) {        /* 1 when the font size is clearly larger than normal */
    int n = 0;
    if (!memcmp(v, "large", 5) || !memcmp(v, "x-large", 7) || !memcmp(v, "xx-large", 8)) return 1;
    if (*v < '0' || *v > '9') return 0;
    while (*v >= '0' && *v <= '9') n = n * 10 + (*v++ - '0');
    n *= 10;
    if (*v == '.') { ++v; if (*v >= '0' && *v <= '9') n += *v - '0'; while (*v >= '0' && *v <= '9') ++v; }
    if (!memcmp(v, "px", 2)) return n >= 240;
    if (!memcmp(v, "pt", 2)) return n >= 180;
    if (!memcmp(v, "em", 2) || !memcmp(v, "rem", 3)) return n >= 15;
    if (*v == '%') return n >= 1500;
    return 0;
}

static void fa_decl(const char *d, FaStyle *st) {      /* "color:red; font-size:2em" */
    while (*d) {
        char prop[20], val[24];
        int i = 0, j = 0, c;
        while (*d == ' ' || *d == ';') ++d;
        while (*d && *d != ':' && *d != ';' && i < 19) prop[i++] = text_lower(*d++);
        while (i && prop[i - 1] == ' ') --i;
        prop[i] = 0;
        if (*d != ':') { if (*d) ++d; continue; }
        for (++d; *d == ' '; ++d) {}
        while (*d && *d != ';' && j < 23) val[j++] = text_lower(*d++);
        val[j] = 0;
        if (!strcmp(prop, "color")) { c = fa_color(val); if (c >= 0) st->fg = c; }
        else if (!strcmp(prop, "background-color") || !strcmp(prop, "background")) { c = fa_color(val); if (c >= 0) st->bg = c; }
        else if (!strcmp(prop, "font-size")) st->big = (signed char)fa_bigsize(val);
        else if (!strcmp(prop, "text-align")) st->ctr = !memcmp(val, "center", 6);
        else if (!strcmp(prop, "display")) st->hide = !memcmp(val, "none", 4);
    }
}

static void fa_add_rule(char kind, const char *name, const FaStyle *s) {
    FaRule *r;
    int n = 0;
    if (fa_nrule >= FA_RULES || !*name) return;
    r = &fa_rule[fa_nrule++];
    r->kind = kind;
    while (n < 14 && ((name[n] >= 'a' && name[n] <= 'z') || (name[n] >= 'A' && name[n] <= 'Z') || (name[n] >= '0' && name[n] <= '9') || name[n] == '-' || name[n] == '_')) { r->name[n] = kind == 't' ? text_lower(name[n]) : name[n]; ++n; }
    r->name[n] = 0;
    memcpy(&r->s, s, sizeof(FaStyle));
}

static void fa_parse_css(char *css) {
    char *p = css, *q;
    for (q = css; *q; ++q)                              /* blank out comments */
        if (q[0] == '/' && q[1] == '*') {
            while (*q && !(q[0] == '*' && q[1] == '/')) *q++ = ' ';
            if (*q) { q[0] = q[1] = ' '; ++q; }
            if (!*q) break;
        }
    for (q = css; *q; ++q) if ((unsigned char)*q < 32) *q = ' ';
    while (*p) {
        char *ob = strchr(p, '{'), *cb, *s;
        FaStyle st;
        if (!ob || !(cb = strchr(ob, '}'))) break;
        *ob = 0; *cb = 0;
        fa_style_init(&st);
        fa_decl(ob + 1, &st);
        for (s = p; s;) {
            char *comma = strchr(s, ','), *e, *t, *dot, *hash;
            if (comma) *comma = 0;
            e = s + strlen(s);
            while (e > s && e[-1] == ' ') --e;
            *e = 0;
            t = e;
            while (t > s && t[-1] != ' ' && t[-1] != '>') --t;
            if (*t && !strchr(t, ':') && !strchr(p, '@') && *t != '*') {
                dot = strchr(t, '.'); hash = strchr(t, '#');
                if (dot) fa_add_rule('.', dot + 1, &st);
                else if (hash) fa_add_rule('#', hash + 1, &st);
                else fa_add_rule('t', t, &st);
            }
            s = comma ? comma + 1 : 0;
        }
        p = cb + 1;
    }
}

static int fa_hasword(const char *list, const char *w) {
    unsigned int l = (unsigned int)strlen(w);
    while (*list) {
        const char *e;
        while (*list == ' ') ++list;
        for (e = list; *e && *e != ' '; ++e) {}
        if ((unsigned int)(e - list) == l && !memcmp(list, w, l)) return 1;
        list = e;
    }
    return 0;
}

static int fa_attr(const char *tagtext, const char *name, char *out, int max) {
    char key[16];
    const char *h;
    char q;
    int n = 0;
    sprintf(key, " %s=", name);
    h = fa_find(tagtext, key);
    if (!h) return 0;
    h += strlen(key);
    q = (*h == '"' || *h == '\'') ? *h++ : ' ';
    while (*h && *h != q && n < max - 1) out[n++] = *h++;
    out[n] = 0;
    return 1;
}

static void fa_style_for(FaStyle *st, const char *tag, const char *cls, const char *id, const char *inl) {
    int pass, i;
    FaStyle in;
    for (pass = 0; pass < 3; ++pass)
        for (i = 0; i < fa_nrule; ++i) {
            const FaRule *r = &fa_rule[i];
            if (pass == 0 ? (r->kind == 't' && !strcmp(r->name, tag))
                : pass == 1 ? (r->kind == '.' && fa_hasword(cls, r->name))
                : (r->kind == '#' && id[0] && !strcmp(r->name, id)))
                fa_merge(st, &r->s);
        }
    if (inl[0]) { fa_style_init(&in); fa_decl(inl, &in); fa_merge(st, &in); }
}

static void fa_emit(const FaStyle *s) {
    if (s->fg != fa_cur.fg) {
        if (s->fg < 0) *fa_w++ = 7;
        else { *fa_w++ = 1; *fa_w++ = (char)(0x40 | ((s->fg >> 18) & 63)); *fa_w++ = (char)(0x40 | ((s->fg >> 12) & 63)); *fa_w++ = (char)(0x40 | ((s->fg >> 6) & 63)); *fa_w++ = (char)(0x40 | (s->fg & 63)); }
        fa_cur.fg = s->fg;
    }
    if (s->big != fa_cur.big) { *fa_w++ = s->big > 0 ? 2 : 3; fa_cur.big = s->big; }
    if (s->ctr != fa_cur.ctr) { *fa_w++ = s->ctr > 0 ? 5 : 6; fa_cur.ctr = s->ctr; }
}

static void fa_nl(int force) {
    if (fa_bol && !force) return;
    if (fa_bol) *fa_w++ = ' ';
    *fa_w++ = '\n';
    fa_bol = 1; fa_sp = 0;
}

static void fa_ch(char c) {
    if ((unsigned char)c < 32) c = ' ';
    if (c == ' ') { if (!fa_bol && !fa_sp) { *fa_w++ = ' '; fa_sp = 1; } }
    else { *fa_w++ = c; fa_bol = 0; fa_sp = 0; }
}

static int fa_isblock(const char *t) {
    static const char *const b[] = { "br", "p", "li", "tr", "div", "ul", "ol", "table", "blockquote", "pre", "section", "article",
                                     "header", "footer", "body", "center", "dl", "dt", "dd", "form", "h1", "h2", "h3", "h4", "h5", "h6" };
    int i;
    if (*t == '/') ++t;
    for (i = 0; i < (int)(sizeof b / sizeof b[0]); ++i) if (!strcmp(t, b[i])) return 1;
    return 0;
}

static int fa_read(const char *name, char *buf, int cap) {
    int h = platform_file_open(name, 0), n, tot = 0;
    if (h < 0) return -1;
    while (tot < cap - 1 && (n = platform_file_read(h, buf + tot, cap - 1 - tot)) > 0) tot += n;
    platform_file_close(h);
    buf[tot] = 0;
    return tot;
}

static void fa_basename(char *dst, const char *src, int to_img) {     /* last path part; optionally extension -> .IMG */
    const char *b = src, *s;
    int n = 0;
    for (s = src; *s && *s != '"' && *s != '#'; ++s) if (*s == '/' || *s == '\\') b = s + 1;
    while (b < s && n < IMPORT_NAME_MAX - 5 && !(to_img && (*b == '.' || n >= 8))) dst[n++] = *b++;
    if (to_img) { dst[n++] = '.'; dst[n++] = 'I'; dst[n++] = 'M'; dst[n++] = 'G'; }
    else while (b < s && n < IMPORT_NAME_MAX - 1) dst[n++] = *b++;
    dst[n] = 0;
}

static void fa_load_css(const char *href) {
    char nm[IMPORT_NAME_MAX], *u;
    if (!fa_css) fa_css = (char *)platform_alloc(FA_CSS_MAX);
    if (!fa_css || (href[0] == 'h' && href[1] == 't')) return;
    fa_basename(nm, href, 0);
    if (fa_read(nm, fa_css, FA_CSS_MAX) < 0) {
        for (u = nm; *u; ++u) if (*u >= 'a' && *u <= 'z') *u -= 32;
        if (fa_read(nm, fa_css, FA_CSS_MAX) < 0) return;
    }
    fa_parse_css(fa_css);
}

static void fa_convert(int len) {
    static char ua[] = "a{color:#0000cc} h1{font-size:2em} h2{font-size:1.6em} center{text-align:center} title{display:none}";
    FaStyle stk[FA_DEPTH];
    char *r, *e, *sstart = 0;
    int sp = 1, skip = 0, i;
    if (len > (int)(fa_cap / 3 * 2)) { len = (int)(fa_cap / 3 * 2); fa_buf[len] = 0; }
    r = fa_buf + fa_cap - 1 - len;                      /* read from the tail, write from the head */
    memmove(r, fa_buf, (unsigned int)len + 1);
    fa_w = fa_buf; fa_bol = 1; fa_sp = 0;
    fa_nlink = fa_nimg = fa_nrule = 0;
    memset(fa_iw, 0, sizeof fa_iw); memset(fa_ih, 0, sizeof fa_ih);
    fa_bg = 0xFFFFFF;
    fa_style_init(&stk[0]); stk[0].fg = -1; stk[0].big = stk[0].ctr = stk[0].hide = 0;
    memcpy(&fa_cur, &stk[0], sizeof(FaStyle));
    fa_parse_css(ua);
    while (*r && fa_w + 40 < r) {
        char ch;
        if (r[0] == '<' && r[1] == '!' && r[2] == '-' && r[3] == '-') {
            const char *c = fa_find(r + 4, "-->");
            if (!c) break;
            r = (char *)c + 3;
            continue;
        }
        if (*r == '<' && (e = strchr(r, '>')) != 0) {
            char tag[10], cls[24], id[16], inl[64], val[40], *c;
            const char *t = r + 1;
            int k = 0, closing;
            for (c = r; c < e; ++c) if ((unsigned char)*c < 32) *c = ' ';
            if (*t == '/') tag[k++] = *t++;
            while (t < e && k < 9 && *t != ' ' && *t != '/') tag[k++] = text_lower(*t++);
            tag[k] = 0;
            closing = tag[0] == '/';
            *e = 0;
            if (!strcmp(tag, "script") || !strcmp(tag, "style")) { skip = 1; sstart = e + 1; }
            else if (!strcmp(tag, "/script")) skip = 0;
            else if (!strcmp(tag, "/style")) { char sv = *r; *r = 0; if (sstart) fa_parse_css(sstart); *r = sv; skip = 0; }
            else if (!skip && closing) {
                for (i = sp - 1; i > 0; --i) if (!strcmp(stk[i].tag, tag + 1)) break;
                if (i > 0) sp = i;
                if (fa_isblock(tag)) fa_nl(0);
                fa_emit(&stk[sp - 1]);
            } else if (!skip && tag[0] != '!') {
                FaStyle st; memcpy(&st, &stk[sp - 1], sizeof(FaStyle));
                int isvoid = !strcmp(tag, "br") || !strcmp(tag, "img") || !strcmp(tag, "hr") || !strcmp(tag, "meta") || !strcmp(tag, "link") || !strcmp(tag, "input");
                cls[0] = id[0] = inl[0] = 0;
                st.bg = -1;
                fa_attr(r, "class", cls, sizeof cls);
                fa_attr(r, "id", id, sizeof id);
                fa_attr(r, "style", inl, sizeof inl);
                if (!strcmp(tag, "font") && fa_attr(r, "color", val, sizeof val)) sprintf(inl, "color:%s", val);
                if (!strcmp(tag, "body") && fa_attr(r, "bgcolor", val, sizeof val)) sprintf(inl, "background-color:%s", val);
                fa_style_for(&st, tag, cls, id, inl);
                if (st.bg >= 0 && (!strcmp(tag, "body") || !strcmp(tag, "html"))) fa_bg = st.bg;
                if (!strcmp(tag, "link") && fa_attr(r, "href", val, sizeof val)) fa_load_css(val);
                if (!strcmp(tag, "a") && fa_nlink < FA_LINKS && fa_attr(r, "href", val, sizeof val) && !(val[0] == 'h' && val[1] == 't')) {
                    fa_basename(fa_link[fa_nlink], val, 0);
                    if (fa_link[fa_nlink][0]) ++fa_nlink;
                }
                if (!isvoid && sp < FA_DEPTH) { st.tag[0] = 0; for (k = 0; tag[k] && k < 7; ++k) st.tag[k] = tag[k]; st.tag[k] = 0; memcpy(&stk[sp], &st, sizeof(FaStyle)); ++sp; }
                if (fa_isblock(tag)) fa_nl(!strcmp(tag, "br"));
                fa_emit(&st);
                if (!st.hide) {
                    if (!strcmp(tag, "li")) { fa_ch('-'); fa_ch(' '); }
                    else if (!strcmp(tag, "hr")) { for (k = 0; k < 40; ++k) fa_ch('-'); fa_nl(0); }
                    else if (!strcmp(tag, "img") && fa_nimg < FA_IMGS && fa_attr(r, "src", val, sizeof val) && !(val[0] == 'h' && val[1] == 't') && memcmp(val, "data:", 5)) {
                        fa_basename(fa_img[fa_nimg], val, 1);
                        fa_nl(0);
                        *fa_w++ = 4; *fa_w++ = (char)(0x40 | fa_nimg++); *fa_w++ = '\n';
                        fa_bol = 1; fa_sp = 0;
                    }
                }
            }
            *e = '>';
            r = e + 1;
            continue;
        }
        if (!skip && !stk[sp - 1].hide) {
            ch = *r;
            if (ch == '&') {
                if (!memcmp(r, "&amp;", 5)) { ch = '&'; r += 4; }
                else if (!memcmp(r, "&lt;", 4)) { ch = '<'; r += 3; }
                else if (!memcmp(r, "&gt;", 4)) { ch = '>'; r += 3; }
                else if (!memcmp(r, "&nbsp;", 6)) { ch = ' '; r += 5; }
                else if (!memcmp(r, "&quot;", 6)) { ch = '"'; r += 5; }
            }
            fa_ch(ch);
        }
        ++r;
    }
    *fa_w = 0;
}

static int fa_pick_link(void) {
    int sel = 0, k, i;
    for (;;) {
        frame("Links", "UP/DOWN:Select ENTER:Open BACK:Cancel");
        for (i = 0; i < fa_nlink; ++i) list_row(LIST_ROW0 + i, fa_link[i], i == sel);
        platform_present();
        k = get_key();
        if (k == K_BACK) return -1;
        if (k == K_ENTER) return sel;
        sel = move_sel(k, sel, fa_nlink, 1);
    }
}

/* Image header: "IMG1", u16 w, u16 h (big-endian), 256 x RGB565 palette, w*h palette indices. */
#define FA_IMG_DATA 520
static int fa_imgopen(int idx) {
    int h = platform_file_open(fa_img[idx], 0);
    if (h < 0) {
        char *u;
        for (u = fa_img[idx]; *u; ++u) if (*u >= 'a' && *u <= 'z') *u -= 32;
        h = platform_file_open(fa_img[idx], 0);
    }
    return h;
}

static void fa_imgdim(int idx) {
    unsigned char hd[8];
    int h = fa_imgopen(idx);
    fa_ih[idx] = -1;
    if (h < 0) return;
    if (platform_file_read(h, hd, 8) == 8 && !memcmp(hd, "IMG1", 4)) {
        fa_iw[idx] = hd[4] << 8 | hd[5];
        fa_ih[idx] = hd[6] << 8 | hd[7];
        if (fa_iw[idx] < 1 || fa_iw[idx] > SCREEN_W || fa_ih[idx] < 1 || fa_ih[idx] > 2000) fa_ih[idx] = -1;
    }
    platform_file_close(h);
}

static void fa_draw_image(int idx, int vrow, int top, int ctr) {
    static unsigned char pl[512], row[SCREEN_W];
    int h = fa_imgopen(idx), w = fa_iw[idx], ht = fa_ih[idx], y, x, e, last = -1;
    int x0 = ctr ? (SCREEN_W - w) / 2 : FONT_W;
    int ybase = (LIST_ROW0 + vrow - top) * FONT_H + Y_OFF, ymin = LIST_ROW0 * FONT_H + Y_OFF, ymax = ymin + LIST_ROWS * FONT_H;
    if (h < 0) return;
    platform_file_seek(h, 8);
    if (platform_file_read(h, pl, 512) != 512) { platform_file_close(h); return; }
    for (y = 0; y < ht; ++y) {
        if (ybase + y < ymin || ybase + y >= ymax) continue;
        platform_file_seek(h, (unsigned long)(FA_IMG_DATA + y * w));
        if (platform_file_read(h, row, w) != w) break;
        for (x = 0; x < w; x = e) {
            int i = row[x];
            for (e = x + 1; e < w && row[e] == i; ++e) {}
            if (i != last) {
                int v = pl[2 * i] << 8 | pl[2 * i + 1], rr = (v >> 11) & 31, gg = (v >> 5) & 63, bb = v & 31;
                platform_set_color(C_USER2, ((rr << 3 | rr >> 2) << 16) | ((gg << 2 | gg >> 4) << 8) | (bb << 3 | bb >> 2));
                last = i;
            }
            platform_rect(x0 + x, ybase + y, e - x, 1, C_USER2);
        }
    }
    platform_file_close(h);
}

/* Lay out (and draw rows [top, top+LIST_ROWS) when draw != 0) the converted page. Returns the number of rows. */
static int fa_render(int top, int draw) {
    const unsigned char *p = (const unsigned char *)fa_buf;
    int vrow = 0, fg = -1, big = 0, ctr = 0, shown = -2;
    int dark = ((fa_bg >> 8) & 255) < 110;
    for (;;) {
        const unsigned char *q;
        int w = 0, lh, scale, width, col, any = 0;
        for (;;) {                                        /* leading style codes */
            if (*p == 1) { fg = ((p[1] & 63) << 18) | ((p[2] & 63) << 12) | ((p[3] & 63) << 6) | (p[4] & 63); p += 5; }
            else if (*p == 7) { fg = -1; ++p; }
            else if (*p == 2) { big = 1; ++p; }
            else if (*p == 3) { big = 0; ++p; }
            else if (*p == 5) { ctr = 1; ++p; }
            else if (*p == 6) { ctr = 0; ++p; }
            else break;
        }
        if (!*p) break;
        if (*p == 4) {                                    /* image line */
            int idx = p[1] - 0x40, rows = 1;
            p += 2;
            if (*p == '\n') ++p;
            if (idx < 0 || idx >= FA_IMGS) continue;
            if (!fa_ih[idx]) fa_imgdim(idx);
            if (fa_ih[idx] > 0) {
                rows = (fa_ih[idx] + FONT_H - 1) / FONT_H;
                if (draw && vrow >= top && vrow + rows <= top + LIST_ROWS + rows - 1 && vrow < top + LIST_ROWS) fa_draw_image(idx, vrow, top, ctr);
            } else if (draw && vrow >= top && vrow < top + LIST_ROWS) {
                sprintf(line, "[image: %s]", fa_img[idx]);
                platform_set_color(C_USER1, dark ? 0xFFFFFF : 0x000000);
                platform_text(2, LIST_ROW0 + vrow - top, line, C_USER1);
                shown = -2;
            }
            vrow += rows;
            continue;
        }
        scale = big ? 2 : 1;
        lh = scale;
        width = FA_W / scale;
        for (q = p; *q && *q != '\n' && *q != 4; ) {      /* width of the line in cells */
            if (*q == 1) q += 5;
            else if (*q < 8) ++q;
            else { const char *n = (const char *)q; (void)text_next(&n); q = (const unsigned char *)n; ++w; }
        }
        col = (ctr && w <= width) ? (width - w) / 2 : 0;
        while (*p && *p != '\n' && *p != 4) {
            if (*p == 1) { fg = ((p[1] & 63) << 18) | ((p[2] & 63) << 12) | ((p[3] & 63) << 6) | (p[4] & 63); p += 5; continue; }
            if (*p == 7) { fg = -1; ++p; continue; }
            if (*p < 8) { ++p; continue; }
            {
                const char *s = (const char *)p, *n = s;
                char b[4];
                int len;
                (void)text_next(&n);
                len = (int)(n - s);
                if (col >= width) { vrow += lh; col = 0; }
                if (draw && vrow >= top && vrow + lh <= top + LIST_ROWS) {
                    int rgb = fg < 0 ? (dark ? 0xFFFFFF : 0x000000) : fg;
                    memcpy(b, s, (unsigned int)len); b[len] = 0;
                    if (rgb != shown) { platform_set_color(C_USER1, rgb); shown = rgb; }
                    if (big) platform_text_big(1 + col * 2, LIST_ROW0 + vrow - top, b, C_USER1);
                    else platform_text(1 + col, LIST_ROW0 + vrow - top, b, C_USER1);
                }
                ++col; any = 1; p = (const unsigned char *)n;
            }
        }
        if (*p == '\n') ++p;
        if (any) vrow += lh;
    }
    return vrow;
}

static void fa_browse(const char *start) {
    char st[6][IMPORT_NAME_MAX];
    int depth = 0, top = 0, k, nl = 0, loaded = 0;
    text_copy(st[0], start, IMPORT_NAME_MAX);
    for (;;) {
        if (!loaded) {
            int rc = fa_load(st[depth]);
            if (rc < 0 && depth > 0) {                      /* links may differ in case from the file name */
                char *u;
                for (u = st[depth]; *u; ++u) if (*u >= 'a' && *u <= 'z') *u -= 32;
                rc = fa_load(st[depth]);
            }
            if (rc < 0) {
                message("Browser (offline)", "Cannot open file:", st[depth]);
                if (depth == 0) return;
                --depth;
                continue;
            }
            fa_convert(rc);
            nl = fa_render(1 << 20, 0);
            top = 0;
            loaded = 1;
        }
        frame("Browser (offline)", "UP/DOWN:Scroll F2:Links BACK:Back/Close");
        platform_set_color(C_USER2, fa_bg);
        platform_rect(0, LIST_ROW0 * FONT_H + Y_OFF, SCREEN_W, LIST_ROWS * FONT_H, C_USER2);
        fa_render(top, 1);
        sprintf(line, "%s   row %d/%d   links: %d", st[depth], top + 1, nl, fa_nlink);
        put(2, MSG_ROW, line, C_DIM);
        platform_present();
        k = get_key();
        if (k == K_BACK) { if (depth == 0) return; --depth; loaded = 0; continue; }
        if (k == K_F2 && fa_nlink) {
            int i = fa_pick_link();
            if (i >= 0 && depth < 5) { text_copy(st[depth + 1], fa_link[i], IMPORT_NAME_MAX); ++depth; loaded = 0; }
            continue;
        }
        top = fa_scroll(k, top, nl);
    }
}

/* ---- spreadsheet ---------------------------------------------------- */
#define SS_R   60
#define SS_C   12
#define SS_W   20
#define SS_VC  5        /* visible columns */
#define SS_CW  11       /* column width in cells */
#define SS_VR  16       /* visible rows */
static char (*ss)[SS_C][SS_W];

static int ss_isnum(const char *s, long *v) {
    long x = 0;
    int neg = 0, any = 0;
    if (*s == '-') { neg = 1; ++s; }
    for (; *s >= '0' && *s <= '9'; ++s) { x = x * 10 + (*s - '0'); any = 1; }
    while (*s == ' ') ++s;
    if (!any || *s) return 0;
    *v = neg ? -x : x;
    return 1;
}

static int ss_ref(const char **p, int *r, int *c) {
    const char *s = *p;
    int n = 0;
    if (*s < 'A' || *s >= 'A' + SS_C) return 0;
    *c = *s++ - 'A';
    if (*s < '0' || *s > '9') return 0;
    while (*s >= '0' && *s <= '9') n = n * 10 + (*s++ - '0');
    if (n < 1 || n > SS_R) return 0;
    *r = n - 1;
    *p = s;
    return 1;
}

/* 1 if s is a number or a valid =SUM(A1:A5) / =AVG(A1:A5); the value goes to *v. */
static int ss_eval(const char *s, long *v) {
    static int depth;
    const char *p;
    int r1, c1, r2, c2, r, c, avg, cnt = 0;
    long sum = 0, x;
    if (ss_isnum(s, v)) return 1;
    if (s[0] != '=' || depth > 3) return 0;
    p = s + 1;
    if (!memcmp(p, "SUM(", 4)) avg = 0; else if (!memcmp(p, "AVG(", 4)) avg = 1; else return 0;
    p += 4;
    if (!ss_ref(&p, &r1, &c1) || *p++ != ':' || !ss_ref(&p, &r2, &c2)) return 0;
    ++depth;
    for (r = r1; r <= r2; ++r) for (c = c1; c <= c2; ++c) if (ss_eval(ss[r][c], &x)) { sum += x; ++cnt; }
    --depth;
    if (avg) {
        if (!cnt) return 0;
        sum = sum < 0 ? -(long)((unsigned int)(-sum) / (unsigned int)cnt) : (long)((unsigned int)sum / (unsigned int)cnt);
    }
    *v = sum;
    return 1;
}

static void ss_text(int r, int c, char *out, unsigned int max) {
    const char *s = ss[r][c];
    long v;
    if (s[0] == '=') { if (ss_eval(s, &v)) sprintf(out, "%d", (int)v); else text_copy(out, "#ERR", max); }
    else text_sanitize(out, s, max);
}

static void ss_parse(void) {
    const char *p = fa_buf;
    char d = ',';
    int r = 0, c = 0, q = 0;
    unsigned int n = 0;
    memset(ss, 0, SS_R * SS_C * SS_W);
    if ((unsigned char)p[0] == 0xEF && (unsigned char)p[1] == 0xBB && (unsigned char)p[2] == 0xBF) p += 3;
    {   /* delimiter: comma unless the first line only has tabs / semicolons */
        const char *s = p;
        int comma = 0, tab = 0, semi = 0;
        for (; *s && *s != '\n'; ++s) { if (*s == ',') comma = 1; if (*s == '\t') tab = 1; if (*s == ';') semi = 1; }
        if (!comma) d = tab ? '\t' : (semi ? ';' : ',');
    }
    for (; *p && r < SS_R; ++p) {
        char ch = *p, out = 0;
        if (q) {
            if (ch == '"') { if (p[1] == '"') { out = '"'; ++p; } else q = 0; }
            else out = ch == '\n' || ch == '\r' ? ' ' : ch;
        } else if (ch == '"') q = 1;
        else if (ch == d) { ++c; n = 0; }
        else if (ch == '\n') { ++r; c = 0; n = 0; }
        else if (ch != '\r') out = ch;
        if (out && c < SS_C && n < SS_W - 1) ss[r][c][n++] = out;
    }
}

static int ss_save(const char *name) {
    unsigned int n = 0;
    int r, c, mr = -1, mc = 0;
    for (r = 0; r < SS_R; ++r) for (c = 0; c < SS_C; ++c) if (ss[r][c][0]) { mr = r; if (c + 1 > mc) mc = c + 1; }
    for (r = 0; r <= mr; ++r) for (c = 0; c < mc; ++c) {
        const char *s = ss[r][c], *t;
        int q = 0;
        if (n + 2 * SS_W + 4 > fa_cap) return -1;
        for (t = s; *t; ++t) if (*t == ',' || *t == '"' || *t == '\n') q = 1;
        if (q) fa_buf[n++] = '"';
        for (t = s; *t; ++t) { if (*t == '"') fa_buf[n++] = '"'; fa_buf[n++] = *t; }
        if (q) fa_buf[n++] = '"';
        fa_buf[n++] = c + 1 < mc ? ',' : '\n';
    }
    return fa_save(name, fa_buf, n);
}

static void fa_sheet(const char *name) {
    int cr = 0, cc = 0, tr = 0, tc = 0, k, r, c, dirty = 0;
    if (!ss) {
        ss = (char (*)[SS_C][SS_W])platform_alloc(SS_R * SS_C * SS_W);
        if (!ss) { message("Sheet", "Not enough memory for the spreadsheet.", 0); return; }
    }
    if (fa_load(name) < 0) fa_buf[0] = 0;
    ss_parse();
    for (;;) {
        char cell[SS_W * 3], disp[SS_CW * 3 + 1], ref[16], hd[2];
        if (cc < tc) tc = cc;
        if (cc >= tc + SS_VC) tc = cc - SS_VC + 1;
        keep_visible(cr, &tr, SS_VR);
        frame("Sheet", "ENTER:Edit F1/F2:+-1 F3/F4:+-10 F5:Clear F6:Save F7:SUM F8:AVG");
        hd[1] = 0;
        for (c = 0; c < SS_VC && tc + c < SS_C; ++c) { hd[0] = (char)('A' + tc + c); put(5 + c * SS_CW + 4, 2, hd, C_ACCENT); }
        for (r = 0; r < SS_VR && tr + r < SS_R; ++r) {
            sprintf(line, "%d", tr + r + 1);
            put(1, 3 + r, line, C_DIM);
            for (c = 0; c < SS_VC && tc + c < SS_C; ++c) {
                int sel = (tr + r == cr && tc + c == cc);
                ss_text(tr + r, tc + c, cell, sizeof cell);
                fit(disp, cell, SS_CW - 1);
                if (sel) platform_cell_rect(5 + c * SS_CW, 3 + r, SS_CW - 1, 1, C_SEL_BG);
                put(5 + c * SS_CW, 3 + r, disp, sel ? C_SEL_FG : C_FG);
            }
        }
        ref[0] = (char)('A' + cc);
        sprintf(ref + 1, "%d", cr + 1);
        text_sanitize(cell, ss[cr][cc], sizeof cell);
        sprintf(line, "%s: %s%s", ref, cell, dirty ? "   *" : "");
        put(2, 20, line, C_ACCENT);
        put(2, MSG_ROW, name, C_DIM);
        platform_present();

        k = get_key();
        if (k == K_BACK) { if (dirty && confirm("Sheet", "Save changes?", name)) ss_save(name); return; }
        if (k == K_UP && cr > 0) --cr;
        if (k == K_DOWN && cr + 1 < SS_R) ++cr;
        if (k == K_LEFT && cc > 0) --cc;
        if (k == K_RIGHT && cc + 1 < SS_C) ++cc;
        if (k == K_PGUP) cr = cr > SS_VR ? cr - SS_VR : 0;
        if (k == K_PGDN) cr = cr + SS_VR < SS_R ? cr + SS_VR : SS_R - 1;
        if (k == K_ENTER) {
            char buf[SS_W], title[24];
            text_copy(buf, ss[cr][cc], SS_W);
            sprintf(title, "Cell %s", ref);
            if (text_input(title, "Value (F7/F8 on the sheet make SUM/AVG formulas)", buf, SS_W, 1)) { text_copy(ss[cr][cc], buf, SS_W); dirty = 1; }
        }
        if (k >= K_F1 && k <= K_F4) {
            int d = k == K_F1 ? 1 : k == K_F2 ? -1 : k == K_F3 ? 10 : -10;
            long v = 0;
            if (!ss[cr][cc][0] || ss_isnum(ss[cr][cc], &v)) { sprintf(ss[cr][cc], "%d", (int)(v + d)); dirty = 1; }
        }
        if (k == K_F5) { ss[cr][cc][0] = 0; dirty = 1; }
        if (k == K_F6) { if (ss_save(name) == 0) dirty = 0; else message("Sheet", "Save failed.", name); }
        if ((k == K_F7 || k == K_F8) && cr > 0) {
            int r0 = cr;
            long x;
            while (r0 > 0 && ss[r0 - 1][cc][0] && ss_eval(ss[r0 - 1][cc], &x)) --r0;
            if (r0 < cr) {
                char L[2];
                L[0] = (char)('A' + cc); L[1] = 0;
                sprintf(ss[cr][cc], "=%s(%s%d:%s%d)", k == K_F7 ? "SUM" : "AVG", L, r0 + 1, L, cr);
                dirty = 1;
            }
        }
    }
}

/* ---- file list ------------------------------------------------------ */
static void fa_open(const char *name) {
    int kind = fa_kind(name);
    if (kind == 'h') fa_browse(name); else if (kind == 'c') fa_sheet(name); else fa_text(name);
}

void ui_show_files(void) {
    int sel = 0, top = 0, k, i, reload = 1;
    if (!fa_init()) { message("Files", "Not enough memory.", 0); return; }
    for (;;) {
        if (reload) {
            fa_n = 0;
            platform_list_files("*.TXT", fa_collect, 0);
            platform_list_files("*.HTM", fa_collect, 0);
            platform_list_files("*.CSV", fa_collect, 0);
            for (i = 1; i < fa_n; ++i) {            /* insertion sort by name, ignoring case */
                char tmp[IMPORT_NAME_MAX];
                int j = i;
                text_copy(tmp, fa_names[i], IMPORT_NAME_MAX);
                while (j > 0 && strcasecmp(fa_names[j - 1], tmp) > 0) { text_copy(fa_names[j], fa_names[j - 1], IMPORT_NAME_MAX); --j; }
                text_copy(fa_names[j], tmp, IMPORT_NAME_MAX);
            }
            reload = 0;
        }
        if (sel >= fa_n) sel = fa_n ? fa_n - 1 : 0;
        keep_visible(sel, &top, LIST_ROWS);
        frame("Files", "ENTER:Open F1:New text F2:New sheet BACK:Home");
        if (!fa_n) put(2, 4, "No .TXT / .HTM / .CSV files in the app folder. Press F1 to create one.", C_DIM);
        for (i = top; i < fa_n && i < top + LIST_ROWS; ++i) {
            int kd = fa_kind(fa_names[i]);
            sprintf(line, "%s  %s", kd == 'h' ? "BROWSE" : kd == 'c' ? "SHEET " : "TEXT  ", fa_names[i]);
            list_row(LIST_ROW0 + i - top, line, i == sel);
        }
        platform_present();
        k = get_key();
        if (k == K_BACK) return;
        if (k == K_ENTER && fa_n) { fa_open(fa_names[sel]); reload = 1; continue; }
        if (k == K_F1 || k == K_F2) {
            char nm[16];
            nm[0] = 0;
            if (text_input("New file", "File name (letters only, no extension)", nm, 9, 0)) {
                strcat(nm, k == K_F1 ? ".TXT" : ".CSV");
                fa_open(nm);
                reload = 1;
            }
            continue;
        }
        sel = move_sel(k, sel, fa_n, 0);
    }
}
