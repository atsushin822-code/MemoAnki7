Sample articles for testing (sample.jsonl) are original short texts, NOT Wikipedia content.
Build WIKI.DAT:  python3 tools/wikipedia_prepare.py sample.jsonl -o data/device/WIKI.DAT
JSONL fields: title, text, optional reading (hiragana, used as the search key).
If you use real Wikipedia text, follow CC BY-SA (attribution).
