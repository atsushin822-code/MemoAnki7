Place generated compact dictionary data here.
Do not redistribute copyrighted dictionary contents without permission.
