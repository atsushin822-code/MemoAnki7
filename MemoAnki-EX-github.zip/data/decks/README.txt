Deck data directory.
Deck names are user-defined.
Example CSV columns: Front,Back,Example
