# Put your own WIKI.DAT / IMPORT*.DAT / *.CSV here; they are copied into build/*/MEMAN/.
# If absent, CI generates small samples.
