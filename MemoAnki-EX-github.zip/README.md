# MemoAnki EX

CASIO EX-word DATAPLUS 5 (XD-A8500) 向けの Anki 風学習アプリです。GitHub Actions でビルドし、`build/ja/MEMAN` を本体に導入して使います。

## ファイルの置き場所(SD カード対応)
アプリは次のフォルダをこの順に探し、保存(`MEMANKI.DAT`・新規テキスト/シート)も最初に書けたフォルダへ行います。
1. SD カードのルートに作った **`MEMANKI`** フォルダ(`\\crd0\MEMANKI\`)
2. SD カードの **`MEMAN`** フォルダ(`\\crd0\MEMAN\`)
3. アプリを導入した場所の `_USER\` と `MEMAN\`

CSV・TXT・HTM・`IMPORT*.DAT`・`WIKI.DAT` は、PC でカードを読んで **SD カードの `MEMANKI` フォルダ**に入れるのがおすすめです(アプリはフォルダを作れないので、`MEMANKI` フォルダは PC で作っておきます)。見えているかどうかは、アプリの **Settings → File check** で確認できます(探したフォルダと、見つかったファイルの名前・種類を一覧表示。↑↓/PAGE でスクロール、最大128件まで)。Import と Files の一覧も、それぞれ最大128ファイルまで表示します(メモリを確保できない機種では16件)。

## できること

- **日本語表示**: 内蔵の美咲フォント(8×8、JIS X 0208 の約7,000字)を `.d01` に埋め込み。カード・デッキ名・Wikipedia 本文に使えます。学習画面の表/裏は2倍サイズ。
- **CSV の直接取り込み**: UTF-8 の CSV を `IMPORT.CSV` という名前でアプリのフォルダに置き、Settings → Import で取り込めます(変換ツール不要)。
- **日本語入力**: ローマ字→ひらがな/カタカナ(F1 で abc/ABC/hira/kata を切替)。漢字変換は無いので、漢字入りのカードは `IMPORT.DAT` で取り込みます。
- **Wikipedia(オフライン)**: `WIKI.DAT` を検索(英字、またはローマ字でよみ)・閲覧(1x/2x 切替 F1)、記事から1キーでカード作成。
- Study / Review、評価 0〜4、デッキの作成・名前変更・コピー・削除・カード追加、辞書(全カード検索)、統計、設定(キーテスト・保存・リセット・デッキ取り込み)。
- 進捗の自動保存(`MEMANKI.DAT`)。

## 操作

| キー | 動作 |
|---|---|
| ↑↓ / PAGE UP/DOWN | 選択・スクロール |
| ENTER | 決定 / 答えを見る / 評価確定 |
| ←→ + ENTER、または F1〜F5 | 評価 0〜4 |
| BACK | 戻る(ホームで押すと終了) / POWER: 保存して終了 |
| 文字キー | 入力。F1=入力モード切替、SHIFT=大文字、SYMBOL=スペース、BACKSPACE=削除、F2/F3/F4 = ー/、/。 |

## データの用意(PC側)

変換ツールの詳細は [docs/TOOLS.md](docs/TOOLS.md)。コマンド不要のブラウザ版(XServer 等に置ける静的HTML)は [web/](web/README.md) にあります。

```
# Anki のデッキ(.apkg / テキスト書き出し)・CSV -> IMPORT.DAT
python3 tools/anki_to_deck.py my.apkg --deck "英単語" -o IMPORT.DAT
python3 tools/csv_to_deck.py my.csv --deck "英単語" --dat IMPORT.DAT
# Wikipedia(タイトル一覧 / 公式ダンプ / WikiExtractor)-> WIKI.DAT
python3 tools/wikipedia_convert.py fetch titles.txt --lang ja -o WIKI.DAT
```
`data/device/` に置いたファイルは `build/*/MEMAN/` にコピーされます(無ければ CI がサンプルを生成)。デバイス側では **Settings → Import a deck from a file** で取り込みます。

**CSV を直接取り込む場合**(変換不要): UTF-8 の CSV(列は `Front,Back,Example`、見出し行は省略可)を `MEMAN` フォルダに入れます。**ファイル名は自由**です(`IMPORT.CSV`、`IMPORT2.CSV`、`words.csv` など。拡張子が `.CSV` なら何でも可)。変換ツールが作る `.DAT` は `IMPORT` で始まる名前(`IMPORT.DAT`、`IMPORT2.DAT` …)にします(`MEMANKI.DAT` と `WIKI.DAT` はデータ用なので一覧に出ません)。
**Settings → Import a deck from a file** を開くと、見つかったファイルが一覧に並びます。選んで ENTER で取り込みます(CSV はデッキ名を入力。初期値はファイル名)。引用符、欄内の改行、タブ/セミコロン区切り、BOM、CRLF に対応します。Excel で作るときは「CSV UTF-8」で保存してください(Shift_JIS は取り込めません)。1回の取り込みは最大600枚(確保できない機種では16枚)です。辞書がフォルダの一覧を返さない場合は、`IMPORT.CSV` / `IMPORT.DAT` / `IMPORT1`〜`IMPORT9` の名前だけを探します。

## Files(テキスト / オフラインブラウザ / 表計算)

ホーム最下段の **Files** で、アプリフォルダ(`_USER\` を含む)の `*.TXT` `*.HTM` `*.CSV` を一覧(名前順)して開きます。F1=新規テキスト、F2=新規シート。

| 種類 | 機能 | キー |
|---|---|---|
| TXT | テキストエディタ(入力は末尾に追加、ローマ字→かな対応) | 文字キー=入力、ENTER=改行、F1=入力モード、F5=保存、↑↓/PAGE=スクロール、BACK=閉じる(未保存なら確認) |
| HTM | オフラインブラウザ(HTML + CSS + 画像。下記) | ↑↓/PAGE=スクロール、F2=リンク一覧、BACK=戻る/閉じる |
| CSV | 表計算(最大60行×12列、1セル19バイト、引用符・BOM・タブ/セミコロン区切り対応) | 矢印=移動、ENTER=セル編集、F1/F2=±1、F3/F4=±10、F5=消去、F6=保存、F7/F8=上の数値列の `=SUM(..)` / `=AVG(..)` |

**HTML ページの用意(PC側)**: `python3 tools/html_prepare.py index.html -o out/` で、HTML・CSS・画像を 8.3 名の `*.HTM` / `*.CSS` / `*.IMG` に変換します(`<a href>` で繋がったローカルページも一緒に変換。画像は Pillow で 480×200 以内・256色に縮小)。できたファイルを MEMAN フォルダに入れてください。コマンド不要のブラウザ版は、変換ページ([web/](web/README.md))の「HTML → オフラインブラウザ」タブです(ファイル/フォルダをドロップ → ZIP をダウンロード)。
対応する CSS: `color`、`background(-color)`(body/html)、`font-size`(大きい指定は2倍表示)、`text-align:center`、`display:none`、セレクタは `タグ` / `.class` / `#id`(複数指定は最後の単純セレクタ)、`style=""`、`<font color>`、`<body bgcolor>`。画像は `<img>` の位置に表示(`<h1>` などは2倍、リンクは青)。太字・表レイアウト・`float`・外部サイト(http)は非対応です。大きい画像は描画に時間がかかります(単色部分は高速)。

数字キーが無いため、数値は F1〜F4 で増減して入力します。数式は `=SUM(A1:A5)` / `=AVG(A1:A5)`(整数演算)。ファイルは最大24KB(確保できない機種では1KB)。実装は `src/fileapp.inc`、テストは `tools/sim/scripts/13_files_files.txt`。

## 既知の制限

- 実機未検証です。特に (1) `WIKI.DAT`/`IMPORT.DAT` がアプリ導入時に一緒にコピーされるか、(2) 保存先、(3) キー割当は実機で確認が必要です(設定のキーテスト、Data file 表示)。
- 美咲フォントは JIS X 0208 範囲です。それ以外の文字は `?` になります。8×8は小さいので、必要に応じて2倍表示(Wikipedia は F1)を使ってください。
- 漢字の読みが無い Wikipedia 記事は、よみ(`reading` またはテキスト先頭の「(よみ)」)が無いと検索入力できません(一覧のスクロールでは見られます)。
- メモリ: 静的RAMは約32KBのため、カード表・記事バッファはシステムメモリプールから確保します(最大カード600枚/記事32KB。確保できない機種では16枚/約1KB)。
- 数字・記号キーは無いため、数字は入力できません。

## ビルド・検証

[GITHUB_SETUP.md](GITHUB_SETUP.md)。ローカル確認は `tools/sim/run_sim.sh`(実機と同じUIコードをホストで動かし、画面PNGと自動テストを出力)。

## ライセンス

`src/libc` が GPL-2.0(Gnuboy EX 由来)のため本リポジトリは GPL-2.0(`COPYING`)。`src/jfont_data.c` は美咲フォント(© Num Kadoma、自由に利用・再配布可、無保証。`docs/MISAKI_LICENSE.txt`)から生成。Wikipedia 本文は同梱していません(サンプルは自作の短文)。
